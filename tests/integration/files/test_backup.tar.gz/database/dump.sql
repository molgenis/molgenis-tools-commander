--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: validate_update_it_emx_autoid_testAutoId#46feeb51(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_it_emx_autoid_testAutoId#46feeb51"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "it_emx_autoid_testAutoId#46feeb51" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_it_emx_autoid_testAutoId#46feeb51"() OWNER TO molgenis;

--
-- Name: validate_update_sys_App#1723bf4f(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_App#1723bf4f"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_App#1723bf4f" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_App#1723bf4f"() OWNER TO molgenis;

--
-- Name: validate_update_sys_FileMeta#76d84794(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_FileMeta#76d84794"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_FileMeta#76d84794" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_FileMeta#76d84794"() OWNER TO molgenis;

--
-- Name: validate_update_sys_FreemarkerTemplate#1b0d9d12(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_FreemarkerTemplate#1b0d9d12"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_FreemarkerTemplate#1b0d9d12" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_FreemarkerTemplate#1b0d9d12"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ImportRun#5ed65642(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ImportRun#5ed65642"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ImportRun#5ed65642" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ImportRun#5ed65642"() OWNER TO molgenis;

--
-- Name: validate_update_sys_L10nString#95a21e09(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_L10nString#95a21e09"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_L10nString#95a21e09" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_L10nString#95a21e09"() OWNER TO molgenis;

--
-- Name: validate_update_sys_Language#ab857455(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_Language#ab857455"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."code" <> NEW."code" THEN
    RAISE EXCEPTION 'Updating read-only column "code" of table "sys_Language#ab857455" with id [%] is not allowed', OLD."code" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_Language#ab857455"() OWNER TO molgenis;

--
-- Name: validate_update_sys_Plugin#4fafb60a(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_Plugin#4fafb60a"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_Plugin#4fafb60a" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."path" <> NEW."path" THEN
    RAISE EXCEPTION 'Updating read-only column "path" of table "sys_Plugin#4fafb60a" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_Plugin#4fafb60a"() OWNER TO molgenis;

--
-- Name: validate_update_sys_StaticContent#f1dd2665(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_StaticContent#f1dd2665"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."key_" <> NEW."key_" THEN
    RAISE EXCEPTION 'Updating read-only column "key_" of table "sys_StaticContent#f1dd2665" with id [%] is not allowed', OLD."key_" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_StaticContent#f1dd2665"() OWNER TO molgenis;

--
-- Name: validate_update_sys_beacons_Beacon#8e99cfb8(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_beacons_Beacon#8e99cfb8"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_beacons_Beacon#8e99cfb8" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_beacons_Beacon#8e99cfb8"() OWNER TO molgenis;

--
-- Name: validate_update_sys_beacons_BeaconDataset#17b7de29(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_beacons_BeaconDataset#17b7de29"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_beacons_BeaconDataset#17b7de29" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_beacons_BeaconDataset#17b7de29"() OWNER TO molgenis;

--
-- Name: validate_update_sys_beacons_BeaconOrganization#02fc7b88(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_beacons_BeaconOrganization#02fc7b88"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_beacons_BeaconOrganization#02fc7b88" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_beacons_BeaconOrganization#02fc7b88"() OWNER TO molgenis;

--
-- Name: validate_update_sys_dec_DecoratorConfiguration#e9347da9(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_dec_DecoratorConfiguration#e9347da9"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_dec_DecoratorConfiguration#e9347da9" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_dec_DecoratorConfiguration#e9347da9"() OWNER TO molgenis;

--
-- Name: validate_update_sys_dec_DecoratorParameters#0c01537a(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_dec_DecoratorParameters#0c01537a"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_dec_DecoratorParameters#0c01537a" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_dec_DecoratorParameters#0c01537a"() OWNER TO molgenis;

--
-- Name: validate_update_sys_dec_DynamicDecorator#8c3531bb(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_dec_DynamicDecorator#8c3531bb"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_dec_DynamicDecorator#8c3531bb" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_dec_DynamicDecorator#8c3531bb"() OWNER TO molgenis;

--
-- Name: validate_update_sys_genomebrowser_GenomeBrowserAttribu#bf815a63(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_genomebrowser_GenomeBrowserAttribu#bf815a63"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_genomebrowser_GenomeBrowserAttributes#bf815a63" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_genomebrowser_GenomeBrowserAttribu#bf815a63"() OWNER TO molgenis;

--
-- Name: validate_update_sys_genomebrowser_GenomeBrowserSetting#294012a4(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_genomebrowser_GenomeBrowserSetting#294012a4"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_genomebrowser_GenomeBrowserSettings#294012a4" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_genomebrowser_GenomeBrowserSetting#294012a4"() OWNER TO molgenis;

--
-- Name: validate_update_sys_idx_IndexAction#43bbc99b(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_idx_IndexAction#43bbc99b"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_idx_IndexAction#43bbc99b" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_idx_IndexAction#43bbc99b"() OWNER TO molgenis;

--
-- Name: validate_update_sys_idx_IndexActionGroup#dd7eea75(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_idx_IndexActionGroup#dd7eea75"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_idx_IndexActionGroup#dd7eea75" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_idx_IndexActionGroup#dd7eea75"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_AmazonBucketJobExecution#f9fb2a28(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_AmazonBucketJobExecution#f9fb2a28"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_AmazonBucketJobExecution#f9fb2a28" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_AmazonBucketJobExecution#f9fb2a28"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_FileIngestJobExecution#091fdb52(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_FileIngestJobExecution#091fdb52"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_FileIngestJobExecution#091fdb52" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_FileIngestJobExecution#091fdb52"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_IndexJobExecution#1d1bc397(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_IndexJobExecution#1d1bc397"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_IndexJobExecution#1d1bc397" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_IndexJobExecution#1d1bc397"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_MappingJobExecution#9d59355f(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_MappingJobExecution#9d59355f"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_MappingJobExecution#9d59355f" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_MappingJobExecution#9d59355f"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_OneClickImportJobExecution#c6636b72(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_OneClickImportJobExecution#c6636b72"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_OneClickImportJobExecution#c6636b72" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_OneClickImportJobExecution#c6636b72"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_ResourceCopyJobExecution#79e3e597(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_ResourceCopyJobExecution#79e3e597"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_ResourceCopyJobExecution#79e3e597" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_ResourceCopyJobExecution#79e3e597"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_ResourceDeleteJobExecution#5d6022b0(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_ResourceDeleteJobExecution#5d6022b0"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_ResourceDeleteJobExecution#5d6022b0" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_ResourceDeleteJobExecution#5d6022b0"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_ResourceDownloadJobExecution#3d0dbc70(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_ResourceDownloadJobExecution#3d0dbc70"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_ResourceDownloadJobExecution#3d0dbc70" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_ResourceDownloadJobExecution#3d0dbc70"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_ScheduledJob#d2aed7e4(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_ScheduledJob#d2aed7e4"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_job_ScheduledJob#d2aed7e4" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_ScheduledJob#d2aed7e4"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_ScheduledJobType#d68c491a(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_ScheduledJobType#d68c491a"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."name" <> NEW."name" THEN
    RAISE EXCEPTION 'Updating read-only column "name" of table "sys_job_ScheduledJobType#d68c491a" with id [%] is not allowed', OLD."name" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_ScheduledJobType#d68c491a"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_ScriptJobExecution#26f219e1(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_ScriptJobExecution#26f219e1"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_ScriptJobExecution#26f219e1" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_ScriptJobExecution#26f219e1"() OWNER TO molgenis;

--
-- Name: validate_update_sys_job_SortaJobExecution#3df661b2(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_job_SortaJobExecution#3df661b2"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_job_SortaJobExecution#3df661b2" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_job_SortaJobExecution#3df661b2"() OWNER TO molgenis;

--
-- Name: validate_update_sys_mail_JavaMailProperty#ddcd42a8(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_mail_JavaMailProperty#ddcd42a8"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."mailSettings" <> NEW."mailSettings" THEN
    RAISE EXCEPTION 'Updating read-only column "mailSettings" of table "sys_mail_JavaMailProperty#ddcd42a8" with id [%] is not allowed', OLD."key" USING ERRCODE = '23506';
  END IF;
  IF OLD."key" <> NEW."key" THEN
    RAISE EXCEPTION 'Updating read-only column "key" of table "sys_mail_JavaMailProperty#ddcd42a8" with id [%] is not allowed', OLD."key" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_mail_JavaMailProperty#ddcd42a8"() OWNER TO molgenis;

--
-- Name: validate_update_sys_map_AttributeMapping#fdffac26(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_map_AttributeMapping#fdffac26"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_map_AttributeMapping#fdffac26" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_map_AttributeMapping#fdffac26"() OWNER TO molgenis;

--
-- Name: validate_update_sys_map_EntityMapping#4c287e1a(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_map_EntityMapping#4c287e1a"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_map_EntityMapping#4c287e1a" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_map_EntityMapping#4c287e1a"() OWNER TO molgenis;

--
-- Name: validate_update_sys_map_MappingProject#c2f22991(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_map_MappingProject#c2f22991"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_map_MappingProject#c2f22991" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_map_MappingProject#c2f22991"() OWNER TO molgenis;

--
-- Name: validate_update_sys_map_MappingTarget#8e135dd7(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_map_MappingTarget#8e135dd7"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."identifier" <> NEW."identifier" THEN
    RAISE EXCEPTION 'Updating read-only column "identifier" of table "sys_map_MappingTarget#8e135dd7" with id [%] is not allowed', OLD."identifier" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_map_MappingTarget#8e135dd7"() OWNER TO molgenis;

--
-- Name: validate_update_sys_md_Attribute#c8d9a252(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_md_Attribute#c8d9a252"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_md_Attribute#c8d9a252" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."name" <> NEW."name" THEN
    RAISE EXCEPTION 'Updating read-only column "name" of table "sys_md_Attribute#c8d9a252" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."entity" <> NEW."entity" THEN
    RAISE EXCEPTION 'Updating read-only column "entity" of table "sys_md_Attribute#c8d9a252" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."mappedBy" <> NEW."mappedBy" THEN
    RAISE EXCEPTION 'Updating read-only column "mappedBy" of table "sys_md_Attribute#c8d9a252" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_md_Attribute#c8d9a252"() OWNER TO molgenis;

--
-- Name: validate_update_sys_md_EntityType#6a3870a0(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_md_EntityType#6a3870a0"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_md_EntityType#6a3870a0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."isAbstract" <> NEW."isAbstract" THEN
    RAISE EXCEPTION 'Updating read-only column "isAbstract" of table "sys_md_EntityType#6a3870a0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."extends" <> NEW."extends" THEN
    RAISE EXCEPTION 'Updating read-only column "extends" of table "sys_md_EntityType#6a3870a0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."backend" <> NEW."backend" THEN
    RAISE EXCEPTION 'Updating read-only column "backend" of table "sys_md_EntityType#6a3870a0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_md_EntityType#6a3870a0"() OWNER TO molgenis;

--
-- Name: validate_update_sys_md_Package#a6dc6fe7(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_md_Package#a6dc6fe7"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_md_Package#a6dc6fe7" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_md_Package#a6dc6fe7"() OWNER TO molgenis;

--
-- Name: validate_update_sys_md_Tag#c2d685da(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_md_Tag#c2d685da"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_md_Tag#c2d685da" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_md_Tag#c2d685da"() OWNER TO molgenis;

--
-- Name: validate_update_sys_negotiator_NegotiatorConfig#aced883a(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_negotiator_NegotiatorConfig#aced883a"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_negotiator_NegotiatorConfig#aced883a" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_negotiator_NegotiatorConfig#aced883a"() OWNER TO molgenis;

--
-- Name: validate_update_sys_negotiator_NegotiatorEntityConfig#9a61747d(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_negotiator_NegotiatorEntityConfig#9a61747d"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_negotiator_NegotiatorEntityConfig#9a61747d" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_negotiator_NegotiatorEntityConfig#9a61747d"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ont_Ontology#49a81949(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ont_Ontology#49a81949"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ont_Ontology#49a81949" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ont_Ontology#49a81949"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ont_OntologyTerm#f0034aa0(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ont_OntologyTerm#f0034aa0"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ont_OntologyTerm#f0034aa0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ont_OntologyTerm#f0034aa0"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ont_OntologyTermDynamicAnnotation#6454b1f8(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ont_OntologyTermDynamicAnnotation#6454b1f8"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ont_OntologyTermDynamicAnnotation#6454b1f8" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ont_OntologyTermDynamicAnnotation#6454b1f8"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ont_OntologyTermHit#9ce87f6a(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ont_OntologyTermHit#9ce87f6a"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ont_OntologyTermHit#9ce87f6a" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ont_OntologyTermHit#9ce87f6a"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ont_OntologyTermNodePath#adc5397c(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ont_OntologyTermNodePath#adc5397c"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ont_OntologyTermNodePath#adc5397c" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ont_OntologyTermNodePath#adc5397c"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ont_OntologyTermSynonym#ce764ed4(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ont_OntologyTermSynonym#ce764ed4"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ont_OntologyTermSynonym#ce764ed4" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ont_OntologyTermSynonym#ce764ed4"() OWNER TO molgenis;

--
-- Name: validate_update_sys_ont_TermFrequency#aef76974(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_ont_TermFrequency#aef76974"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_ont_TermFrequency#aef76974" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_ont_TermFrequency#aef76974"() OWNER TO molgenis;

--
-- Name: validate_update_sys_scr_Script#354cd12b(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_scr_Script#354cd12b"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."name" <> NEW."name" THEN
    RAISE EXCEPTION 'Updating read-only column "name" of table "sys_scr_Script#354cd12b" with id [%] is not allowed', OLD."name" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_scr_Script#354cd12b"() OWNER TO molgenis;

--
-- Name: validate_update_sys_scr_ScriptParameter#88bc2dd2(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_scr_ScriptParameter#88bc2dd2"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."name" <> NEW."name" THEN
    RAISE EXCEPTION 'Updating read-only column "name" of table "sys_scr_ScriptParameter#88bc2dd2" with id [%] is not allowed', OLD."name" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_scr_ScriptParameter#88bc2dd2"() OWNER TO molgenis;

--
-- Name: validate_update_sys_scr_ScriptType#3e8906a6(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_scr_ScriptType#3e8906a6"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."name" <> NEW."name" THEN
    RAISE EXCEPTION 'Updating read-only column "name" of table "sys_scr_ScriptType#3e8906a6" with id [%] is not allowed', OLD."name" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_scr_ScriptType#3e8906a6"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_Group#d325f6e2(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_Group#d325f6e2"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_Group#d325f6e2" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."rootPackage" <> NEW."rootPackage" THEN
    RAISE EXCEPTION 'Updating read-only column "rootPackage" of table "sys_sec_Group#d325f6e2" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_Group#d325f6e2"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_MembershipInvitation#27f7958b(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_MembershipInvitation#27f7958b"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_MembershipInvitation#27f7958b" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_MembershipInvitation#27f7958b"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_PasswordResetToken#a04705dd(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_PasswordResetToken#a04705dd"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_PasswordResetToken#a04705dd" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."user" <> NEW."user" THEN
    RAISE EXCEPTION 'Updating read-only column "user" of table "sys_sec_PasswordResetToken#a04705dd" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_PasswordResetToken#a04705dd"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_RecoveryCode#a3192a80(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_RecoveryCode#a3192a80"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_RecoveryCode#a3192a80" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_RecoveryCode#a3192a80"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_Role#b6639604(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_Role#b6639604"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_Role#b6639604" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."name" <> NEW."name" THEN
    RAISE EXCEPTION 'Updating read-only column "name" of table "sys_sec_Role#b6639604" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_Role#b6639604"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_RoleMembership#2f0e0432(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_RoleMembership#2f0e0432"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_RoleMembership#2f0e0432" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_RoleMembership#2f0e0432"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_Token#2dc001d0(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_Token#2dc001d0"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_Token#2dc001d0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."creationDate" <> NEW."creationDate" THEN
    RAISE EXCEPTION 'Updating read-only column "creationDate" of table "sys_sec_Token#2dc001d0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_Token#2dc001d0"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_User#953f6cde(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_User#953f6cde"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_User#953f6cde" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."username" <> NEW."username" THEN
    RAISE EXCEPTION 'Updating read-only column "username" of table "sys_sec_User#953f6cde" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_User#953f6cde"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_UserSecret#f51533c3(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_UserSecret#f51533c3"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_UserSecret#f51533c3" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_UserSecret#f51533c3"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_oidc_OidcClient#3e7b1b4d(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_oidc_OidcClient#3e7b1b4d"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."registrationId" <> NEW."registrationId" THEN
    RAISE EXCEPTION 'Updating read-only column "registrationId" of table "sys_sec_oidc_OidcClient#3e7b1b4d" with id [%] is not allowed', OLD."registrationId" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_oidc_OidcClient#3e7b1b4d"() OWNER TO molgenis;

--
-- Name: validate_update_sys_sec_oidc_OidcUserMapping#72060861(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_sec_oidc_OidcUserMapping#72060861"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_sec_oidc_OidcUserMapping#72060861" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_sec_oidc_OidcUserMapping#72060861"() OWNER TO molgenis;

--
-- Name: validate_update_sys_set_MailSettings#6daa44ed(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_set_MailSettings#6daa44ed"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_set_MailSettings#6daa44ed" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_set_MailSettings#6daa44ed"() OWNER TO molgenis;

--
-- Name: validate_update_sys_set_OpenCpuSettings#0ec0e4e8(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_set_OpenCpuSettings#0ec0e4e8"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_set_OpenCpuSettings#0ec0e4e8" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_set_OpenCpuSettings#0ec0e4e8"() OWNER TO molgenis;

--
-- Name: validate_update_sys_set_StyleSheet#9d5413fc(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_set_StyleSheet#9d5413fc"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_set_StyleSheet#9d5413fc" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_set_StyleSheet#9d5413fc"() OWNER TO molgenis;

--
-- Name: validate_update_sys_set_app#4f91996f(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_set_app#4f91996f"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."ga_acc_privacy_friendly_mgs" <> NEW."ga_acc_privacy_friendly_mgs" THEN
    RAISE EXCEPTION 'Updating read-only column "ga_acc_privacy_friendly_mgs" of table "sys_set_app#4f91996f" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_set_app#4f91996f" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_set_app#4f91996f"() OWNER TO molgenis;

--
-- Name: validate_update_sys_set_auth#98c4c015(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_set_auth#98c4c015"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_set_auth#98c4c015" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_set_auth#98c4c015"() OWNER TO molgenis;

--
-- Name: validate_update_sys_set_dataexplorer#76c80fb0(); Type: FUNCTION; Schema: public; Owner: molgenis
--

CREATE FUNCTION public."validate_update_sys_set_dataexplorer#76c80fb0"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD."id" <> NEW."id" THEN
    RAISE EXCEPTION 'Updating read-only column "id" of table "sys_set_dataexplorer#76c80fb0" with id [%] is not allowed', OLD."id" USING ERRCODE = '23506';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public."validate_update_sys_set_dataexplorer#76c80fb0"() OWNER TO molgenis;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Version; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."Version" (
    id integer NOT NULL
);


ALTER TABLE public."Version" OWNER TO molgenis;

--
-- Name: acl_class; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public.acl_class (
    id bigint NOT NULL,
    class character varying NOT NULL,
    class_id_type character varying NOT NULL
);


ALTER TABLE public.acl_class OWNER TO molgenis;

--
-- Name: acl_class_id_seq; Type: SEQUENCE; Schema: public; Owner: molgenis
--

CREATE SEQUENCE public.acl_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.acl_class_id_seq OWNER TO molgenis;

--
-- Name: acl_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: molgenis
--

ALTER SEQUENCE public.acl_class_id_seq OWNED BY public.acl_class.id;


--
-- Name: acl_entry; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public.acl_entry (
    id bigint NOT NULL,
    acl_object_identity bigint NOT NULL,
    ace_order integer NOT NULL,
    sid bigint NOT NULL,
    mask integer NOT NULL,
    granting boolean NOT NULL,
    audit_success boolean NOT NULL,
    audit_failure boolean NOT NULL
);


ALTER TABLE public.acl_entry OWNER TO molgenis;

--
-- Name: acl_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: molgenis
--

CREATE SEQUENCE public.acl_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.acl_entry_id_seq OWNER TO molgenis;

--
-- Name: acl_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: molgenis
--

ALTER SEQUENCE public.acl_entry_id_seq OWNED BY public.acl_entry.id;


--
-- Name: acl_object_identity; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public.acl_object_identity (
    id bigint NOT NULL,
    object_id_class bigint NOT NULL,
    object_id_identity character varying NOT NULL,
    parent_object bigint,
    owner_sid bigint,
    entries_inheriting boolean NOT NULL
);


ALTER TABLE public.acl_object_identity OWNER TO molgenis;

--
-- Name: acl_object_identity_id_seq; Type: SEQUENCE; Schema: public; Owner: molgenis
--

CREATE SEQUENCE public.acl_object_identity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.acl_object_identity_id_seq OWNER TO molgenis;

--
-- Name: acl_object_identity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: molgenis
--

ALTER SEQUENCE public.acl_object_identity_id_seq OWNED BY public.acl_object_identity.id;


--
-- Name: acl_sid; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public.acl_sid (
    id bigint NOT NULL,
    principal boolean NOT NULL,
    sid character varying NOT NULL
);


ALTER TABLE public.acl_sid OWNER TO molgenis;

--
-- Name: acl_sid_id_seq; Type: SEQUENCE; Schema: public; Owner: molgenis
--

CREATE SEQUENCE public.acl_sid_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.acl_sid_id_seq OWNER TO molgenis;

--
-- Name: acl_sid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: molgenis
--

ALTER SEQUENCE public.acl_sid_id_seq OWNED BY public.acl_sid.id;


--
-- Name: it_emx_autoid_testAutoId#46feeb51; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."it_emx_autoid_testAutoId#46feeb51" (
    id character varying(255) NOT NULL,
    "firstName" character varying(255),
    "lastName" character varying(255)
);


ALTER TABLE public."it_emx_autoid_testAutoId#46feeb51" OWNER TO molgenis;

--
-- Name: sys_App#1723bf4f; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_App#1723bf4f" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description text,
    "isActive" boolean NOT NULL,
    "appVersion" character varying(255),
    "apiDependency" character varying(255),
    "templateContent" text NOT NULL,
    "resourceFolder" character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "appConfig" text,
    "includeMenuAndFooter" boolean NOT NULL
);


ALTER TABLE public."sys_App#1723bf4f" OWNER TO molgenis;

--
-- Name: sys_FileMeta#76d84794; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_FileMeta#76d84794" (
    id character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    "contentType" character varying(255),
    size bigint,
    url character varying(255) NOT NULL
);


ALTER TABLE public."sys_FileMeta#76d84794" OWNER TO molgenis;

--
-- Name: sys_FreemarkerTemplate#1b0d9d12; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_FreemarkerTemplate#1b0d9d12" (
    id character varying(255) NOT NULL,
    "Name" character varying(255) NOT NULL,
    "Value" text NOT NULL
);


ALTER TABLE public."sys_FreemarkerTemplate#1b0d9d12" OWNER TO molgenis;

--
-- Name: sys_ImportRun#5ed65642; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ImportRun#5ed65642" (
    id character varying(255) NOT NULL,
    "startDate" timestamp with time zone NOT NULL,
    "endDate" timestamp with time zone,
    username character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    message text,
    progress integer NOT NULL,
    "importedEntities" text,
    notify boolean,
    CONSTRAINT "sys_ImportRun#5ed65642_status_chk" CHECK (((status)::text = ANY ((ARRAY['RUNNING'::character varying, 'FINISHED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public."sys_ImportRun#5ed65642" OWNER TO molgenis;

--
-- Name: sys_L10nString#95a21e09; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_L10nString#95a21e09" (
    id character varying(255) NOT NULL,
    msgid character varying(255) NOT NULL,
    namespace character varying(255) NOT NULL,
    description text,
    en text,
    nl text,
    de text,
    es text,
    it text,
    pt text,
    fr text,
    xx text
);


ALTER TABLE public."sys_L10nString#95a21e09" OWNER TO molgenis;

--
-- Name: sys_Language#ab857455; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_Language#ab857455" (
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    active boolean NOT NULL
);


ALTER TABLE public."sys_Language#ab857455" OWNER TO molgenis;

--
-- Name: sys_Plugin#4fafb60a; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_Plugin#4fafb60a" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    description character varying(255)
);


ALTER TABLE public."sys_Plugin#4fafb60a" OWNER TO molgenis;

--
-- Name: sys_StaticContent#f1dd2665; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_StaticContent#f1dd2665" (
    key_ character varying(255) NOT NULL,
    content text
);


ALTER TABLE public."sys_StaticContent#f1dd2665" OWNER TO molgenis;

--
-- Name: sys_beacons_Beacon#8e99cfb8; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_beacons_Beacon#8e99cfb8" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    api_version character varying(255) NOT NULL,
    beacon_organization character varying(255),
    description text,
    version character varying(255),
    welcome_url character varying(255)
);


ALTER TABLE public."sys_beacons_Beacon#8e99cfb8" OWNER TO molgenis;

--
-- Name: sys_beacons_Beacon#8e99cfb8_data_sets; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_beacons_Beacon#8e99cfb8_data_sets" (
    "order" integer,
    id character varying(255) NOT NULL,
    data_sets character varying(255) NOT NULL
);


ALTER TABLE public."sys_beacons_Beacon#8e99cfb8_data_sets" OWNER TO molgenis;

--
-- Name: sys_beacons_BeaconDataset#17b7de29; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_beacons_BeaconDataset#17b7de29" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description character varying(255),
    data_set_entity_type character varying(255) NOT NULL,
    genome_browser_attributes character varying(255) NOT NULL
);


ALTER TABLE public."sys_beacons_BeaconDataset#17b7de29" OWNER TO molgenis;

--
-- Name: sys_beacons_BeaconOrganization#02fc7b88; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_beacons_BeaconOrganization#02fc7b88" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    address character varying(255),
    welcome_url character varying(255),
    contact_url character varying(255),
    logo_url character varying(255)
);


ALTER TABLE public."sys_beacons_BeaconOrganization#02fc7b88" OWNER TO molgenis;

--
-- Name: sys_dec_DecoratorConfi#e9347da9_parameters; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_dec_DecoratorConfi#e9347da9_parameters" (
    "order" integer,
    id character varying(255) NOT NULL,
    parameters character varying(255) NOT NULL
);


ALTER TABLE public."sys_dec_DecoratorConfi#e9347da9_parameters" OWNER TO molgenis;

--
-- Name: sys_dec_DecoratorConfiguration#e9347da9; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_dec_DecoratorConfiguration#e9347da9" (
    id character varying(255) NOT NULL,
    "entityTypeId" character varying(255) NOT NULL
);


ALTER TABLE public."sys_dec_DecoratorConfiguration#e9347da9" OWNER TO molgenis;

--
-- Name: sys_dec_DecoratorParameters#0c01537a; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_dec_DecoratorParameters#0c01537a" (
    id character varying(255) NOT NULL,
    decorator character varying(255) NOT NULL,
    parameters text
);


ALTER TABLE public."sys_dec_DecoratorParameters#0c01537a" OWNER TO molgenis;

--
-- Name: sys_dec_DynamicDecorator#8c3531bb; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_dec_DynamicDecorator#8c3531bb" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    schema text
);


ALTER TABLE public."sys_dec_DynamicDecorator#8c3531bb" OWNER TO molgenis;

--
-- Name: sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks" (
    "order" integer,
    id character varying(255) NOT NULL,
    molgenis_reference_tracks character varying(255) NOT NULL
);


ALTER TABLE public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks" OWNER TO molgenis;

--
-- Name: sys_genomebrowser_GenomeBrowserAttributes#bf815a63; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63" (
    id character varying(255) NOT NULL,
    "default" boolean NOT NULL,
    "order" integer,
    pos character varying(255) NOT NULL,
    chr character varying(255) NOT NULL,
    ref character varying(255),
    alt character varying(255),
    stop character varying(255)
);


ALTER TABLE public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63" OWNER TO molgenis;

--
-- Name: sys_genomebrowser_GenomeBrowserSettings#294012a4; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_genomebrowser_GenomeBrowserSettings#294012a4" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    entity character varying(255) NOT NULL,
    genome_browser_attrs character varying(255) NOT NULL,
    "labelAttr" character varying(255) NOT NULL,
    track_type character varying(255) NOT NULL,
    exon_key character varying(255),
    "scoreAttr" character varying(255),
    attrs character varying(255),
    molgenis_reference_tracks_mode character varying(255) NOT NULL,
    actions text,
    feature_info_plugin text,
    CONSTRAINT "sys_genomebrowser_Ge#294012a4_molgenis_reference_t#3063ef51_chk" CHECK (((molgenis_reference_tracks_mode)::text = ANY ((ARRAY['ALL'::character varying, 'CONFIGURED'::character varying, 'NONE'::character varying])::text[]))),
    CONSTRAINT "sys_genomebrowser_Ge#294012a4_track_type_chk" CHECK (((track_type)::text = ANY ((ARRAY['VARIANT'::character varying, 'NUMERIC'::character varying, 'EXON'::character varying])::text[])))
);


ALTER TABLE public."sys_genomebrowser_GenomeBrowserSettings#294012a4" OWNER TO molgenis;

--
-- Name: sys_idx_IndexAction#43bbc99b; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_idx_IndexAction#43bbc99b" (
    id character varying(255) NOT NULL,
    "creationDateTime" timestamp with time zone NOT NULL,
    "indexActionGroup" character varying(255),
    "actionOrder" integer NOT NULL,
    "entityTypeId" character varying(255) NOT NULL,
    "entityId" text,
    "indexStatus" character varying(255) NOT NULL,
    CONSTRAINT "sys_idx_IndexAction#43bbc99b_indexStatus_chk" CHECK ((("indexStatus")::text = ANY ((ARRAY['FINISHED'::character varying, 'CANCELED'::character varying, 'FAILED'::character varying, 'STARTED'::character varying, 'PENDING'::character varying])::text[])))
);


ALTER TABLE public."sys_idx_IndexAction#43bbc99b" OWNER TO molgenis;

--
-- Name: sys_idx_IndexActionGroup#dd7eea75; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_idx_IndexActionGroup#dd7eea75" (
    id character varying(255) NOT NULL,
    count integer NOT NULL
);


ALTER TABLE public."sys_idx_IndexActionGroup#dd7eea75" OWNER TO molgenis;

--
-- Name: sys_job_AmazonBucketJobExecution#f9fb2a28; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_AmazonBucketJobExecution#f9fb2a28" (
    bucket character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    expression boolean NOT NULL,
    "accessKey" character varying(255) NOT NULL,
    "secretKey" character varying(255) NOT NULL,
    region character varying(255) NOT NULL,
    "targetEntityId" character varying(255),
    file character varying(255),
    extension character varying(255),
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_AmazonBucket#f9fb2a28_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_AmazonBucketJobExecution#f9fb2a28" OWNER TO molgenis;

--
-- Name: sys_job_FileIngestJobExecution#091fdb52; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_FileIngestJobExecution#091fdb52" (
    file character varying(255),
    url character varying(255) NOT NULL,
    loader character varying(255) NOT NULL,
    "targetEntityId" character varying(255) NOT NULL,
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_FileIngestJo#091fdb52_loader_chk" CHECK (((loader)::text = 'CSV'::text)),
    CONSTRAINT "sys_job_FileIngestJo#091fdb52_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_FileIngestJobExecution#091fdb52" OWNER TO molgenis;

--
-- Name: sys_job_IndexJobExecution#1d1bc397; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_IndexJobExecution#1d1bc397" (
    "indexActionJobID" character varying(255) NOT NULL,
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_IndexJobExec#1d1bc397_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_IndexJobExecution#1d1bc397" OWNER TO molgenis;

--
-- Name: sys_job_MappingJobExecution#9d59355f; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_MappingJobExecution#9d59355f" (
    "mappingProjectId" character varying(255) NOT NULL,
    "targetEntityTypeId" character varying(255) NOT NULL,
    "addSourceAttribute" boolean,
    "packageId" character varying(255),
    label character varying(255),
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_MappingJobEx#9d59355f_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_MappingJobExecution#9d59355f" OWNER TO molgenis;

--
-- Name: sys_job_OneClickImportJobExecution#c6636b72; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_OneClickImportJobExecution#c6636b72" (
    file character varying(255) NOT NULL,
    "entityTypes" text,
    package character varying(255),
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_OneClickImpo#c6636b72_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_OneClickImportJobExecution#c6636b72" OWNER TO molgenis;

--
-- Name: sys_job_ResourceCopyJobExecution#79e3e597; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_ResourceCopyJobExecution#79e3e597" (
    resources text,
    "targetPackage" character varying(255),
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_ResourceCopy#79e3e597_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_ResourceCopyJobExecution#79e3e597" OWNER TO molgenis;

--
-- Name: sys_job_ResourceDeleteJobExecution#5d6022b0; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_ResourceDeleteJobExecution#5d6022b0" (
    resources text,
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_ResourceDele#5d6022b0_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_ResourceDeleteJobExecution#5d6022b0" OWNER TO molgenis;

--
-- Name: sys_job_ResourceDownloadJobExecution#3d0dbc70; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_ResourceDownloadJobExecution#3d0dbc70" (
    resources text,
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_ResourceDown#3d0dbc70_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_ResourceDownloadJobExecution#3d0dbc70" OWNER TO molgenis;

--
-- Name: sys_job_ScheduledJob#d2aed7e4; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_ScheduledJob#d2aed7e4" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "cronExpression" character varying(255) NOT NULL,
    active boolean NOT NULL,
    "user" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    type character varying(255) NOT NULL,
    parameters text NOT NULL
);


ALTER TABLE public."sys_job_ScheduledJob#d2aed7e4" OWNER TO molgenis;

--
-- Name: sys_job_ScheduledJobType#d68c491a; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_ScheduledJobType#d68c491a" (
    name character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description text,
    "jobExecutionType" character varying(255) NOT NULL,
    schema text
);


ALTER TABLE public."sys_job_ScheduledJobType#d68c491a" OWNER TO molgenis;

--
-- Name: sys_job_ScriptJobExecution#26f219e1; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_ScriptJobExecution#26f219e1" (
    name character varying(255) NOT NULL,
    parameters text,
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_ScriptJobExe#26f219e1_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_ScriptJobExecution#26f219e1" OWNER TO molgenis;

--
-- Name: sys_job_SortaJobExecution#3df661b2; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_job_SortaJobExecution#3df661b2" (
    name character varying(255) NOT NULL,
    "resultEntity" character varying(255) NOT NULL,
    "sourceEntity" character varying(255) NOT NULL,
    "ontologyIri" character varying(255) NOT NULL,
    "deleteUrl" character varying(255) NOT NULL,
    "Threshold" double precision NOT NULL,
    identifier character varying(255) NOT NULL,
    "user" character varying(255),
    status character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "submissionDate" timestamp with time zone NOT NULL,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "progressInt" integer,
    "progressMax" integer,
    "progressMessage" character varying(255),
    log text,
    "resultUrl" character varying(255),
    "failureEmail" character varying(255),
    "successEmail" character varying(255),
    "scheduledJobId" character varying(255),
    CONSTRAINT "sys_job_SortaJobExec#3df661b2_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'RUNNING'::character varying, 'CANCELING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'CANCELED'::character varying])::text[])))
);


ALTER TABLE public."sys_job_SortaJobExecution#3df661b2" OWNER TO molgenis;

--
-- Name: sys_mail_JavaMailProperty#ddcd42a8; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_mail_JavaMailProperty#ddcd42a8" (
    "mailSettings" character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public."sys_mail_JavaMailProperty#ddcd42a8" OWNER TO molgenis;

--
-- Name: sys_map_AttributeMapping#fdffac26; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_map_AttributeMapping#fdffac26" (
    identifier character varying(255) NOT NULL,
    "targetAttribute" character varying(255) NOT NULL,
    "sourceAttributes" text,
    algorithm text,
    "algorithmState" character varying(255),
    CONSTRAINT "sys_map_AttributeMap#fdffac26_algorithmState_chk" CHECK ((("algorithmState")::text = ANY ((ARRAY['CURATED'::character varying, 'GENERATED_HIGH'::character varying, 'GENERATED_LOW'::character varying, 'DISCUSS'::character varying, 'MISSING_TARGET'::character varying])::text[])))
);


ALTER TABLE public."sys_map_AttributeMapping#fdffac26" OWNER TO molgenis;

--
-- Name: sys_map_EntityMapping#4c287e1a; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_map_EntityMapping#4c287e1a" (
    identifier character varying(255) NOT NULL,
    "sourceEntityType" character varying(255),
    "targetEntityType" character varying(255)
);


ALTER TABLE public."sys_map_EntityMapping#4c287e1a" OWNER TO molgenis;

--
-- Name: sys_map_EntityMapping#4c287e1a_attributeMappings; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_map_EntityMapping#4c287e1a_attributeMappings" (
    "order" integer,
    identifier character varying(255) NOT NULL,
    "attributeMappings" character varying(255) NOT NULL
);


ALTER TABLE public."sys_map_EntityMapping#4c287e1a_attributeMappings" OWNER TO molgenis;

--
-- Name: sys_map_MappingProject#c2f22991; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_map_MappingProject#c2f22991" (
    identifier character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    depth integer
);


ALTER TABLE public."sys_map_MappingProject#c2f22991" OWNER TO molgenis;

--
-- Name: sys_map_MappingProject#c2f22991_mappingtargets; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_map_MappingProject#c2f22991_mappingtargets" (
    "order" integer,
    identifier character varying(255) NOT NULL,
    mappingtargets character varying(255) NOT NULL
);


ALTER TABLE public."sys_map_MappingProject#c2f22991_mappingtargets" OWNER TO molgenis;

--
-- Name: sys_map_MappingTarget#8e135dd7; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_map_MappingTarget#8e135dd7" (
    identifier character varying(255) NOT NULL,
    target character varying(255) NOT NULL
);


ALTER TABLE public."sys_map_MappingTarget#8e135dd7" OWNER TO molgenis;

--
-- Name: sys_map_MappingTarget#8e135dd7_entityMappings; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_map_MappingTarget#8e135dd7_entityMappings" (
    "order" integer,
    identifier character varying(255) NOT NULL,
    "entityMappings" character varying(255) NOT NULL
);


ALTER TABLE public."sys_map_MappingTarget#8e135dd7_entityMappings" OWNER TO molgenis;

--
-- Name: sys_md_Attribute#c8d9a252; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_md_Attribute#c8d9a252" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    entity character varying(255) NOT NULL,
    "sequenceNr" integer NOT NULL,
    type character varying(255) NOT NULL,
    "isIdAttribute" boolean,
    "isLabelAttribute" boolean,
    "lookupAttributeIndex" integer,
    parent character varying(255),
    "refEntityType" character varying(255),
    "isCascadeDelete" boolean,
    "mappedBy" character varying(255),
    "orderBy" character varying(255),
    expression character varying(255),
    "isNullable" boolean NOT NULL,
    "isAuto" boolean NOT NULL,
    "isVisible" boolean NOT NULL,
    label character varying(255),
    description text,
    "isAggregatable" boolean NOT NULL,
    "enumOptions" text,
    "rangeMin" bigint,
    "rangeMax" bigint,
    "isReadOnly" boolean NOT NULL,
    "isUnique" boolean NOT NULL,
    "nullableExpression" text,
    "visibleExpression" text,
    "validationExpression" text,
    "defaultValue" text,
    "labelEn" character varying(255),
    "descriptionEn" text,
    "labelNl" character varying(255),
    "descriptionNl" text,
    "labelDe" character varying(255),
    "descriptionDe" text,
    "labelEs" character varying(255),
    "descriptionEs" text,
    "labelIt" character varying(255),
    "descriptionIt" text,
    "labelPt" character varying(255),
    "descriptionPt" text,
    "labelFr" character varying(255),
    "descriptionFr" text,
    "labelXx" character varying(255),
    "descriptionXx" text,
    CONSTRAINT "sys_md_Attribute#c8d9a252_type_chk" CHECK (((type)::text = ANY ((ARRAY['bool'::character varying, 'categorical'::character varying, 'categoricalmref'::character varying, 'compound'::character varying, 'date'::character varying, 'datetime'::character varying, 'decimal'::character varying, 'email'::character varying, 'enum'::character varying, 'file'::character varying, 'html'::character varying, 'hyperlink'::character varying, 'int'::character varying, 'long'::character varying, 'mref'::character varying, 'onetomany'::character varying, 'script'::character varying, 'string'::character varying, 'text'::character varying, 'xref'::character varying])::text[])))
);


ALTER TABLE public."sys_md_Attribute#c8d9a252" OWNER TO molgenis;

--
-- Name: sys_md_Attribute#c8d9a252_tags; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_md_Attribute#c8d9a252_tags" (
    "order" integer,
    id character varying(255) NOT NULL,
    tags character varying(255) NOT NULL
);


ALTER TABLE public."sys_md_Attribute#c8d9a252_tags" OWNER TO molgenis;

--
-- Name: sys_md_EntityType#6a3870a0; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_md_EntityType#6a3870a0" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description text,
    package character varying(255),
    "isAbstract" boolean NOT NULL,
    extends character varying(255),
    backend character varying(255) NOT NULL,
    "indexingDepth" integer NOT NULL,
    "labelEn" character varying(255),
    "descriptionEn" text,
    "labelNl" character varying(255),
    "descriptionNl" text,
    "labelDe" character varying(255),
    "descriptionDe" text,
    "labelEs" character varying(255),
    "descriptionEs" text,
    "labelIt" character varying(255),
    "descriptionIt" text,
    "labelPt" character varying(255),
    "descriptionPt" text,
    "labelFr" character varying(255),
    "descriptionFr" text,
    "labelXx" character varying(255),
    "descriptionXx" text,
    CONSTRAINT "sys_md_EntityType#6a3870a0_backend_chk" CHECK (((backend)::text = 'PostgreSQL'::text))
);


ALTER TABLE public."sys_md_EntityType#6a3870a0" OWNER TO molgenis;

--
-- Name: sys_md_EntityType#6a3870a0_tags; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_md_EntityType#6a3870a0_tags" (
    "order" integer,
    id character varying(255) NOT NULL,
    tags character varying(255) NOT NULL
);


ALTER TABLE public."sys_md_EntityType#6a3870a0_tags" OWNER TO molgenis;

--
-- Name: sys_md_Package#a6dc6fe7; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_md_Package#a6dc6fe7" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description text,
    parent character varying(255)
);


ALTER TABLE public."sys_md_Package#a6dc6fe7" OWNER TO molgenis;

--
-- Name: sys_md_Package#a6dc6fe7_tags; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_md_Package#a6dc6fe7_tags" (
    "order" integer,
    id character varying(255) NOT NULL,
    tags character varying(255) NOT NULL
);


ALTER TABLE public."sys_md_Package#a6dc6fe7_tags" OWNER TO molgenis;

--
-- Name: sys_md_Tag#c2d685da; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_md_Tag#c2d685da" (
    id character varying(255) NOT NULL,
    "objectIRI" text,
    label character varying(255) NOT NULL,
    "relationIRI" character varying(255) NOT NULL,
    "relationLabel" character varying(255) NOT NULL,
    "codeSystem" character varying(255)
);


ALTER TABLE public."sys_md_Tag#c2d685da" OWNER TO molgenis;

--
-- Name: sys_negotiator_NegotiatorConfig#aced883a; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_negotiator_NegotiatorConfig#aced883a" (
    id character varying(255) NOT NULL,
    negotiator_url character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL
);


ALTER TABLE public."sys_negotiator_NegotiatorConfig#aced883a" OWNER TO molgenis;

--
-- Name: sys_negotiator_NegotiatorEntityConfig#9a61747d; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_negotiator_NegotiatorEntityConfig#9a61747d" (
    id character varying(255) NOT NULL,
    entity character varying(255) NOT NULL,
    "negotiatorConfig" character varying(255) NOT NULL,
    "collectionId" character varying(255) NOT NULL,
    "biobankId" character varying(255) NOT NULL,
    "enabledExpression" text
);


ALTER TABLE public."sys_negotiator_NegotiatorEntityConfig#9a61747d" OWNER TO molgenis;

--
-- Name: sys_ont_Ontology#49a81949; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_Ontology#49a81949" (
    id character varying(255) NOT NULL,
    "ontologyIRI" character varying(255) NOT NULL,
    "ontologyName" character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_Ontology#49a81949" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTerm#f0034aa0; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTerm#f0034aa0" (
    id character varying(255) NOT NULL,
    "ontologyTermIRI" character varying(255) NOT NULL,
    "ontologyTermName" text NOT NULL,
    ontology character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTerm#f0034aa0" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTerm#f0034aa0_nodePath; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTerm#f0034aa0_nodePath" (
    "order" integer,
    id character varying(255) NOT NULL,
    "nodePath" character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTerm#f0034aa0_nodePath" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation" (
    "order" integer,
    id character varying(255) NOT NULL,
    "ontologyTermDynamicAnnotation" character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym" (
    "order" integer,
    id character varying(255) NOT NULL,
    "ontologyTermSynonym" character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTermDynamicAnnotation#6454b1f8; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTermDynamicAnnotation#6454b1f8" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    label character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTermDynamicAnnotation#6454b1f8" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_nodePath; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTermHi#9ce87f6a_nodePath" (
    "order" integer,
    id character varying(255) NOT NULL,
    "nodePath" character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTermHi#9ce87f6a_nodePath" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation" (
    "order" integer,
    id character varying(255) NOT NULL,
    "ontologyTermDynamicAnnotation" character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym" (
    "order" integer,
    id character varying(255) NOT NULL,
    "ontologyTermSynonym" character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTermHit#9ce87f6a; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTermHit#9ce87f6a" (
    id character varying(255) NOT NULL,
    "Score" double precision,
    "Combined_Score" double precision,
    "ontologyTermIRI" character varying(255) NOT NULL,
    "ontologyTermName" text NOT NULL,
    ontology character varying(255) NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTermHit#9ce87f6a" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTermNodePath#adc5397c; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTermNodePath#adc5397c" (
    id character varying(255) NOT NULL,
    "nodePath" text NOT NULL,
    root boolean NOT NULL
);


ALTER TABLE public."sys_ont_OntologyTermNodePath#adc5397c" OWNER TO molgenis;

--
-- Name: sys_ont_OntologyTermSynonym#ce764ed4; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_OntologyTermSynonym#ce764ed4" (
    id character varying(255) NOT NULL,
    "ontologyTermSynonym" text NOT NULL,
    "Score" double precision,
    "Combined_Score" double precision
);


ALTER TABLE public."sys_ont_OntologyTermSynonym#ce764ed4" OWNER TO molgenis;

--
-- Name: sys_ont_TermFrequency#aef76974; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_ont_TermFrequency#aef76974" (
    id character varying(255) NOT NULL,
    term character varying(255) NOT NULL,
    frequency double precision NOT NULL,
    occurrence integer NOT NULL
);


ALTER TABLE public."sys_ont_TermFrequency#aef76974" OWNER TO molgenis;

--
-- Name: sys_scr_Script#354cd12b; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_scr_Script#354cd12b" (
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    content text NOT NULL,
    "generateToken" boolean,
    "resultFileExtension" character varying(255)
);


ALTER TABLE public."sys_scr_Script#354cd12b" OWNER TO molgenis;

--
-- Name: sys_scr_Script#354cd12b_parameters; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_scr_Script#354cd12b_parameters" (
    "order" integer,
    name character varying(255) NOT NULL,
    parameters character varying(255) NOT NULL
);


ALTER TABLE public."sys_scr_Script#354cd12b_parameters" OWNER TO molgenis;

--
-- Name: sys_scr_ScriptParameter#88bc2dd2; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_scr_ScriptParameter#88bc2dd2" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."sys_scr_ScriptParameter#88bc2dd2" OWNER TO molgenis;

--
-- Name: sys_scr_ScriptType#3e8906a6; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_scr_ScriptType#3e8906a6" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."sys_scr_ScriptType#3e8906a6" OWNER TO molgenis;

--
-- Name: sys_sec_Group#d325f6e2; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_Group#d325f6e2" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    "labelEn" character varying(255),
    "labelNl" character varying(255),
    "labelDe" character varying(255),
    "labelEs" character varying(255),
    "labelIt" character varying(255),
    "labelPt" character varying(255),
    "labelFr" character varying(255),
    "labelXx" character varying(255),
    description text,
    "descriptionEn" text,
    "descriptionNl" text,
    "descriptionDe" text,
    "descriptionEs" text,
    "descriptionIt" text,
    "descriptionPt" text,
    "descriptionFr" text,
    "descriptionXx" text,
    public boolean NOT NULL,
    "rootPackage" character varying(255) NOT NULL
);


ALTER TABLE public."sys_sec_Group#d325f6e2" OWNER TO molgenis;

--
-- Name: sys_sec_MembershipInvitation#27f7958b; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_MembershipInvitation#27f7958b" (
    id character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "from" timestamp with time zone NOT NULL,
    "to" timestamp with time zone,
    role character varying(255) NOT NULL,
    "invitedBy" character varying(255) NOT NULL,
    issued timestamp with time zone NOT NULL,
    "lastUpdate" timestamp with time zone NOT NULL,
    "invitationText" text,
    "declineReason" text,
    status character varying(255) NOT NULL,
    CONSTRAINT "sys_sec_MembershipIn#27f7958b_status_chk" CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'ACCEPTED'::character varying, 'REVOKED'::character varying, 'EXPIRED'::character varying, 'DECLINED'::character varying])::text[])))
);


ALTER TABLE public."sys_sec_MembershipInvitation#27f7958b" OWNER TO molgenis;

--
-- Name: sys_sec_PasswordResetToken#a04705dd; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_PasswordResetToken#a04705dd" (
    id character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    "user" character varying(255) NOT NULL,
    "expirationDate" timestamp with time zone NOT NULL
);


ALTER TABLE public."sys_sec_PasswordResetToken#a04705dd" OWNER TO molgenis;

--
-- Name: sys_sec_RecoveryCode#a3192a80; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_RecoveryCode#a3192a80" (
    id character varying(255) NOT NULL,
    "userId" character varying(255) NOT NULL,
    code character varying(255) NOT NULL
);


ALTER TABLE public."sys_sec_RecoveryCode#a3192a80" OWNER TO molgenis;

--
-- Name: sys_sec_Role#b6639604; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_Role#b6639604" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    "labelEn" character varying(255),
    "labelNl" character varying(255),
    "labelDe" character varying(255),
    "labelEs" character varying(255),
    "labelIt" character varying(255),
    "labelPt" character varying(255),
    "labelFr" character varying(255),
    "labelXx" character varying(255),
    description character varying(255),
    "descriptionEn" text,
    "descriptionNl" text,
    "descriptionDe" text,
    "descriptionEs" text,
    "descriptionIt" text,
    "descriptionPt" text,
    "descriptionFr" text,
    "descriptionXx" text,
    "group" character varying(255)
);


ALTER TABLE public."sys_sec_Role#b6639604" OWNER TO molgenis;

--
-- Name: sys_sec_Role#b6639604_includes; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_Role#b6639604_includes" (
    "order" integer,
    id character varying(255) NOT NULL,
    includes character varying(255) NOT NULL
);


ALTER TABLE public."sys_sec_Role#b6639604_includes" OWNER TO molgenis;

--
-- Name: sys_sec_RoleMembership#2f0e0432; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_RoleMembership#2f0e0432" (
    id character varying(255) NOT NULL,
    "user" character varying(255) NOT NULL,
    role character varying(255) NOT NULL,
    "from" timestamp with time zone NOT NULL,
    "to" timestamp with time zone
);


ALTER TABLE public."sys_sec_RoleMembership#2f0e0432" OWNER TO molgenis;

--
-- Name: sys_sec_Token#2dc001d0; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_Token#2dc001d0" (
    id character varying(255) NOT NULL,
    "User" character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    "expirationDate" timestamp with time zone,
    "creationDate" timestamp with time zone NOT NULL,
    description text
);


ALTER TABLE public."sys_sec_Token#2dc001d0" OWNER TO molgenis;

--
-- Name: sys_sec_User#953f6cde; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_User#953f6cde" (
    id character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    password_ character varying(255) NOT NULL,
    "activationCode" character varying(255),
    active boolean NOT NULL,
    superuser boolean NOT NULL,
    "FirstName" character varying(255),
    "MiddleNames" character varying(255),
    "LastName" character varying(255),
    "Title" character varying(255),
    "Affiliation" character varying(255),
    "Department" character varying(255),
    "Role" character varying(255),
    "Address" text,
    "Phone" character varying(255),
    "Email" character varying(255) NOT NULL,
    "Fax" character varying(255),
    "tollFreePhone" character varying(255),
    "City" character varying(255),
    "Country" character varying(255),
    "changePassword" boolean NOT NULL,
    use2fa boolean,
    "languageCode" character varying(255),
    "googleAccountId" character varying(255),
    CONSTRAINT "sys_sec_User#953f6cde_languageCode_chk" CHECK ((("languageCode")::text = ANY ((ARRAY['en'::character varying, 'nl'::character varying, 'de'::character varying, 'es'::character varying, 'it'::character varying, 'pt'::character varying, 'fr'::character varying, 'xx'::character varying])::text[])))
);


ALTER TABLE public."sys_sec_User#953f6cde" OWNER TO molgenis;

--
-- Name: sys_sec_UserSecret#f51533c3; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_UserSecret#f51533c3" (
    id character varying(255) NOT NULL,
    "userId" character varying(255) NOT NULL,
    secret character varying(255) NOT NULL,
    last_failed_authentication timestamp with time zone,
    failed_login_attempts integer NOT NULL
);


ALTER TABLE public."sys_sec_UserSecret#f51533c3" OWNER TO molgenis;

--
-- Name: sys_sec_oidc_OidcClient#3e7b1b4d; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_oidc_OidcClient#3e7b1b4d" (
    "registrationId" character varying(255) NOT NULL,
    "clientId" character varying(255) NOT NULL,
    "clientSecret" character varying(255) NOT NULL,
    "clientName" character varying(255) NOT NULL,
    "clientAuthenticationMethod" character varying(255) NOT NULL,
    "authorizationGrantType" character varying(255) NOT NULL,
    scopes character varying(255) NOT NULL,
    "authorizationUri" character varying(255) NOT NULL,
    "tokenUri" character varying(255) NOT NULL,
    "jwkSetUri" character varying(255) NOT NULL,
    "userInfoUri" character varying(255) NOT NULL,
    "userNameAttributeName" character varying(255) NOT NULL,
    CONSTRAINT "sys_sec_oidc_OidcCli#3e7b1b4d_authorizationGrantType_chk" CHECK ((("authorizationGrantType")::text = ANY ((ARRAY['authorization_code'::character varying, 'implicit'::character varying, 'refresh_token'::character varying])::text[])))
);


ALTER TABLE public."sys_sec_oidc_OidcClient#3e7b1b4d" OWNER TO molgenis;

--
-- Name: sys_sec_oidc_OidcUserMapping#72060861; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_sec_oidc_OidcUserMapping#72060861" (
    id character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    "oidcClient" character varying(255) NOT NULL,
    "oidcUsername" character varying(255) NOT NULL,
    "user" character varying(255) NOT NULL
);


ALTER TABLE public."sys_sec_oidc_OidcUserMapping#72060861" OWNER TO molgenis;

--
-- Name: sys_set_MailSettings#6daa44ed; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_set_MailSettings#6daa44ed" (
    host character varying(255) NOT NULL,
    port integer NOT NULL,
    protocol character varying(255) NOT NULL,
    username character varying(255),
    password character varying(255),
    "defaultEncoding" character varying(255) NOT NULL,
    "startTlsEnabled" character varying(255),
    "waitQuit" character varying(255),
    auth character varying(255),
    "fromAddress" character varying(255),
    "testConnection" boolean NOT NULL,
    id character varying(255) NOT NULL
);


ALTER TABLE public."sys_set_MailSettings#6daa44ed" OWNER TO molgenis;

--
-- Name: sys_set_OpenCpuSettings#0ec0e4e8; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_set_OpenCpuSettings#0ec0e4e8" (
    scheme character varying(255) NOT NULL,
    host character varying(255) NOT NULL,
    port integer NOT NULL,
    "rootPath" character varying(255) NOT NULL,
    id character varying(255) NOT NULL
);


ALTER TABLE public."sys_set_OpenCpuSettings#0ec0e4e8" OWNER TO molgenis;

--
-- Name: sys_set_StyleSheet#9d5413fc; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_set_StyleSheet#9d5413fc" (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "bootstrap3Theme" character varying(255) NOT NULL,
    "bootstrap4Theme" character varying(255)
);


ALTER TABLE public."sys_set_StyleSheet#9d5413fc" OWNER TO molgenis;

--
-- Name: sys_set_app#4f91996f; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_set_app#4f91996f" (
    title character varying(255) NOT NULL,
    logo_href_navbar character varying(255),
    logo_href_top character varying(255),
    "logoTopMaxHeight" integer NOT NULL,
    footer text,
    molgenis_menu text,
    language_code character varying(255) NOT NULL,
    bootstrap_theme character varying(255) NOT NULL,
    css_href character varying(255),
    aggregate_threshold integer,
    custom_javascript text,
    ga_privacy_friendly boolean NOT NULL,
    ga_tracking_id character varying(255),
    ga_acc_privacy_friendly boolean NOT NULL,
    ga_tracking_id_mgs character varying(255),
    ga_acc_privacy_friendly_mgs boolean NOT NULL,
    tracking_code_footer text,
    recaptcha_private_key character varying(255),
    recaptcha_public_key character varying(255),
    recaptcha_is_enabled boolean NOT NULL,
    recaptcha_verify_uri character varying(255) NOT NULL,
    recaptcha_bot_threshold double precision NOT NULL,
    id character varying(255) NOT NULL
);


ALTER TABLE public."sys_set_app#4f91996f" OWNER TO molgenis;

--
-- Name: sys_set_auth#98c4c015; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_set_auth#98c4c015" (
    signup boolean NOT NULL,
    signup_moderation boolean NOT NULL,
    sign_in_2fa character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    CONSTRAINT "sys_set_auth#98c4c015_sign_in_2fa_chk" CHECK (((sign_in_2fa)::text = ANY ((ARRAY['Disabled'::character varying, 'Enabled'::character varying, 'Enforced'::character varying])::text[])))
);


ALTER TABLE public."sys_set_auth#98c4c015" OWNER TO molgenis;

--
-- Name: sys_set_auth#98c4c015_oidcClients; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_set_auth#98c4c015_oidcClients" (
    "order" integer,
    id character varying(255) NOT NULL,
    "oidcClients" character varying(255) NOT NULL
);


ALTER TABLE public."sys_set_auth#98c4c015_oidcClients" OWNER TO molgenis;

--
-- Name: sys_set_dataexplorer#76c80fb0; Type: TABLE; Schema: public; Owner: molgenis
--

CREATE TABLE public."sys_set_dataexplorer#76c80fb0" (
    searchbox boolean NOT NULL,
    item_select_panel boolean NOT NULL,
    launch_wizard boolean NOT NULL,
    header_abbreviate integer NOT NULL,
    show_navigator_link boolean,
    mod_aggregates boolean NOT NULL,
    agg_distinct boolean NOT NULL,
    agg_distinct_overrides text,
    mod_data boolean NOT NULL,
    gb_init_browser_links text NOT NULL,
    gb_init_coord_system text NOT NULL,
    gb_init_location text NOT NULL,
    gb_init_sources text NOT NULL,
    gb_init_highlight_region boolean NOT NULL,
    data_genome_browser boolean NOT NULL,
    use_vue_data_row_edit boolean NOT NULL,
    mod_reports boolean NOT NULL,
    mod_standalone_reports boolean,
    reports_entities text,
    id character varying(255) NOT NULL
);


ALTER TABLE public."sys_set_dataexplorer#76c80fb0" OWNER TO molgenis;

--
-- Name: acl_class id; Type: DEFAULT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_class ALTER COLUMN id SET DEFAULT nextval('public.acl_class_id_seq'::regclass);


--
-- Name: acl_entry id; Type: DEFAULT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_entry ALTER COLUMN id SET DEFAULT nextval('public.acl_entry_id_seq'::regclass);


--
-- Name: acl_object_identity id; Type: DEFAULT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_object_identity ALTER COLUMN id SET DEFAULT nextval('public.acl_object_identity_id_seq'::regclass);


--
-- Name: acl_sid id; Type: DEFAULT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_sid ALTER COLUMN id SET DEFAULT nextval('public.acl_sid_id_seq'::regclass);


--
-- Data for Name: Version; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."Version" (id) FROM stdin;
38
\.


--
-- Data for Name: acl_class; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public.acl_class (id, class, class_id_type) FROM stdin;
1	package	java.lang.String
2	entity-sys_job_ResourceDownloadJobExecution	java.lang.String
3	entity-sys_FileMeta	java.lang.String
4	entity-sys_ImportRun	java.lang.String
5	entity-sys_job_OneClickImportJobExecution	java.lang.String
6	entity-sys_job_ResourceDeleteJobExecution	java.lang.String
7	entity-sys_job_ResourceCopyJobExecution	java.lang.String
8	entityType	java.lang.String
9	plugin	java.lang.String
\.


--
-- Data for Name: acl_entry; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public.acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) FROM stdin;
1	117	0	2	4	t	f	f
2	102	0	3	4	t	f	f
3	108	0	2	4	t	f	f
4	3	0	2	4	t	f	f
5	97	0	3	4	t	f	f
6	106	0	2	4	t	f	f
7	113	0	4	4	t	f	f
9	39	0	2	4	t	f	f
10	39	1	4	8	t	f	f
11	110	0	5	4	t	f	f
12	54	0	5	4	t	f	f
13	94	0	5	4	t	f	f
14	13	0	5	4	t	f	f
15	114	0	5	4	t	f	f
16	116	0	4	4	t	f	f
17	115	0	4	4	t	f	f
18	34	0	4	8	t	f	f
19	31	0	4	8	t	f	f
20	56	0	4	8	t	f	f
21	9	0	3	4	t	f	f
22	118	0	4	4	t	f	f
23	4	0	5	4	t	f	f
24	42	0	2	4	t	f	f
25	19	0	2	4	t	f	f
27	15	0	3	4	t	f	f
28	15	1	6	8	t	f	f
29	75	0	2	4	t	f	f
30	92	0	5	4	t	f	f
31	50	0	4	8	t	f	f
32	33	0	4	8	t	f	f
33	120	0	6	4	t	f	f
34	65	0	6	8	t	f	f
35	1	0	3	1	t	f	f
36	111	0	6	4	t	f	f
37	122	0	6	4	t	f	f
38	71	0	6	8	t	f	f
39	66	0	6	8	t	f	f
40	123	0	1	8	t	f	f
41	124	0	1	8	t	f	f
42	125	0	1	8	t	f	f
43	126	0	1	8	t	f	f
44	127	0	1	8	t	f	f
45	128	0	1	8	t	f	f
46	129	0	1	8	t	f	f
47	130	0	1	8	t	f	f
48	131	0	1	8	t	f	f
49	132	0	1	8	t	f	f
50	133	0	1	8	t	f	f
51	134	0	1	8	t	f	f
52	135	0	1	8	t	f	f
53	136	0	1	8	t	f	f
54	137	0	1	8	t	f	f
55	138	0	1	8	t	f	f
56	139	0	1	8	t	f	f
57	140	0	1	8	t	f	f
58	141	0	1	8	t	f	f
59	142	0	1	8	t	f	f
60	143	0	1	8	t	f	f
61	144	0	1	8	t	f	f
62	145	0	1	8	t	f	f
63	146	0	1	8	t	f	f
64	147	0	1	8	t	f	f
65	148	0	1	8	t	f	f
66	149	0	1	8	t	f	f
67	150	0	1	8	t	f	f
68	151	0	1	8	t	f	f
69	152	0	1	8	t	f	f
70	153	0	1	8	t	f	f
71	154	0	1	8	t	f	f
72	155	0	1	8	t	f	f
73	156	0	1	8	t	f	f
74	157	0	1	8	t	f	f
75	158	0	1	8	t	f	f
76	159	0	1	8	t	f	f
77	160	0	1	8	t	f	f
78	161	0	1	8	t	f	f
79	162	0	1	8	t	f	f
80	163	0	1	8	t	f	f
81	164	0	7	8	t	f	f
82	168	0	7	16	t	f	f
83	169	0	7	8	t	f	f
\.


--
-- Data for Name: acl_object_identity; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public.acl_object_identity (id, object_id_class, object_id_identity, parent_object, owner_sid, entries_inheriting) FROM stdin;
2	1	sys_sec	1	1	t
164	4	aaaac3fyime3hzw2vuwyxoyaae	\N	7	t
5	1	sys_job	1	1	t
6	1	sys_mail	1	1	t
7	1	sys_set	1	1	t
8	1	sys_scr	1	1	t
10	1	sys_idx	1	1	t
11	1	sys_sec_oidc	2	1	t
12	1	sys_map	1	1	t
14	1	sys_dec	1	1	t
16	8	sys_idx_IndexActionGroup	10	1	t
17	8	sys_StaticContent	1	1	t
18	8	sys_scr_ScriptType	8	1	t
20	8	sys_job_JobExecution	5	1	t
21	8	sys_ont_Ontology	9	1	t
22	8	sys_Questionnaire	1	1	t
23	8	sys_scr_ScriptParameter	8	1	t
24	8	sys_ont_TermFrequency	9	1	t
25	8	sys_Plugin	1	1	t
26	8	sys_md_Tag	15	1	t
27	8	sys_ont_OntologyTermNodePath	9	1	t
28	8	sys_set_settings	7	1	t
29	8	sys_genomebrowser_GenomeBrowserAttributes	4	1	t
30	8	sys_ont_OntologyTermSynonym	9	1	t
32	8	sys_dec_DynamicDecorator	14	1	t
35	8	sys_beacons_BeaconOrganization	3	1	t
36	8	sys_sec_RecoveryCode	2	1	t
37	8	sys_sec_oidc_OidcClient	11	1	t
38	8	sys_sec_User	2	1	t
40	8	sys_sec_UserSecret	2	1	t
41	8	sys_ont_OntologyTermDynamicAnnotation	9	1	t
43	8	sys_md_Property	15	1	t
44	8	sys_negotiator_NegotiatorConfig	13	1	t
45	8	sys_App	1	1	t
46	8	sys_map_AttributeMapping	12	1	t
47	8	sys_sec_oidc_OidcUserMapping	11	1	t
48	8	sys_job_SortaJobExecution	5	1	t
49	8	sys_job_ScriptJobExecution	5	1	t
165	1	it	\N	7	t
51	8	sys_set_OpenCpuSettings	7	1	t
52	8	sys_set_StyleSheet	7	1	t
53	8	sys_dec_DecoratorParameters	14	1	t
166	1	it_emx	165	7	t
55	8	sys_sec_PasswordResetToken	2	1	t
167	1	it_emx_autoid	166	7	t
57	8	sys_sec_Token	2	1	t
58	8	sys_idx_IndexAction	10	1	t
59	8	sys_set_auth	7	1	t
60	8	sys_job_IndexJobExecution	5	1	t
61	8	sys_set_app	7	1	t
62	8	sys_ont_OntologyTerm	9	1	t
63	8	sys_md_Package	15	1	t
64	8	sys_job_FileIngestJobExecution	5	1	t
168	8	it_emx_autoid_testAutoId	167	7	t
67	8	sys_job_AmazonBucketJobExecution	5	1	t
68	8	sys_scr_Script	8	1	t
69	8	sys_map_EntityMapping	12	1	t
70	8	sys_job_MappingJobExecution	5	1	t
72	8	sys_set_MailSettings	7	1	t
73	8	sys_md_EntityType	15	1	t
74	8	sys_mail_JavaMailProperty	6	1	t
76	8	sys_map_MappingTarget	12	1	t
77	8	sys_sec_Group	2	1	t
78	8	sys_map_MappingProject	12	1	t
79	8	sys_job_ScheduledJobType	5	1	t
80	8	sys_sec_Role	2	1	t
81	8	sys_beacons_BeaconDataset	3	1	t
82	8	sys_md_Attribute	15	1	t
83	8	sys_job_ScheduledJob	5	1	t
84	8	sys_sec_MembershipInvitation	2	1	t
85	8	sys_sec_RoleMembership	2	1	t
86	8	sys_negotiator_NegotiatorEntityConfig	13	1	t
87	8	sys_genomebrowser_GenomeBrowserSettings	4	1	t
88	8	sys_beacons_Beacon	3	1	t
89	9	scheduledjobs	\N	1	t
90	9	tagwizard	\N	1	t
91	9	references	\N	1	t
93	9	sorta	\N	1	t
95	9	swagger	\N	1	t
96	9	usermanager	\N	1	t
98	9	contact	\N	1	t
99	9	mappingservice	\N	1	t
100	9	menumanager	\N	1	t
101	9	scripts	\N	1	t
103	9	news	\N	1	t
104	9	logmanager	\N	1	t
105	9	permissionmanager	\N	1	t
107	9	thememanager	\N	1	t
109	9	settings	\N	1	t
112	9	void	\N	1	t
119	9	background	\N	1	t
121	9	appmanager	\N	1	t
117	9	home	\N	1	t
102	9	useraccount	\N	1	t
108	9	app	\N	1	t
3	1	sys_beacons	1	1	t
97	9	feedback	\N	1	t
106	9	redirect	\N	1	t
113	9	importwizard	\N	1	t
39	8	sys_FreemarkerTemplate	1	1	t
110	9	dataexplorer	\N	1	t
54	8	sys_set_dataexplorer	7	1	t
94	9	directory	\N	1	t
13	1	sys_negotiator	1	1	t
114	9	searchAll	\N	1	t
116	9	data-row-edit	\N	1	t
115	9	jobs	\N	1	t
34	8	sys_ImportRun	1	1	t
31	8	sys_ont_MatchingTaskContent	9	1	t
56	8	sys_ont_OntologyTermHit	9	1	t
9	1	sys_ont	1	1	t
118	9	questionnaires	\N	1	t
4	1	sys_genomebrowser	1	1	t
42	8	sys_Language	1	1	t
19	8	sys_L10nString	1	1	t
15	1	sys_md	1	1	t
75	8	sys_dec_DecoratorConfiguration	14	1	t
92	9	navigator	\N	1	t
50	8	sys_job_ResourceDownloadJobExecution	5	1	t
33	8	sys_FileMeta	1	1	t
120	9	one-click-importer	\N	1	t
65	8	sys_job_OneClickImportJobExecution	5	1	t
1	1	sys	\N	1	t
111	9	security-ui	\N	1	t
122	9	metadata-manager	\N	1	t
71	8	sys_job_ResourceCopyJobExecution	5	1	t
66	8	sys_job_ResourceDeleteJobExecution	5	1	t
123	3	aaaac3fyigv4bzw2vuwyxoyaai	\N	1	t
124	3	aaaac3fyigwadzw2vuwyxoyaae	\N	1	t
125	3	aaaac3fyigwdpzw2vuwyxoyaai	\N	1	t
126	3	aaaac3fyigwgfzw2vuwyxoyaae	\N	1	t
127	3	aaaac3fyigwjnzw2vuwyxoyaai	\N	1	t
128	3	aaaac3fyigwofzw2vuwyxoyaae	\N	1	t
129	3	aaaac3fyigwrvzw2vuwyxoyaai	\N	1	t
130	3	aaaac3fyigwvhzw2vuwyxoyaai	\N	1	t
131	3	aaaac3fyigwytzw2vuwyxoyaai	\N	1	t
132	3	aaaac3fyigw3pzw2vuwyxoyaae	\N	1	t
133	3	aaaac3fyigw6tzw2vuwyxoyaai	\N	1	t
134	3	aaaac3fyigxa7zw2vuwyxoyaae	\N	1	t
135	3	aaaac3fyigxefzw2vuwyxoyaai	\N	1	t
136	3	aaaac3fyigxgtzw2vuwyxoyaae	\N	1	t
137	3	aaaac3fyigxjpzw2vuwyxoyaai	\N	1	t
138	3	aaaac3fyigxmbzw2vuwyxoyaae	\N	1	t
139	3	aaaac3fyigxpnzw2vuwyxoyaai	\N	1	t
140	3	aaaac3fyigxtfzw2vuwyxoyaae	\N	1	t
169	3	aaaac3fyiq74lzw2vuwyxoyaae	\N	7	t
141	3	aaaac3fyigxwpzw2vuwyxoyaai	\N	1	t
142	3	aaaac3fyigxz5zw2vuwyxoyaae	\N	1	t
143	3	aaaac3fyigx5hzw2vuwyxoyaai	\N	1	t
144	3	aaaac3fyigyahzw2vuwyxoyaae	\N	1	t
145	3	aaaac3fyigyddzw2vuwyxoyaai	\N	1	t
146	3	aaaac3fyigyftzw2vuwyxoyaae	\N	1	t
147	3	aaaac3fyigyijzw2vuwyxoyaai	\N	1	t
148	3	aaaac3fyigykrzw2vuwyxoyaae	\N	1	t
149	3	aaaac3fyigynlzw2vuwyxoyaai	\N	1	t
150	3	aaaac3fyigyqhzw2vuwyxoyaae	\N	1	t
151	3	aaaac3fyigytvzw2vuwyxoyaai	\N	1	t
152	3	aaaac3fyigywjzw2vuwyxoyaae	\N	1	t
153	3	aaaac3fyigyzdzw2vuwyxoyaai	\N	1	t
154	3	aaaac3fyigy3vzw2vuwyxoyaae	\N	1	t
155	3	aaaac3fyigy6hzw2vuwyxoyaai	\N	1	t
156	3	aaaac3fyigzanzw2vuwyxoyaae	\N	1	t
157	3	aaaac3fyigzdfzw2vuwyxoyaai	\N	1	t
158	3	aaaac3fyigzfnzw2vuwyxoyaae	\N	1	t
159	3	aaaac3fyigzihzw2vuwyxoyaai	\N	1	t
160	3	aaaac3fyigzkrzw2vuwyxoyaae	\N	1	t
161	3	aaaac3fyigznpzw2vuwyxoyaai	\N	1	t
162	3	aaaac3fyigzqxzw2vuwyxoyaae	\N	1	t
163	3	aaaac3fyigzudzw2vuwyxoyaai	\N	1	t
\.


--
-- Data for Name: acl_sid; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public.acl_sid (id, principal, sid) FROM stdin;
1	f	ROLE_SYSTEM
2	f	ROLE_ANONYMOUS
3	f	ROLE_USER
4	f	ROLE_EDITOR
5	f	ROLE_VIEWER
6	f	ROLE_MANAGER
7	t	admin
\.


--
-- Data for Name: it_emx_autoid_testAutoId#46feeb51; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."it_emx_autoid_testAutoId#46feeb51" (id, "firstName", "lastName") FROM stdin;
aaaac3fyimgpxzw2vuwyxoyaam	John	Doe
aaaac3fyimgqbzw2vuwyxoyaae	Jane	Doe
aaaac3fyimgqbzw2vuwyxoyaai	Mary	Doe
aaaac3fyimgqdzw2vuwyxoyaae	Bob	Doe
\.


--
-- Data for Name: sys_App#1723bf4f; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_App#1723bf4f" (id, label, description, "isActive", "appVersion", "apiDependency", "templateContent", "resourceFolder", name, "appConfig", "includeMenuAndFooter") FROM stdin;
\.


--
-- Data for Name: sys_FileMeta#76d84794; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_FileMeta#76d84794" (id, filename, "contentType", size, url) FROM stdin;
aaaac3fyigv4bzw2vuwyxoyaai	bootstrap-molgenis-red.min.css	css	204	/files/aaaac3fyigv4bzw2vuwyxoyaai
aaaac3fyigwadzw2vuwyxoyaae	bootstrap-molgenis-red.min.css	css	139200	/files/aaaac3fyigwadzw2vuwyxoyaae
aaaac3fyigwdpzw2vuwyxoyaai	bootstrap-spacelab.min.css	css	127143	/files/aaaac3fyigwdpzw2vuwyxoyaai
aaaac3fyigwgfzw2vuwyxoyaae	bootstrap-spacelab.min.css	css	156866	/files/aaaac3fyigwgfzw2vuwyxoyaae
aaaac3fyigwjnzw2vuwyxoyaai	bootstrap-cerulean.min.css	css	124177	/files/aaaac3fyigwjnzw2vuwyxoyaai
aaaac3fyigwofzw2vuwyxoyaae	bootstrap-cerulean.min.css	css	153528	/files/aaaac3fyigwofzw2vuwyxoyaae
aaaac3fyigwrvzw2vuwyxoyaai	bootstrap-paper.min.css	css	135263	/files/aaaac3fyigwrvzw2vuwyxoyaai
aaaac3fyigwvhzw2vuwyxoyaai	bootstrap-readable.min.css	css	120485	/files/aaaac3fyigwvhzw2vuwyxoyaai
aaaac3fyigwytzw2vuwyxoyaai	bootstrap-slate.min.css	css	137012	/files/aaaac3fyigwytzw2vuwyxoyaai
aaaac3fyigw3pzw2vuwyxoyaae	bootstrap-slate.min.css	css	162484	/files/aaaac3fyigw3pzw2vuwyxoyaae
aaaac3fyigw6tzw2vuwyxoyaai	bootstrap-molgenis-blue.min.css	css	204	/files/aaaac3fyigw6tzw2vuwyxoyaai
aaaac3fyigxa7zw2vuwyxoyaae	bootstrap-molgenis-blue.min.css	css	139153	/files/aaaac3fyigxa7zw2vuwyxoyaae
aaaac3fyigxefzw2vuwyxoyaai	bootstrap-cyborg.min.css	css	120870	/files/aaaac3fyigxefzw2vuwyxoyaai
aaaac3fyigxgtzw2vuwyxoyaae	bootstrap-cyborg.min.css	css	153252	/files/aaaac3fyigxgtzw2vuwyxoyaae
aaaac3fyigxjpzw2vuwyxoyaai	bootstrap-flatly.min.css	css	122915	/files/aaaac3fyigxjpzw2vuwyxoyaai
aaaac3fyigxmbzw2vuwyxoyaae	bootstrap-flatly.min.css	css	153224	/files/aaaac3fyigxmbzw2vuwyxoyaae
aaaac3fyigxpnzw2vuwyxoyaai	bootstrap-yeti.min.css	css	123605	/files/aaaac3fyigxpnzw2vuwyxoyaai
aaaac3fyigxtfzw2vuwyxoyaae	bootstrap-yeti.min.css	css	156591	/files/aaaac3fyigxtfzw2vuwyxoyaae
aaaac3fyigxwpzw2vuwyxoyaai	bootstrap-darkly.min.css	css	123224	/files/aaaac3fyigxwpzw2vuwyxoyaai
aaaac3fyigxz5zw2vuwyxoyaae	bootstrap-darkly.min.css	css	153162	/files/aaaac3fyigxz5zw2vuwyxoyaae
aaaac3fyigx5hzw2vuwyxoyaai	bootstrap-cosmo.min.css	css	120924	/files/aaaac3fyigx5hzw2vuwyxoyaai
aaaac3fyigyahzw2vuwyxoyaae	bootstrap-cosmo.min.css	css	145050	/files/aaaac3fyigyahzw2vuwyxoyaae
aaaac3fyigyddzw2vuwyxoyaai	bootstrap-journal.min.css	css	119803	/files/aaaac3fyigyddzw2vuwyxoyaai
aaaac3fyigyftzw2vuwyxoyaae	bootstrap-journal.min.css	css	151218	/files/aaaac3fyigyftzw2vuwyxoyaae
aaaac3fyigyijzw2vuwyxoyaai	bootstrap-united.min.css	css	118795	/files/aaaac3fyigyijzw2vuwyxoyaai
aaaac3fyigykrzw2vuwyxoyaae	bootstrap-united.min.css	css	150997	/files/aaaac3fyigykrzw2vuwyxoyaae
aaaac3fyigynlzw2vuwyxoyaai	bootstrap-lumen.min.css	css	125853	/files/aaaac3fyigynlzw2vuwyxoyaai
aaaac3fyigyqhzw2vuwyxoyaae	bootstrap-lumen.min.css	css	155804	/files/aaaac3fyigyqhzw2vuwyxoyaae
aaaac3fyigytvzw2vuwyxoyaai	bootstrap-superhero.min.css	css	121743	/files/aaaac3fyigytvzw2vuwyxoyaai
aaaac3fyigywjzw2vuwyxoyaae	bootstrap-superhero.min.css	css	153227	/files/aaaac3fyigywjzw2vuwyxoyaae
aaaac3fyigyzdzw2vuwyxoyaai	bootstrap-sandstone.min.css	css	120769	/files/aaaac3fyigyzdzw2vuwyxoyaai
aaaac3fyigy3vzw2vuwyxoyaae	bootstrap-sandstone.min.css	css	152829	/files/aaaac3fyigy3vzw2vuwyxoyaae
aaaac3fyigy6hzw2vuwyxoyaai	bootstrap-basic.min.css	css	19963	/files/aaaac3fyigy6hzw2vuwyxoyaai
aaaac3fyigzanzw2vuwyxoyaae	bootstrap-basic.min.css	css	144877	/files/aaaac3fyigzanzw2vuwyxoyaae
aaaac3fyigzdfzw2vuwyxoyaai	bootstrap-molgenis-green.min.css	css	204	/files/aaaac3fyigzdfzw2vuwyxoyaai
aaaac3fyigzfnzw2vuwyxoyaae	bootstrap-molgenis-green.min.css	css	139145	/files/aaaac3fyigzfnzw2vuwyxoyaae
aaaac3fyigzihzw2vuwyxoyaai	bootstrap-simplex.min.css	css	122747	/files/aaaac3fyigzihzw2vuwyxoyaai
aaaac3fyigzkrzw2vuwyxoyaae	bootstrap-simplex.min.css	css	153965	/files/aaaac3fyigzkrzw2vuwyxoyaae
aaaac3fyigznpzw2vuwyxoyaai	bootstrap-molgenis.min.css	css	204	/files/aaaac3fyigznpzw2vuwyxoyaai
aaaac3fyigzqxzw2vuwyxoyaae	bootstrap-molgenis.min.css	css	140711	/files/aaaac3fyigzqxzw2vuwyxoyaae
aaaac3fyigzudzw2vuwyxoyaai	bootstrap-ibd.min.css	css	6764	/files/aaaac3fyigzudzw2vuwyxoyaai
aaaac3fyiq74lzw2vuwyxoyaae	testfile	text/plain	15	/api/files/aaaac3fyiq74lzw2vuwyxoyaae?alt=media
\.


--
-- Data for Name: sys_FreemarkerTemplate#1b0d9d12; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_FreemarkerTemplate#1b0d9d12" (id, "Name", "Value") FROM stdin;
\.


--
-- Data for Name: sys_ImportRun#5ed65642; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ImportRun#5ed65642" (id, "startDate", "endDate", username, status, message, progress, "importedEntities", notify) FROM stdin;
aaaac3fyime3hzw2vuwyxoyaae	2019-08-22 07:38:16+00	2019-08-22 07:38:18+00	admin	FINISHED	Imported 4 it_emx_autoid_testAutoId entities.<br />	0	it_emx_autoid_testAutoId	f
\.


--
-- Data for Name: sys_L10nString#95a21e09; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_L10nString#95a21e09" (id, msgid, namespace, description, en, nl, de, es, it, pt, fr, xx) FROM stdin;
PRM02	PRM02	api-permissions	\N	'and' rsql operator is not supported for this API.	\N	\N	\N	\N	\N	\N	\N
PRM01	PRM01	api-permissions	\N	Unknown field ''{0}'' in query, only ''user'' and ''role'' are supported.	\N	\N	\N	\N	\N	\N	\N
PRM04	PRM04	api-permissions	\N	Combination of "includeInheritance" and paging is not supported.	\N	\N	\N	\N	\N	\N	\N
PRM03	PRM03	api-permissions	\N	Please provide both page and pageSize.	\N	\N	\N	\N	\N	\N	\N
PRM06	PRM06	api-permissions	\N	Please provide a 'user' or 'role' for this operation.	\N	\N	\N	\N	\N	\N	\N
PRM05	PRM05	api-permissions	\N	Please provide either a 'user' or a 'role', instead of both.	\N	\N	\N	\N	\N	\N	\N
PRM07	PRM07	api-permissions	\N	An error occured while parsing the RSQL query: ''{0}''.	\N	\N	\N	\N	\N	\N	\N
import-input-label	import-input-label	one-click-importer	\N	Select a file to import	Selecteer een bestand om te importeren	\N	\N	\N	\N	\N	\N
file-types	file-types	one-click-importer	\N	Supported file types	Ondersteunde bestandstypen	\N	\N	\N	\N	\N	\N
error-message-prefix	error-message-prefix	one-click-importer	\N	Import failed	Fout tijdens het importeren	\N	\N	\N	\N	\N	\N
import-list-header	import-list-header	one-click-importer	\N	Imports	Geïmporteerde bestanden	\N	\N	\N	\N	\N	\N
security-ui-add-group	security-ui-add-group	security-ui	\N	Add Group	Nieuwe Groep	\N	\N	\N	\N	\N	\N
security-ui-btn-edit	security-ui-btn-edit	security-ui	\N	Edit	Bewerken	\N	\N	\N	\N	\N	\N
security-ui-group-attribute-label-name	security-ui-group-attribute-label-name	security-ui	\N	Group name	Naam van de Groep	\N	\N	\N	\N	\N	\N
security-ui-btn-cancel	security-ui-btn-cancel	security-ui	\N	Cancel	Annuleren	\N	\N	\N	\N	\N	\N
security-ui-delete-confirmation-ok-text	security-ui-delete-confirmation-ok-text	security-ui	\N	Delete	Verwijder	\N	\N	\N	\N	\N	\N
security-ui-group-attribute-name-taken-message	security-ui-group-attribute-name-taken-message	security-ui	\N	This group name is not available any more, please choose a different name.	Deze groepsnaam is niet meer beschikbaar, kies a.u.b. een andere naam.	\N	\N	\N	\N	\N	\N
security-ui-group-btn-creating-group	security-ui-group-btn-creating-group	security-ui	\N	Creating	Maken	\N	\N	\N	\N	\N	\N
security-ui-group-attribute-name-name	security-ui-group-attribute-name-name	security-ui	\N	Group Identifier	Groep identificatie	\N	\N	\N	\N	\N	\N
security-ui-groups-header	security-ui-groups-header	security-ui	\N	Groups	Groepen	\N	\N	\N	\N	\N	\N
security-ui-delete-confirmation-cancel-text	security-ui-delete-confirmation-cancel-text	security-ui	\N	Cancel	Annuleer	\N	\N	\N	\N	\N	\N
security-ui-no-available-users	security-ui-no-available-users	security-ui	\N	No available users	Geen gebruikers beschikbaar	\N	\N	\N	\N	\N	\N
security-ui-members-header	security-ui-members-header	security-ui	\N	Members	Leden	\N	\N	\N	\N	\N	\N
security-ui-membership-attribute-role	security-ui-membership-attribute-role	security-ui	\N	Role	Rol	\N	\N	\N	\N	\N	\N
security-ui-btn-adding-member	security-ui-btn-adding-member	security-ui	\N	Adding	Toevoegen	\N	\N	\N	\N	\N	\N
security-ui-member-details-header	security-ui-member-details-header	security-ui	\N	Member details	Lidmaatschapsgegevens	\N	\N	\N	\N	\N	\N
security-ui-group-attribute-label-placeholder	security-ui-group-attribute-label-placeholder	security-ui	\N	My Group	Mijn Groep	\N	\N	\N	\N	\N	\N
security-ui-add-group-title	security-ui-add-group-title	security-ui	\N	Create group	Nieuwe groep	\N	\N	\N	\N	\N	\N
security-ui-groups-page-title	security-ui-groups-page-title	security-ui	\N	Groups overview	Groepen overzicht	\N	\N	\N	\N	\N	\N
security-ui-member-removing	security-ui-member-removing	security-ui	\N	Removing	Verwijderen	\N	\N	\N	\N	\N	\N
security-ui-member-remove	security-ui-member-remove	security-ui	\N	Remove	Verwijderen	\N	\N	\N	\N	\N	\N
security-ui-delete-confirmation-text	security-ui-delete-confirmation-text	security-ui	\N	Are you sure you want to permanently delete this group?	Weet je zeker dat je deze groep permanent wilt verwijderen?	\N	\N	\N	\N	\N	\N
security-ui-group-btn-create-group	security-ui-group-btn-create-group	security-ui	\N	Create	Maak Groep	\N	\N	\N	\N	\N	\N
security-ui-membership-attribute-user	security-ui-membership-attribute-user	security-ui	\N	User	Gebruiker	\N	\N	\N	\N	\N	\N
security-ui-group-attribute-name-description	security-ui-group-attribute-name-description	security-ui	\N	Name as used in URL	Naam zoals gebruikt in linkjes	\N	\N	\N	\N	\N	\N
security-ui-no-groups-found	security-ui-no-groups-found	security-ui	\N	No groups available	Geen groepen beschikbaar	\N	\N	\N	\N	\N	\N
security-ui-group-attribute-name-placeholder	security-ui-group-attribute-name-placeholder	security-ui	\N	my-group	mijn-groep	\N	\N	\N	\N	\N	\N
security-ui-add-member	security-ui-add-member	security-ui	\N	Add Member	Nieuw Lid	\N	\N	\N	\N	\N	\N
security-ui-delete-confirmation-title	security-ui-delete-confirmation-title	security-ui	\N	Confirm Deletion	Bevestig Verwijderen	\N	\N	\N	\N	\N	\N
security-ui-please-select-a-user	security-ui-please-select-a-user	security-ui	\N	Please select a user	Selecteer a.u.b. een gebruiker	\N	\N	\N	\N	\N	\N
security-ui-btn-add-member	security-ui-btn-add-member	security-ui	\N	Add member	Voeg lid toe	\N	\N	\N	\N	\N	\N
security-ui-breadcrumb-groups	security-ui-breadcrumb-groups	security-ui	\N	Groups	Groepen	\N	\N	\N	\N	\N	\N
security-ui-add-member-title	security-ui-add-member-title	security-ui	\N	Add Member	Nieuw Lid	\N	\N	\N	\N	\N	\N
security-ui-group-attribute-label-description	security-ui-group-attribute-label-description	security-ui	\N	The group name as shown in the interface	De naam van de groep op het scherm	\N	\N	\N	\N	\N	\N
security-ui-members-page-title	security-ui-members-page-title	security-ui	\N	Group	Groep	\N	\N	\N	\N	\N	\N
confirm-before-leaving-text	confirm-before-leaving-text	metadata-manager	\N	All unsaved changes will be lost, are you sure you want to continue?	Alle wijzigingen die niet zijn opgeslagen raken verloren, weet je zeker dat je verder wilt?	\N	\N	\N	\N	\N	\N
confirm-before-delete-title	confirm-before-delete-title	metadata-manager	\N	You are about to delete	Je staat op het punt om het volgende te verwijderen	\N	\N	\N	\N	\N	\N
delete-entity-button	delete-entity-button	metadata-manager	\N	Delete entity	Verwijder Entiteit	\N	\N	\N	\N	\N	\N
attribute-edit-form-unique-label	attribute-edit-form-unique-label	metadata-manager	\N	Unique	Uniek	\N	\N	\N	\N	\N	\N
confirm-before-delete-text	confirm-before-delete-text	metadata-manager	\N	Are you sure you want to continue?	Weet je zeker dat je verder wil?	\N	\N	\N	\N	\N	\N
attribute-edit-form-parent-label	attribute-edit-form-parent-label	metadata-manager	\N	Parent	Ouder	\N	\N	\N	\N	\N	\N
application-title	application-title	metadata-manager	\N	Metadata manager	Metadata manager	\N	\N	\N	\N	\N	\N
attribute-edit-form-order-by-label	attribute-edit-form-order-by-label	metadata-manager	\N	Order by	Gesorteerd op	\N	\N	\N	\N	\N	\N
confirm-before-leaving-cancel	confirm-before-leaving-cancel	metadata-manager	\N	No, stay	Nee, blijf	\N	\N	\N	\N	\N	\N
entity-edit-form-label-label	entity-edit-form-label-label	metadata-manager	\N	Label	Label	\N	\N	\N	\N	\N	\N
entity-edit-form-id-attribute-label	entity-edit-form-id-attribute-label	metadata-manager	\N	ID Attribute	ID attribuut	\N	\N	\N	\N	\N	\N
attribute-edit-form-mapped-by-placeholder	attribute-edit-form-mapped-by-placeholder	metadata-manager	\N	Select a reference entity...	Selecteer een referentie entiteit...	\N	\N	\N	\N	\N	\N
attribute-edit-form-maximum-range-placeholder	attribute-edit-form-maximum-range-placeholder	metadata-manager	\N	Add a maximum range...	Voeg een maximale grens toe...	\N	\N	\N	\N	\N	\N
attribute-edit-form-name-label	attribute-edit-form-name-label	metadata-manager	\N	Name	Naam	\N	\N	\N	\N	\N	\N
attribute-edit-form-reference-entity-placeholder	attribute-edit-form-reference-entity-placeholder	metadata-manager	\N	Select a reference entity...	Selecteer een referentie entiteit...	\N	\N	\N	\N	\N	\N
attribute-edit-form-name-placeholder	attribute-edit-form-name-placeholder	metadata-manager	\N	Add a unique name...	Voeg een unieke naam toe...	\N	\N	\N	\N	\N	\N
entity-edit-form-extends-label	entity-edit-form-extends-label	metadata-manager	\N	Extends	Verlengt	\N	\N	\N	\N	\N	\N
save-changes-button	save-changes-button	metadata-manager	\N	Save all changes	Sla alles op	\N	\N	\N	\N	\N	\N
attribute-edit-form-visible-expression-placeholder	attribute-edit-form-visible-expression-placeholder	metadata-manager	\N	Example: $('attributeX').value() > 5	Voorbeeld: $('attribuutX').value() > 5	\N	\N	\N	\N	\N	\N
entity-edit-form-abstract-label	entity-edit-form-abstract-label	metadata-manager	\N	Abstract	Abstract	\N	\N	\N	\N	\N	\N
attribute-edit-form-enum-options-label	attribute-edit-form-enum-options-label	metadata-manager	\N	Enum options	Enum opties	\N	\N	\N	\N	\N	\N
attribute-edit-form-validation-expression-placeholder	attribute-edit-form-validation-expression-placeholder	metadata-manager	\N	Example: $('attributeX').isNull().not()	Voorbeeld: $('attribuutX').isNull().not()	\N	\N	\N	\N	\N	\N
attribute-edit-form-enum-options-placeholder	attribute-edit-form-enum-options-placeholder	metadata-manager	\N	option1,option2,option3...	optie1,optie2,optie3...	\N	\N	\N	\N	\N	\N
attribute-edit-form-label-label	attribute-edit-form-label-label	metadata-manager	\N	Label	Label	\N	\N	\N	\N	\N	\N
attribute-edit-form-visible-expression-label	attribute-edit-form-visible-expression-label	metadata-manager	\N	Visible expression	Zichtbaar expressie	\N	\N	\N	\N	\N	\N
attribute-edit-form-computed-expression-label	attribute-edit-form-computed-expression-label	metadata-manager	\N	Computed value expression	Uitgerekende waarde expressie	\N	\N	\N	\N	\N	\N
entity-edit-form-package-label	entity-edit-form-package-label	metadata-manager	\N	Package	Package	\N	\N	\N	\N	\N	\N
entity-edit-form-package-placeholder	entity-edit-form-package-placeholder	metadata-manager	\N	Select a Package...	Selecteer een Package...	\N	\N	\N	\N	\N	\N
attribute-edit-form-reference-entity-label	attribute-edit-form-reference-entity-label	metadata-manager	\N	Reference entity	Referentie entiteit	\N	\N	\N	\N	\N	\N
attribute-edit-form-nullable-expression-label	attribute-edit-form-nullable-expression-label	metadata-manager	\N	Nullable expression	Nulbare expressie	\N	\N	\N	\N	\N	\N
selected-attribute-label	selected-attribute-label	metadata-manager	\N	Attribute	Attribuut	\N	\N	\N	\N	\N	\N
attribute-edit-form-auto-label	attribute-edit-form-auto-label	metadata-manager	\N	Auto	Automatisch	\N	\N	\N	\N	\N	\N
compound-attribute-text	compound-attribute-text	metadata-manager	\N	Parent attributes from	Ouder attributen van	\N	\N	\N	\N	\N	\N
toast-label-required-id-hidden	toast-label-required-id-hidden	metadata-manager	\N	Label attribute cannot be empty because the ID attribute is not visible.	Het label attribuut mag niet leeg zijn want het ID attribuut is onzichtbaar	\N	\N	\N	\N	\N	\N
attribute-edit-form-order-by-placeholder	attribute-edit-form-order-by-placeholder	metadata-manager	\N	<attribute_name>;ASC/DESC	<attribuut_naam>;ASC/DESC	\N	\N	\N	\N	\N	\N
attribute-edit-form-visible-label	attribute-edit-form-visible-label	metadata-manager	\N	Visible	Zichtbaar	\N	\N	\N	\N	\N	\N
no-entity-type-selected-text	no-entity-type-selected-text	metadata-manager	\N	Select an EntityType to edit	Selecteer een entiteit om te wijzigen	\N	\N	\N	\N	\N	\N
attribute-edit-form-mapped-by-label	attribute-edit-form-mapped-by-label	metadata-manager	\N	Mapped by	Gerefereerd door	\N	\N	\N	\N	\N	\N
attribute-edit-form-cascade-delete-label	attribute-edit-form-cascade-delete-label	metadata-manager	\N	Cascade delete	Cascade verwijderen	\N	\N	\N	\N	\N	\N
button-group-aria-label	button-group-aria-label	metadata-manager	\N	Toolbar with button groups	Gereedschaps balk met knop groepjes	\N	\N	\N	\N	\N	\N
confirm-before-delete-confirm	confirm-before-delete-confirm	metadata-manager	\N	Yes, delete	Ja, verwijder	\N	\N	\N	\N	\N	\N
entity-edit-form-extends-placeholder	entity-edit-form-extends-placeholder	metadata-manager	\N	Select an Entity...	Selecteer een entiteit...	\N	\N	\N	\N	\N	\N
attribute-edit-form-description-label	attribute-edit-form-description-label	metadata-manager	\N	Description	Omschrijving	\N	\N	\N	\N	\N	\N
attribute-edit-form-description-placeholder	attribute-edit-form-description-placeholder	metadata-manager	\N	Add a description...	Voeg een omschrijving toe...	\N	\N	\N	\N	\N	\N
entity-edit-form-lookup-attributes-placeholder	entity-edit-form-lookup-attributes-placeholder	metadata-manager	\N	Select attributes...	Selecteer attributen...	\N	\N	\N	\N	\N	\N
attribute-edit-form-default-value-placeholder	attribute-edit-form-default-value-placeholder	metadata-manager	\N	Add a default value...	Voeg een standaardwaarde toe...	\N	\N	\N	\N	\N	\N
attribute-edit-form-minimum-range-placeholder	attribute-edit-form-minimum-range-placeholder	metadata-manager	\N	Add a minimum range...	Voeg een minimale grens toe...	\N	\N	\N	\N	\N	\N
toast-id-required	toast-id-required	metadata-manager	\N	ID attribute cannot be empty.	Het ID attribuut mag niet leeg zijn	\N	\N	\N	\N	\N	\N
attribute-edit-form-label-placeholder	attribute-edit-form-label-placeholder	metadata-manager	\N	Add a label...	Voeg een label toe...	\N	\N	\N	\N	\N	\N
entity-edit-form-description-placeholder	entity-edit-form-description-placeholder	metadata-manager	\N	Add a description...	Voeg een omschrijving toe...	\N	\N	\N	\N	\N	\N
entity-edit-form-label-attribute-placeholder	entity-edit-form-label-attribute-placeholder	metadata-manager	\N	Select an attribute...	Selecteer een attribuut...	\N	\N	\N	\N	\N	\N
attribute-edit-form-minimum-range-label	attribute-edit-form-minimum-range-label	metadata-manager	\N	Minimum range	Minimale grens	\N	\N	\N	\N	\N	\N
entity-edit-form-description-label	entity-edit-form-description-label	metadata-manager	\N	Description	Omschrijving	\N	\N	\N	\N	\N	\N
confirm-before-leaving-title	confirm-before-leaving-title	metadata-manager	\N	There are unsaved changes	Er zijn wijzigingen die nog niet zijn opgeslagen	\N	\N	\N	\N	\N	\N
attribute-tree-title	attribute-tree-title	metadata-manager	\N	Attributes	Attributen	\N	\N	\N	\N	\N	\N
no-attribute-selected-text	no-attribute-selected-text	metadata-manager	\N	Select an attribute to edit	Selecteer een attribuut om te wijzigen	\N	\N	\N	\N	\N	\N
attribute-edit-form-default-value-label	attribute-edit-form-default-value-label	metadata-manager	\N	Default value	Standaardwaarde	\N	\N	\N	\N	\N	\N
attribute-edit-form-computed-expression-placeholder	attribute-edit-form-computed-expression-placeholder	metadata-manager	\N	Example: attributeX - attributeY	Voorbeeld: attribuutX - attribuutY	\N	\N	\N	\N	\N	\N
attribute-edit-form-nullable-label	attribute-edit-form-nullable-label	metadata-manager	\N	Nullable	Nulbaar	\N	\N	\N	\N	\N	\N
confirm-before-delete-cancel	confirm-before-delete-cancel	metadata-manager	\N	Cancel	annuleer	\N	\N	\N	\N	\N	\N
confirm-before-leaving-confirm	confirm-before-leaving-confirm	metadata-manager	\N	Yes	Ja	\N	\N	\N	\N	\N	\N
undo-changes-button	undo-changes-button	metadata-manager	\N	Undo all changes	Wijzigingen ongedaan maken	\N	\N	\N	\N	\N	\N
header-entity-select-placeholder	header-entity-select-placeholder	metadata-manager	\N	Select an Entity	Selecteer een entiteit	\N	\N	\N	\N	\N	\N
save-succes-message	save-succes-message	metadata-manager	\N	Successfully updated metadata for EntityType	Metadata succesvol opgeslagen voor Entiteit	\N	\N	\N	\N	\N	\N
entity-edit-form-id-attribute-placeholder	entity-edit-form-id-attribute-placeholder	metadata-manager	\N	Select an attribute...	Selecteer een attribuut...	\N	\N	\N	\N	\N	\N
entity-edit-form-label-attribute-label	entity-edit-form-label-attribute-label	metadata-manager	\N	Label attribute	Label attribuut	\N	\N	\N	\N	\N	\N
entity-edit-form-label-placeholder	entity-edit-form-label-placeholder	metadata-manager	\N	Add a label...	Voeg een label toe...	\N	\N	\N	\N	\N	\N
back-to-home-button	back-to-home-button	metadata-manager	\N	Back to home	Ga terug naar het menu	\N	\N	\N	\N	\N	\N
attribute-edit-form-type-placeholder	attribute-edit-form-type-placeholder	metadata-manager	\N	Select an attribute type...	Selecteer een attribuut type...	\N	\N	\N	\N	\N	\N
attribute-edit-form-aggregatable-label	attribute-edit-form-aggregatable-label	metadata-manager	\N	Aggregatable	Aggregeerbaar	\N	\N	\N	\N	\N	\N
attribute-edit-form-type-label	attribute-edit-form-type-label	metadata-manager	\N	Type	Type	\N	\N	\N	\N	\N	\N
entity-edit-form-lookup-attributes-label	entity-edit-form-lookup-attributes-label	metadata-manager	\N	Lookup attributes	Lookup attributen	\N	\N	\N	\N	\N	\N
attribute-edit-form-validation-expression-label	attribute-edit-form-validation-expression-label	metadata-manager	\N	Validation expression	Validatie expressie	\N	\N	\N	\N	\N	\N
attribute-edit-form-maximum-range-label	attribute-edit-form-maximum-range-label	metadata-manager	\N	Maximum range	Maximale grens	\N	\N	\N	\N	\N	\N
attribute-edit-form-parent-placeholder	attribute-edit-form-parent-placeholder	metadata-manager	\N	Select a compound attribute...	Selecteer een attribuut ouder...	\N	\N	\N	\N	\N	\N
attribute-edit-form-readonly-label	attribute-edit-form-readonly-label	metadata-manager	\N	Read-only	Alleen lezen	\N	\N	\N	\N	\N	\N
attribute-edit-form-nullable-expression-placeholder	attribute-edit-form-nullable-expression-placeholder	metadata-manager	\N	Example: $('attributeX').isNull()	Voorbeeld: $('attribuutX').isNull()	\N	\N	\N	\N	\N	\N
progress-copy-packages	progress-copy-packages	navigator	\N	Copying packages	Mappen aan het kopiëren	\N	\N	\N	\N	\N	\N
update-package-cancel-text	update-package-cancel-text	navigator	\N	Cancel	Annuleer	\N	\N	\N	\N	\N	\N
clear-button	clear-button	navigator	\N	Clear	Leeg maken	\N	\N	\N	\N	\N	\N
create-package-title	create-package-title	navigator	\N	Create Package	Maak Package	\N	\N	\N	\N	\N	\N
package-input-label-invalid	package-input-label-invalid	navigator	\N	Please enter a valid name.	Voer een geldige naam in.	\N	\N	\N	\N	\N	\N
update-package-title	update-package-title	navigator	\N	Edit Package	Wijzig Package	\N	\N	\N	\N	\N	\N
package-input-description	package-input-description	navigator	\N	Description	Omschrijving	\N	\N	\N	\N	\N	\N
action-create	action-create	navigator	\N	Create	Maak	\N	\N	\N	\N	\N	\N
progress-delete-success	progress-delete-success	navigator	\N	Deleting completed	Verwijderen voltooid	\N	\N	\N	\N	\N	\N
progress-copy-started	progress-copy-started	navigator	\N	Starting to copy	Begonnen met kopiëren	\N	\N	\N	\N	\N	\N
update-package-ok-text	update-package-ok-text	navigator	\N	Save changes	Wijzigingen opslaan	\N	\N	\N	\N	\N	\N
table-col-header-name	table-col-header-name	navigator	\N	Name	Naam	\N	\N	\N	\N	\N	\N
package-input-label	package-input-label	navigator	\N	Name	Naam	\N	\N	\N	\N	\N	\N
progress-download-success-action-post	progress-download-success-action-post	navigator	\N	to download the file	om de file te downloaden	\N	\N	\N	\N	\N	\N
delete-confirmation-cancel-text	delete-confirmation-cancel-text	navigator	\N	Cancel	Annuleer	\N	\N	\N	\N	\N	\N
progress-download-running	progress-download-running	navigator	\N	Started preparing download...	Begonnen met voorbereiden van de download...	\N	\N	\N	\N	\N	\N
table-no-results	table-no-results	navigator	\N	There are no items to show	Er zijn geen items om weer te geven	\N	\N	\N	\N	\N	\N
progress-download-success-action	progress-download-success-action	navigator	\N	here	hier	\N	\N	\N	\N	\N	\N
NAV02	NAV02	navigator	\N	You can't copy a package into itself.	Je kunt een map niet naar zichzelf kopiëren.	\N	\N	\N	\N	\N	\N
NAV01	NAV01	navigator	\N	Download failed: {0}	Download gefaald: {0}	\N	\N	\N	\N	\N	\N
table-col-header-description	table-col-header-description	navigator	\N	Description	Omschrijving	\N	\N	\N	\N	\N	\N
NAV03	NAV03	navigator	\N	An error occurred during copying.	Er is een fout opgetreden tijdens het kopiëren.	\N	\N	\N	\N	\N	\N
action-copy	action-copy	navigator	\N	Copy	Kopiëren	\N	\N	\N	\N	\N	\N
progress-delete-started	progress-delete-started	navigator	\N	Deleting ...	Verwijderen ...	\N	\N	\N	\N	\N	\N
progress-download-success-action-pre	progress-download-success-action-pre	navigator	\N	Click	Klik	\N	\N	\N	\N	\N	\N
action-download	action-download	navigator	\N	Download	Download	\N	\N	\N	\N	\N	\N
action-delete	action-delete	navigator	\N	Delete	Verwijderen	\N	\N	\N	\N	\N	\N
plugin-title	plugin-title	navigator	\N	Navigator	Verkenner	\N	\N	\N	\N	\N	\N
search-query-label	search-query-label	navigator	\N	search for	zoek naar	\N	\N	\N	\N	\N	\N
N01	N01	navigator	\N	You can't copy a package into itself.	\N	\N	\N	\N	\N	\N	\N
progress-copy-success	progress-copy-success	navigator	\N	Copying completed	Kopiëren voltooid	\N	\N	\N	\N	\N	\N
N02	N02	navigator	\N	Copy failed: {0}	\N	\N	\N	\N	\N	\N	\N
action-create-entity-type	action-create-entity-type	navigator	\N	Entity type	Entiteitsoort	\N	\N	\N	\N	\N	\N
navigator_download_start_message	navigator_download_start_message	navigator	\N	\N	Begonnen met downloaden...	\N	\N	\N	\N	\N	\N
navigator_download_finished_message	navigator_download_finished_message	navigator	\N	\N	Klaar met downloaden.	\N	\N	\N	\N	\N	\N
progress-download-success	progress-download-success	navigator	\N	Finished preparing download.	Klaar met voorbereiden van de download.	\N	\N	\N	\N	\N	\N
action-edit	action-edit	navigator	\N	Edit	Edit	\N	\N	\N	\N	\N	\N
action-cut	action-cut	navigator	\N	Cut	Knippen	\N	\N	\N	\N	\N	\N
search-button	search-button	navigator	\N	Search	Zoek	\N	\N	\N	\N	\N	\N
create-package-ok-text	create-package-ok-text	navigator	\N	Create	Maak	\N	\N	\N	\N	\N	\N
progress-download-failed	progress-download-failed	navigator	\N	Preparing download failed	Download voorbereiden gefaald	\N	\N	\N	\N	\N	\N
action-create-package	action-create-package	navigator	\N	Package	Package	\N	\N	\N	\N	\N	\N
delete-confirmation-title	delete-confirmation-title	navigator	\N	Confirm Deletion	Bevestig Verwijderen	\N	\N	\N	\N	\N	\N
action-paste	action-paste	navigator	\N	Paste	Plakken	\N	\N	\N	\N	\N	\N
create-package-cancel-text	create-package-cancel-text	navigator	\N	Cancel	Annuleer	\N	\N	\N	\N	\N	\N
progress-copy-entity-types	progress-copy-entity-types	navigator	\N	Copying entity types	Entiteitsoorten aan het kopiëren	\N	\N	\N	\N	\N	\N
action-upload	action-upload	navigator	\N	Upload	Upload	\N	\N	\N	\N	\N	\N
delete-confirmation-ok-text	delete-confirmation-ok-text	navigator	\N	Delete	Verwijder	\N	\N	\N	\N	\N	\N
search-input-placeholder	search-input-placeholder	navigator	\N	Search packages and data ...	Zoeken naar folders en tabellen ...	\N	\N	\N	\N	\N	\N
delete-confirmation-text	delete-confirmation-text	navigator	\N	Are you sure you want to permanently remove these items?	Weet je zeker dat je deze items permanent wilt verwijderen?	\N	\N	\N	\N	\N	\N
DF01	DF01	file	\N	Error unzipping file ''{0}''.	\N	\N	\N	\N	\N	\N	\N
org.molgenis.web.exception.ObjectError	org.molgenis.web.exception.ObjectError	web	\N	''{0}'' {1}	\N	\N	\N	\N	\N	\N	\N
org.molgenis.web.exception.FieldError	org.molgenis.web.exception.FieldError	web	\N	Field ''{0}'' of ''{1}'' {2}	\N	\N	\N	\N	\N	\N	\N
XLS03	XLS03	excel	\N	An error occured while writing XLSX:  {0}	Er is een fout opgetreden bij het schrijven van XLSX:  {0}	\N	\N	\N	\N	\N	\N
XLS02	XLS02	excel	\N	Class ''{1}'' of value ''{0}'' is not of a supported type for the XLXS writer.	Klasse ''{1}'' van waarde ''{0}'' is niet van een ondersteund type voor de XLXS writer.	\N	\N	\N	\N	\N	\N
XLS01	XLS01	excel	\N	The entity type name ''{0}'' is too long to be used as a sheet name in XLSX.	De entiteitsoort naam  ''{0}'' is te lang om als tabblad naam in XLSX gebruikt te worden.	\N	\N	\N	\N	\N	\N
SEC02	SEC02	security	\N	The password reset link has expired.	De wachtwoord reset link is verlopen.	\N	\N	\N	\N	\N	\N
SEC01	SEC01	security	\N	Password reset failed.	Wachtwoord reset niet geslaagd.	\N	\N	\N	\N	\N	\N
SEC04	SEC04	security	\N	The password reset link is invalid.	De wachtwoord reset link is ongeldig.	\N	\N	\N	\N	\N	\N
SEC03	SEC03	security	\N	The password reset link is invalid.	De wachtwoord reset link is ongeldig.	\N	\N	\N	\N	\N	\N
security.login.local	security.login.local	security	\N	Use a local user	\N	\N	\N	\N	\N	\N	\N
D12d	D12d	data	\N	Expression ''{0}'' with tag ''{1}'' is missing a reference tag.	Expressie ''{0}'' met tag ''{1}'' mist een referentie tag.	\N	\N	\N	\N	\N	\N
D12c	D12c	data	\N	Expression ''{0}'' with tag ''{1}'' is invalid.	Expressie ''{0}'' met tag ''{1}'' is ongeldig.	\N	\N	\N	\N	\N	\N
D12b	D12b	data	\N	Expression ''{0}'' with tag ''{1}'' refers to unknown attribute.	Expressie ''{0}'' met tag ''{1}'' verwijst naar onbekend attibuut.	\N	\N	\N	\N	\N	\N
D12a	D12a	data	\N	Expression ''{0}'' with tag ''{1}'' refers to attribute with invalid type ''{2}''.	Expressie ''{0}'' met tag ''{1}'' verwijst naar attibuut met ongeldig type ''{2}''.	\N	\N	\N	\N	\N	\N
D01	D01	data	\N	Unknown entity type ''{0}''.	Onbekende entiteitsoort ''{0}''.	\N	\N	\N	\N	\N	\N
D02a	D02a	data	\N	Unknown entity ''{1}'' of type ''{0}''.	Onbekende entiteit ''{1}'' van entiteitsoort ''{0}''.	\N	\N	\N	\N	\N	\N
D02	D02	data	\N	Unknown entity with ''{2,label}'' ''{1}'' of type ''{0,label}''.	Onbekende entiteit met  ''{2,label}'' ''{1}'' van entiteitsoort ''{0,label}''.	\N	\N	\N	\N	\N	\N
D05	D05	data	\N	Unknown repository ''{0}''.	Onbekende opslagplaats ''{0}''.	\N	\N	\N	\N	\N	\N
D04	D04	data	\N	Unknown attribute ''{1}'' of entity type ''{0,label}''.	Onbekend attribuut ''{1}'' van entiteitsoort ''{0,label}''.	\N	\N	\N	\N	\N	\N
D07	D07	data	\N	Unknown plugin with ID ''{0}''	Onbekende plugin met ID ''{0}''	\N	\N	\N	\N	\N	\N
D06	D06	data	\N	Unknown repository collection ''{0}''.	Onbekende opslagplaats verzameling ''{0}''.	\N	\N	\N	\N	\N	\N
D09	D09	data	\N	Entity ''{0}'' of type ''{1,label}'' already exists.	Entiteit ''{0}'' van entiteitsoort ''{1,label}'' bestaat al.	\N	\N	\N	\N	\N	\N
D08	D08	data	\N	Can''t create repository for abstract entity type ''{0,label}''.	Aanmaken van opslagplaats voor abstracte entiteitsoort ''{0,label}'' niet mogelijk.	\N	\N	\N	\N	\N	\N
repository-capability-indexable	repository-capability-indexable	data	\N	indexing	indexeren	\N	\N	\N	\N	\N	\N
repository-capability-validate_reference_constraint	repository-capability-validate_reference_constraint	data	\N	reference validation	referentie validatie	\N	\N	\N	\N	\N	\N
repository-capability-cacheable	repository-capability-cacheable	data	\N	caching	cachen	\N	\N	\N	\N	\N	\N
D10	D10	data	\N	Repository ''{0}'' already exists.	Opslagplaats ''{0}'' bestaat al.	\N	\N	\N	\N	\N	\N
D11	D11	data	\N	Repository ''{0}'' does not support ''{1}''.	Opslagplaats ''{0}'' ondersteunt geen ''{1}''.	\N	\N	\N	\N	\N	\N
D14	D14	data	\N	Unknown tag ''{0}''.	Onbekende tag ''{0}''.	\N	\N	\N	\N	\N	\N
D13	D13	data	\N	Unknown package ''{0}''.	Onbekende map ''{0}''.	\N	\N	\N	\N	\N	\N
repository-capability-queryable	repository-capability-queryable	data	\N	querying	vragen	\N	\N	\N	\N	\N	\N
repository-capability-managable	repository-capability-managable	data	\N	managing	managen	\N	\N	\N	\N	\N	\N
repository-capability-validate_readonly_constraint	repository-capability-validate_readonly_constraint	data	\N	read-only validation	alleen-lezen validatie	\N	\N	\N	\N	\N	\N
repository-capability-writable	repository-capability-writable	data	\N	writing	schrijven	\N	\N	\N	\N	\N	\N
repository-capability-validate_unique_constraint	repository-capability-validate_unique_constraint	data	\N	uniqueness validation	uniekheid validaties	\N	\N	\N	\N	\N	\N
repository-capability-aggregateable	repository-capability-aggregateable	data	\N	aggregating	aggregeren	\N	\N	\N	\N	\N	\N
repository-capability-validate_notnull_constraint	repository-capability-validate_notnull_constraint	data	\N	not-null validation	niet-null validatie	\N	\N	\N	\N	\N	\N
D12e	D12e	data	\N	Expression ''{0}'' syntax invalid.	Expressie ''{0}'' syntax ongeldig.	\N	\N	\N	\N	\N	\N
DS04a	DS04a	data-security	\N	No ''{0}'' permission on entity type with id ''{1}''.	Geen ''{0}'' rechten op entiteitssoort met id ''{1}''.	\N	\N	\N	\N	\N	\N
DS30	DS30	data-security	\N	No ACL information could be found for type ''{0}''.	\N	\N	\N	\N	\N	\N	\N
DS31	DS31	data-security	\N	No permission found to ''{3}'' for id ''{1}'' of type ''{0}'' for ''{2}''.	\N	\N	\N	\N	\N	\N	\N
DS32	DS32	data-security	\N	Getting or setting permissions for ''{0}'' is not allowed since it has role ''superuser'' which has permissions on everything.	\N	\N	\N	\N	\N	\N	\N
DS33	DS33	data-security	\N	No type with id ''{0}'' could be found.	\N	\N	\N	\N	\N	\N	\N
DS34	DS34	data-security	\N	Adding or removing row level security is not allowed for ''{0}'' because it is a system entity type.	\N	\N	\N	\N	\N	\N	\N
DS35	DS35	data-security	\N	An acl with id ''{1}'' for type with id ''{0}'' already exists.	\N	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.AGGREGATE_DATA.name	permission.EntityTypePermission.AGGREGATE_DATA.name	data-security	\N	Aggregate	Aggregeer	\N	\N	\N	\N	\N	\N
permission.PackagePermission.ADD_ENTITY_TYPE.name	permission.PackagePermission.ADD_ENTITY_TYPE.name	data-security	\N	Add entity type	Voeg entiteitssoort toe	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.DELETE_METADATA.name	permission.EntityTypePermission.DELETE_METADATA.name	data-security	\N	Delete metadata	Verwijder metadata	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.ADD_DATA.name	permission.EntityTypePermission.ADD_DATA.name	data-security	\N	Add data	Voeg data toe	\N	\N	\N	\N	\N	\N
permission.EntityPermission.UPDATE.name	permission.EntityPermission.UPDATE.name	data-security	\N	Update	Schrijf	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.COUNT_DATA.name	permission.EntityTypePermission.COUNT_DATA.name	data-security	\N	Count	Tel	\N	\N	\N	\N	\N	\N
permission.GroupPermission.UPDATE_MEMBERSHIP.name	permission.GroupPermission.UPDATE_MEMBERSHIP.name	data-security	\N	Update Membership	\N	\N	\N	\N	\N	\N	\N
DS20	DS20	data-security	\N	User cannot have multiple roles within the same group.	Gebruiker kan niet meerdere rollen binnen dezelfde groep hebben.	\N	\N	\N	\N	\N	\N
DS21	DS21	data-security	\N	Unknown role with name ''{0}''.	\N	\N	\N	\N	\N	\N	\N
DS22	DS22	data-security	\N	Unknown type identifier ''{0}'', if you attempt to use an entity type identifier please prefix with ''entity-''.	\N	\N	\N	\N	\N	\N	\N
DS23	DS23	data-security	\N	The permission ''{0}'' cannot be used for type ''{1}''.	\N	\N	\N	\N	\N	\N	\N
DS24	DS24	data-security	\N	No read permission on type ''{0}''.	\N	\N	\N	\N	\N	\N	\N
DS25	DS25	data-security	\N	No permission to read permissions for user(s) and/or role(s) ''{0}''.	\N	\N	\N	\N	\N	\N	\N
DS26	DS26	data-security	\N	User has to be one of the following: ''{2}'' for this operation on row with id ''{1}'' of type ''{0}''.	\N	\N	\N	\N	\N	\N	\N
DS27	DS27	data-security	\N	''{0}'' already has a permission on the resource with id ''{1}'' of type ''{2}''.	\N	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.UPDATE_DATA.name	permission.EntityTypePermission.UPDATE_DATA.name	data-security	\N	Update data	Schrijf data	\N	\N	\N	\N	\N	\N
DS28	DS28	data-security	\N	Read permissions on 'sys_sec_Role' and 'sys_sec_RoleMembership' are required to be able to show inherited permissions.	\N	\N	\N	\N	\N	\N	\N
DS29	DS29	data-security	\N	A type with id ''{0}'' already exists.	\N	\N	\N	\N	\N	\N	\N
permission.GroupPermission.VIEW.name	permission.GroupPermission.VIEW.name	data-security	\N	View	\N	\N	\N	\N	\N	\N	\N
DS10	DS10	data-security	\N	No ''{0}'' permission on group ''{1}''.	\N	\N	\N	\N	\N	\N	\N
role-owner	role-owner	data-security	\N	owner	\N	\N	\N	\N	\N	\N	\N
role-superuser	role-superuser	data-security	\N	superuser	\N	\N	\N	\N	\N	\N	\N
DS15	DS15	data-security	\N	Role ''{0}'' is not a valid group role for group ''{1}''.	\N	\N	\N	\N	\N	\N	\N
DS16	DS16	data-security	\N	Group name ''{0}'' is not a available, please choose a different group name.	\N	\N	\N	\N	\N	\N	\N
DS17	DS17	data-security	\N	Unknown user with username ''{0}''.	Onbekende gebruiker met gebruikersnaam ''{0}''.	\N	\N	\N	\N	\N	\N
DS18	DS18	data-security	\N	No permission to create or modify superuser ''{0}''.	Geen rechten om superuser ''{0}'' aan te maken of te wijzigen.	\N	\N	\N	\N	\N	\N
DS19	DS19	data-security	\N	Invalid email address.	Ongeldig e-mailadres.	\N	\N	\N	\N	\N	\N
permission.EntityPermission.READ.name	permission.EntityPermission.READ.name	data-security	\N	Read	Lees	\N	\N	\N	\N	\N	\N
permission.GroupPermission.ADD_MEMBERSHIP.name	permission.GroupPermission.ADD_MEMBERSHIP.name	data-security	\N	Add Membership	\N	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.READ_DATA.name	permission.EntityTypePermission.READ_DATA.name	data-security	\N	Read data	Lees data	\N	\N	\N	\N	\N	\N
permission.GroupPermission.VIEW_MEMBERSHIP.name	permission.GroupPermission.VIEW_MEMBERSHIP.name	data-security	\N	View Membership	\N	\N	\N	\N	\N	\N	\N
permission.GroupPermission.REMOVE_MEMBERSHIP.name	permission.GroupPermission.REMOVE_MEMBERSHIP.name	data-security	\N	Remove Membership	\N	\N	\N	\N	\N	\N	\N
permission.PackagePermission.ADD_PACKAGE.name	permission.PackagePermission.ADD_PACKAGE.name	data-security	\N	Add package	Voeg package toe	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.UPDATE_METADATA.name	permission.EntityTypePermission.UPDATE_METADATA.name	data-security	\N	Update metadata	Schrijf metadata	\N	\N	\N	\N	\N	\N
DS01	DS01	data-security	\N	No ''{0}'' permission on package ''{1}''.	Geen ''{0}'' rechten op package ''{1}''.	\N	\N	\N	\N	\N	\N
permission.EntityPermission.DELETE.name	permission.EntityPermission.DELETE.name	data-security	\N	Delete	Verwijder	\N	\N	\N	\N	\N	\N
DS02	DS02	data-security	\N	Only superusers are allowed to create EntityTypes without a package.	Alleen superusers mogen entiteitssoorten aanmaken zonder een package.	\N	\N	\N	\N	\N	\N
DS03	DS03	data-security	\N	Only superusers are allowed to create packages without a parent.	Alleen superusers mogen packages aanmaken zonder een package.	\N	\N	\N	\N	\N	\N
DS04	DS04	data-security	\N	No ''{0}'' permission on entity type ''{2,label}'' with id ''{1}''.	Geen ''{0}'' rechten op entiteitssoort ''{2,label}'' met id ''{1}''.	\N	\N	\N	\N	\N	\N
DS05	DS05	data-security	\N	System metadata cannot be modified.	Systeem metadata kan niet aangepast worden.	\N	\N	\N	\N	\N	\N
DS06	DS06	data-security	\N	No ''{0}'' permission on entity ''{1}'' of type ''{2,label}''	Geen ''{0}'' rechten op entiteit ''{1}''  van soort ''{2,label}''	\N	\N	\N	\N	\N	\N
DS07	DS07	data-security	\N	No packages exist that allow for adding entity types and packages.	Er zijn geen packages waar entiteitssoorten en packages aan toegevoegd mogen worden.	\N	\N	\N	\N	\N	\N
DS08	DS08	data-security	\N	No ''{0}'' permission on parent package ''{2}'' of package ''{1}''.	\N	\N	\N	\N	\N	\N	\N
DS09	DS09	data-security	\N	User ''{0}'' is already part of group ''{1}'', can not be added again.	\N	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.DELETE_DATA.name	permission.EntityTypePermission.DELETE_DATA.name	data-security	\N	Delete data	Verwijder data	\N	\N	\N	\N	\N	\N
permission.EntityTypePermission.READ_METADATA.name	permission.EntityTypePermission.READ_METADATA.name	data-security	\N	Read metadata	Lees metadata	\N	\N	\N	\N	\N	\N
data-row-edit-boolean-false	data-row-edit-boolean-false	data-row-edit	\N	No	Nee	\N	\N	\N	\N	\N	\N
data-row-edit-cancel-button-label	data-row-edit-cancel-button-label	data-row-edit	\N	Cancel	Annuleren	\N	\N	\N	\N	\N	\N
data-row-edit-boolean-true	data-row-edit-boolean-true	data-row-edit	\N	Yes	Ja	\N	\N	\N	\N	\N	\N
data-row-edit-save-busy-state-label	data-row-edit-save-busy-state-label	data-row-edit	\N	Saving...	Opslaan...	\N	\N	\N	\N	\N	\N
data-row-edit-invalid-fields-msg	data-row-edit-invalid-fields-msg	data-row-edit	\N	Cannot save, this row contains invalid values.	Opslaan niet mogenlijk, deze rij bevat invalide waarden.	\N	\N	\N	\N	\N	\N
data-row-edit-boolean-null	data-row-edit-boolean-null	data-row-edit	\N	Don't know	Weet ik niet 	\N	\N	\N	\N	\N	\N
data-row-edit-default-error-message	data-row-edit-default-error-message	data-row-edit	\N	An error has occurred.	Er is een fout opgetreden.	\N	\N	\N	\N	\N	\N
data-row-edit-save-button-label	data-row-edit-save-button-label	data-row-edit	\N	Save	Opslaan	\N	\N	\N	\N	\N	\N
questionnaire_forgotten_chapters	questionnaire_forgotten_chapters	questionnaire	\N	Incomplete chapters	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_view_questionnaire_button	questionnaires_table_view_questionnaire_button	questionnaire	\N	View questionnaire	\N	\N	\N	\N	\N	\N	\N
questionnaire_loading_chapter_text	questionnaire_loading_chapter_text	questionnaire	\N	Loading chapter	\N	\N	\N	\N	\N	\N	\N
questionnaire_submit	questionnaire_submit	questionnaire	\N	Submit	\N	\N	\N	\N	\N	\N	\N
questionnaire_back_to_questionnaire_list	questionnaire_back_to_questionnaire_list	questionnaire	\N	Back to questionnaires list	\N	\N	\N	\N	\N	\N	\N
questionnaire_chapters	questionnaire_chapters	questionnaire	\N	Chapters	\N	\N	\N	\N	\N	\N	\N
questionnaires_title	questionnaires_title	questionnaire	\N	My questionnaires	\N	\N	\N	\N	\N	\N	\N
questionnaire_boolean_true	questionnaire_boolean_true	questionnaire	\N	Yes	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_status_header	questionnaires_table_status_header	questionnaire	\N	Status	\N	\N	\N	\N	\N	\N	\N
Q01	Q01	questionnaire	\N	No row level security enabled for questionnaire, this is not allowed	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_status_open	questionnaires_table_status_open	questionnaire	\N	Open	\N	\N	\N	\N	\N	\N	\N
questionnaire_back_to_start	questionnaire_back_to_start	questionnaire	\N	Back to start	\N	\N	\N	\N	\N	\N	\N
questionnaire_loading_text	questionnaire_loading_text	questionnaire	\N	Initializing Questionnaire	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_continue_questionnaire_button	questionnaires_table_continue_questionnaire_button	questionnaire	\N	Continue questionnaire	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_questionnaire_header	questionnaires_table_questionnaire_header	questionnaire	\N	Questionnaire	\N	\N	\N	\N	\N	\N	\N
questionnaires_description	questionnaires_description	questionnaire	\N	Submitted and open questionnaires	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_status_submitted	questionnaires_table_status_submitted	questionnaire	\N	Submitted	\N	\N	\N	\N	\N	\N	\N
questionnaire_save_and_continue	questionnaire_save_and_continue	questionnaire	\N	Save and continue later	\N	\N	\N	\N	\N	\N	\N
questionnaire_previous_chapter	questionnaire_previous_chapter	questionnaire	\N	Previous chapter	\N	\N	\N	\N	\N	\N	\N
questionnaire_saving_changes	questionnaire_saving_changes	questionnaire	\N	Saving...	\N	\N	\N	\N	\N	\N	\N
questionnaire_overview_download_btn_label	questionnaire_overview_download_btn_label	questionnaire	\N	Download	\N	\N	\N	\N	\N	\N	\N
questionnaire_start	questionnaire_start	questionnaire	\N	Start questionnaire	\N	\N	\N	\N	\N	\N	\N
questionnaires_view_overview	questionnaires_view_overview	questionnaire	\N	Finished questionnaire overview	\N	\N	\N	\N	\N	\N	\N
questionnaire_loading_list	questionnaire_loading_list	questionnaire	\N	Loading questionnaires	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_status_not_started	questionnaires_table_status_not_started	questionnaire	\N	Not started yet	\N	\N	\N	\N	\N	\N	\N
questionnaire_changes_saved	questionnaire_changes_saved	questionnaire	\N	All changes have been saved	\N	\N	\N	\N	\N	\N	\N
questionnaires_table_start_questionnaire_button	questionnaires_table_start_questionnaire_button	questionnaire	\N	Start questionnaire	\N	\N	\N	\N	\N	\N	\N
questionnaire_next_chapter	questionnaire_next_chapter	questionnaire	\N	Next chapter	\N	\N	\N	\N	\N	\N	\N
questionnaire_boolean_null	questionnaire_boolean_null	questionnaire	\N	Don't know	\N	\N	\N	\N	\N	\N	\N
questionnaire_boolean_false	questionnaire_boolean_false	questionnaire	\N	No	\N	\N	\N	\N	\N	\N	\N
questionnaire_overview_loading_text	questionnaire_overview_loading_text	questionnaire	\N	Loading Questionnaire overview	\N	\N	\N	\N	\N	\N	\N
questionnaires_view_questionnaire	questionnaires_view_questionnaire	questionnaire	\N	View Questionnaire	\N	\N	\N	\N	\N	\N	\N
questionnaire_chapter_incomplete_message	questionnaire_chapter_incomplete_message	questionnaire	\N	Please complete this chapter before moving on...	\N	\N	\N	\N	\N	\N	\N
questionnaires_overview_title	questionnaires_overview_title	questionnaire	\N	Questionnaire overview	\N	\N	\N	\N	\N	\N	\N
questionnaires_no_questionnaires_found_message	questionnaires_no_questionnaires_found_message	questionnaire	\N	No questionnaires found	\N	\N	\N	\N	\N	\N	\N
AM02	AM02	app-manager	\N	There were some missing files in your zip package {0}. Please add these and upload again.	\N	\N	\N	\N	\N	\N	\N
AM03	AM03	app-manager	\N	There were some missing parameters in your config file {0}. Please add these and upload again.	\N	\N	\N	\N	\N	\N	\N
AM01	AM01	app-manager	\N	{0} is not a valid zip file!	\N	\N	\N	\N	\N	\N	\N
AM10	AM10	app-manager	\N	The app name ''{0}'' is not allowed because it contains a ''/''.	\N	\N	\N	\N	\N	\N	\N
AM08	AM08	app-manager	\N	App already exists with name {0}. To install this app you need to disable and delete the current version.	\N	\N	\N	\N	\N	\N	\N
AM09	AM09	app-manager	\N	Couldn't delete app with id {0}.	\N	\N	\N	\N	\N	\N	\N
AM06	AM06	app-manager	\N	App with name {0} does not exist.	\N	\N	\N	\N	\N	\N	\N
AM07	AM07	app-manager	\N	Access denied for inactive app at location /app/{0}	\N	\N	\N	\N	\N	\N	\N
AM04	AM04	app-manager	\N	The config file you provided has some problems. Please ensure it is a valid JSON file.	\N	\N	\N	\N	\N	\N	\N
AM05	AM05	app-manager	\N	App with id {0} does not exist.	\N	\N	\N	\N	\N	\N	\N
IMP20	IMP20	data-import	\N	Unknown ''{1}'' value ''{0}'' for entity ''{2}''. (sheet: ''{3}'', row {4})	Onbekende ''{1}'' waarde ''{0}'' for entiteit ''{2}''. (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
IMP21	IMP21	data-import	\N	Invalid value for column ''dataType'' of attribute ''{1, label}'' of entity ''{2}'', {0} attributes cannot be of reference data types (sheet: ''{3}'', row {4})	Incorrecte waarde voor kolom dataType van attribuut ''{1, label}'' van entity ''{2}'', ''{0}'' attributen kunnen niet van referentie data types zijn (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
IMP01	IMP01	data-import	\N	Unsupported attribute metadata: ''{0}'', did you mean ''{1}''? (sheet: ''{2}'')	Niet ondersteunde attribuut metadata: ''{0}'', bedoelde u misschien ''{1}''? (werkblad: ''{2}'')	\N	\N	\N	\N	\N	\N
IMP02	IMP02	data-import	\N	Duplicate attribute name ''{0}'' for entity type ''{1}''.(sheet: ''{2}'', row {3})	Dubbele attribuut name ''{0}'' for entiteit type ''{1}''. (werkblad: ''{2}'', rij {3})	\N	\N	\N	\N	\N	\N
IMP03	IMP03	data-import	\N	Import failed: {0} (sheet: ''{1}'', row {2})	Inladen gefaald: {0} (werkblad: ''{1}'', rij {2})	\N	\N	\N	\N	\N	\N
EXP02	EXP02	data-import	\N	The download request should contain at least one package or entity type.	Het download verzoek moet minimaal 1 entiteitsoort of package bevatten.	\N	\N	\N	\N	\N	\N
EXP01	EXP01	data-import	\N	An error occured while downloading your selection.	Er is een fout opgetreden bij het downloaden van uw selectie.	\N	\N	\N	\N	\N	\N
scripts-exposed-parameters	scripts-exposed-parameters	scripts	\N	Exposed Parameters	Parameters	\N	\N	\N	\N	\N	\N
emx_export_metadata_message	emx_export_metadata_message	data-import	\N	Finished downloading package metadata.	Klaar met downloaden van map metadata	\N	\N	\N	\N	\N	\N
IMP04	IMP04	data-import	\N	Package name should be fully qualified. (package: ''{0}'', parentpackage: ''{1}'' sheet: ''{2}'', row {3})	Map naam moet beginnen met de naam van de bovenliggende map. (map: {0}, bovenliggende map: {1} werkblad: ''{2}'', rij {3})	\N	\N	\N	\N	\N	\N
IMP05	IMP05	data-import	\N	partOfAttribute ''{0}'' of attribute {1} of entity {2} must refer to a attribute of type ''compound''. (sheet: ''{3}'', row {4})	partOfattribuut ''{0}'' van attribuut ''{1}'' van entiteit ''{2}'' moet refereren naar een attribuut van type ''compound''. (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
IMP06	IMP06	data-import	\N	Invalid value for column ''dataType'' of attribute ''{2, label}'' of entity ''{3}'', {0} attributes can only be of data type ''{1}''(sheet: ''{4}'', row {5})	Incorrecte waarde voor kolom 'dataType' van attribuut ''{2,label}'' van entity ''{3}'', {0} attributen kunnen alleen van data type ''{1}'' zijn. (werkblad: ''{4}'', rij {5})	\N	\N	\N	\N	\N	\N
IMP07	IMP07	data-import	\N	Unsupported column ''{0}'' on sheet ''{1}''	Onbekende column ''{0}'' op werkblad ''{1}''	\N	\N	\N	\N	\N	\N
IMP08	IMP08	data-import	\N	Invalid value ''{0}'' for column ''{1}'' for attribute ''{3}'' of entity ''{2}'', should be a long(sheet: ''{4}'', row {5})	Incorrecte waarde ''{0}'' voor kolom ''{1}'' voor attribuut ''{3}'' van entiteit ''{2}'', waarde moet van type long zijn. (werkblad: ''{4}'', rij {5})	\N	\N	\N	\N	\N	\N
IMP09	IMP09	data-import	\N	Illegal ''{1}'' value ''{0}''. Allowed values are {2}. (sheet: ''{3}'', row {4})	Illegale ''{1}'' waarde ''{0}''. Toegestane waardes zijn {2}. (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
import_unknown_error	import_unknown_error	data-import	\N	Unknown error has occurred	Er is een onbekende fout opgetreden	\N	\N	\N	\N	\N	\N
IMP10	IMP10	data-import	\N	partOfAttribute ''{0}'' of attribute ''{1}'' of entity ''{2}'' must refer to an existing compound attribute. (sheet: ''{3}'', row {4})	partOfAttribute ''{0}'' van attribuut ''{1}'' of entiteit ''{2}'' moet verwijzen naar een bestaand compound attribuut. (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
IMP11	IMP11	data-import	\N	Missing ''{0}'' for attribute ''{1}'' of entity ''{2}''. (sheet: ''{3}'', row {4})	Onbrekende kolom ''{0}'' voor attribuut ''{1}'' of entiteit ''{2}''. (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
IMP12	IMP12	data-import	\N	Column ''{0}'' is missing. (sheet: ''{1}'', row {2})	Kolom ''{0}'' onbreekt. (werkblad: ''{1}'', rij {2})	\N	\N	\N	\N	\N	\N
IMP14	IMP14	data-import	\N	Missing root package. There must be at least one package without a parent. (sheet: 'packages')	Onbrekende hoofdmap. Minstens 1 map zonder bovenliggende map nodig. (werkblad: 'packages')	\N	\N	\N	\N	\N	\N
EXP03	EXP03	data-import	\N	{0, label} ''{1}'' cannot be downloaded, the identifier does not start with the (parent)package name.	{0, label} ''{1}'' kan niet worden gedownload, de identifier start niet met de (bovenliggende)mapnaam.	\N	\N	\N	\N	\N	\N
IMP15	IMP15	data-import	\N	Nullable aggregatable attribute ''{1}'' of entity ''{0}'' cannot be of type ''{2}''. (sheet: ''{3}'', row {4})	Optioneel aggregeerbaar attribuut ''{1}'' van entiteit ''{0}'' kan niet van type ''{2}'' zijn. (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
IMP16	IMP16	data-import	\N	Could not resolve packages. Is there a circular reference?(sheet: 'packages')	Kon map volgorde niet bepalen. Is er een circulaire referentie? (werkblad: 'packages')	\N	\N	\N	\N	\N	\N
IMP17	IMP17	data-import	\N	partOfAttribute ''{0}'' of attribute ''{1}'' of entity ''{2}'' cannot refer to itself. (sheet: ''{3}'', row {4})	partOfAttribute ''{0}'' van attribuut ''{1}'' of entiteit ''{2}'' kan niet naar zichzelf verwijzen. (werkblad: ''{3}'', rij {4})	\N	\N	\N	\N	\N	\N
IMP18	IMP18	data-import	\N	Unknown datatype ''{0}''. (sheet: ''{1}'', row {2})	Onbekend data type ''{0}''. (werkblad: ''{1}'', rij {2})	\N	\N	\N	\N	\N	\N
IMP19	IMP19	data-import	\N	Unsupported attribute metadata: ''{0}'' (sheet: ''{1}'')	Niet ondersteunde attribuut metadata: ''{0}'' (werkblad: ''{1}'')	\N	\N	\N	\N	\N	\N
emx_export_progress_message	emx_export_progress_message	data-import	\N	Downloading ''{0}''	Bezig met downloaden van ''{0}''	\N	\N	\N	\N	\N	\N
DP01	DP01	data-plugin	\N	No ''{0}'' permission on plugin with id ''{1}''.	\N	\N	\N	\N	\N	\N	\N
permission.PluginPermission.VIEW_PLUGIN.name	permission.PluginPermission.VIEW_PLUGIN.name	data-plugin	\N	View plugin	\N	\N	\N	\N	\N	\N	\N
V01	V01	validation	\N	The JSON contains errors: {0}	\N	\N	\N	\N	\N	\N	\N
V03	V03	validation	\N	Relative paths are not allowed here, please specify an absolute URL.	\N	\N	\N	\N	\N	\N	\N
V02	V02	validation	\N	The JSON Schema contains errors: {0}	\N	\N	\N	\N	\N	\N	\N
V04	V04	validation	\N	Local URL's are not allowed here.	\N	\N	\N	\N	\N	\N	\N
clear-button-label	clear-button-label	searchall	\N	Clear	Wis	\N	\N	\N	\N	\N	\N
search-placeholder	search-placeholder	searchall	\N	Search all data	Zoek in alle data	\N	\N	\N	\N	\N	\N
no-attributes-found-label	no-attributes-found-label	searchall	\N	No matching columns found	geen kolommen gevonden	\N	\N	\N	\N	\N	\N
matching-entitytypes-label	matching-entitytypes-label	searchall	\N	Matching tables	Gevonden tabellen	\N	\N	\N	\N	\N	\N
rows-found-label	rows-found-label	searchall	\N	rows found	rijen gevonden	\N	\N	\N	\N	\N	\N
attributes-label	attributes-label	searchall	\N	Columns	Kolommen	\N	\N	\N	\N	\N	\N
no-matching-packages-label	no-matching-packages-label	searchall	\N	No packages found	Geen mappen gevonden	\N	\N	\N	\N	\N	\N
search-button-label	search-button-label	searchall	\N	Search	Zoek	\N	\N	\N	\N	\N	\N
description-label	description-label	searchall	\N	Description	Omschrijving	\N	\N	\N	\N	\N	\N
show-in-dataexplorer-link	show-in-dataexplorer-link	searchall	\N	Show in dataexplorer	Toon in dataexplorer	\N	\N	\N	\N	\N	\N
matching-packages-label	matching-packages-label	searchall	\N	Matching packages	Gevonden mappen	\N	\N	\N	\N	\N	\N
no-matching-entities-label	no-matching-entities-label	searchall	\N	No tables found	Geen tabellen gevonden	\N	\N	\N	\N	\N	\N
show-in-navigator-link	show-in-navigator-link	searchall	\N	Show in navigator	Toon in verkenner	\N	\N	\N	\N	\N	\N
data-label	data-label	searchall	\N	Data	Data	\N	\N	\N	\N	\N	\N
scripts-delete-script	scripts-delete-script	scripts	\N	Delete script	Verwijder script	\N	\N	\N	\N	\N	\N
scripts-please-use	scripts-please-use	scripts	\N	Please use	Gebruik	\N	\N	\N	\N	\N	\N
scripts-save-label	scripts-save-label	scripts	\N	Save	Opslaan	\N	\N	\N	\N	\N	\N
scripts-cancel-label	scripts-cancel-label	scripts	\N	Cancel	Terug	\N	\N	\N	\N	\N	\N
scripts-parameters-label	scripts-parameters-label	scripts	\N	Parameters	Parameters	\N	\N	\N	\N	\N	\N
scripts-name-label	scripts-name-label	scripts	\N	Name	Naam	\N	\N	\N	\N	\N	\N
scripts-save-and-run	scripts-save-and-run	scripts	\N	Save and Run	Opslaan en uitvoeren	\N	\N	\N	\N	\N	\N
scripts-true-label	scripts-true-label	scripts	\N	Yes	Ja	\N	\N	\N	\N	\N	\N
scripts-connection-error	scripts-connection-error	scripts	\N	Error: Can't connect to molgenis	Error: Geen verbinding gevonden met molgenis	\N	\N	\N	\N	\N	\N
scripts-unique-error	scripts-unique-error	scripts	\N	This field is required, and needs to be unique.	Dit is een verplicht veld en dient uniek te zijn.	\N	\N	\N	\N	\N	\N
scripts-edit-script	scripts-edit-script	scripts	\N	Edit script	Bewerk script	\N	\N	\N	\N	\N	\N
scripts-add-new-script	scripts-add-new-script	scripts	\N	Add new script	Voeg script toe	\N	\N	\N	\N	\N	\N
scripts-new-script	scripts-new-script	scripts	\N	New Script	Nieuw Script	\N	\N	\N	\N	\N	\N
scripts-remove-script	scripts-remove-script	scripts	\N	Are you sure you want to remove this script?	Weet je zeker dat je dit script wilt verwijderen	\N	\N	\N	\N	\N	\N
scripts-type-label	scripts-type-label	scripts	\N	Type	Type	\N	\N	\N	\N	\N	\N
scripts-save-error	scripts-save-error	scripts	\N	Error on saving data	Error tijdens het opslaan van de data	\N	\N	\N	\N	\N	\N
scripts-delete-label	scripts-delete-label	scripts	\N	Delete	Verwijder	\N	\N	\N	\N	\N	\N
scripts-run-label	scripts-run-label	scripts	\N	Run	Uitvoeren	\N	\N	\N	\N	\N	\N
scripts-generate-security-token	scripts-generate-security-token	scripts	\N	Generate security token	Genereer beveiligings token	\N	\N	\N	\N	\N	\N
scripts-confirm-deletion	scripts-confirm-deletion	scripts	\N	Confirm Deletion	Bevestig verwijderen	\N	\N	\N	\N	\N	\N
scripts-false-label	scripts-false-label	scripts	\N	No	Nee	\N	\N	\N	\N	\N	\N
scripts-result-file-extension	scripts-result-file-extension	scripts	\N	Result file extension	Bestands extensie	\N	\N	\N	\N	\N	\N
scripts-run-script	scripts-run-script	scripts	\N	Run script	Script uitvoeren	\N	\N	\N	\N	\N	\N
JOB02	JOB02	jobs	\N	Invalid job execution type ''{0}''.	Ongeldig job execution type ''{0}''.	\N	\N	\N	\N	\N	\N
JOB01	JOB01	jobs	\N	Deleting an active job is not allowed.	Verwijderen van een actieve job is niet toegestaan.	\N	\N	\N	\N	\N	\N
form_number_control_placeholder	form_number_control_placeholder	form	\N	Number	Getal	\N	\N	\N	\N	\N	\N
form_bool_true	form_bool_true	form	\N	Yes	Ja	\N	\N	\N	\N	\N	\N
form_xref_control_placeholder	form_xref_control_placeholder	form	\N	Search for a Value	Zoek een waarde	\N	\N	\N	\N	\N	\N
form_date_control_placeholder	form_date_control_placeholder	form	\N	Date	Datum	\N	\N	\N	\N	\N	\N
form_url_control_placeholder	form_url_control_placeholder	form	\N	URL	\N	\N	\N	\N	\N	\N	\N
form_computed_control_placeholder	form_computed_control_placeholder	form	\N	This value is computed automatically	Berekend veld	\N	\N	\N	\N	\N	\N
form_email_control_placeholder	form_email_control_placeholder	form	\N	Email	\N	\N	\N	\N	\N	\N	\N
form_bool_false	form_bool_false	form	\N	No	Nee	\N	\N	\N	\N	\N	\N
form_bool_missing	form_bool_missing	form	\N	N/A	Niet beschikbaar	\N	\N	\N	\N	\N	\N
form_mref_control_placeholder	form_mref_control_placeholder	form	\N	Search for Values	Zoek waarden	\N	\N	\N	\N	\N	\N
feedback_not_authenticated_mail_server	feedback_not_authenticated_mail_server	feedback	\N	Unfortunately, we were unable to send the mail containing your feedback. Please contact the administrator.	Kon mail server niet authenticeren. Contact uw administrator.	\N	\N	\N	\N	\N	\N
feedback_recaptcha_validation_failed	feedback_recaptcha_validation_failed	feedback	\N	You are not human, go away robot. Stop spamming the humans.	U bent geen mens, ga weg robot. Val ons mensen niet lastig.	\N	\N	\N	\N	\N	\N
dataexplorer_wizard_cancel	dataexplorer_wizard_cancel	dataexplorer	\N	Cancel	\N	\N	\N	\N	\N	\N	\N
dataexplorer_data_data_item_filters	dataexplorer_data_data_item_filters	dataexplorer	\N	Data item filters	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_enabled_collections_header	dataexplorer_directory_export_dialog_enabled_collections_header	dataexplorer	\N	Collections that support this functionality	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_no_config	dataexplorer_directory_no_config	dataexplorer	\N	No negotiator configuration found for the selected entity	\N	\N	\N	\N	\N	\N	\N
dataexplorer_aggregates_title	dataexplorer_aggregates_title	dataexplorer	\N	Aggregates	\N	\N	\N	\N	\N	\N	\N
dataexplorer_aggregates_total	dataexplorer_aggregates_total	dataexplorer	\N	Total	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_disabled_collections_header	dataexplorer_directory_export_dialog_disabled_collections_header	dataexplorer	\N	Collections that do not support this functionality	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_no_filters	dataexplorer_directory_export_no_filters	dataexplorer	\N	Please filter the collections before sending a request to the negotiator.	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_warning_title	dataexplorer_directory_export_dialog_warning_title	dataexplorer	\N	Warning	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_disabled	dataexplorer_directory_disabled	dataexplorer	\N	{0} of {1} collections do not support this functionality. Do you want to continue?	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_title	dataexplorer_directory_export_dialog_title	dataexplorer	\N	Send request to the BBMRI Negotiator?	\N	\N	\N	\N	\N	\N	\N
dataexplorer_aggregates_no_result_message	dataexplorer_aggregates_no_result_message	dataexplorer	\N	No results found	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_message	dataexplorer_directory_export_dialog_message	dataexplorer	\N	Your current selection of biobanks along with your filtering criteria will be sent to the BBMRI Negotiator. Are you sure?	\N	\N	\N	\N	\N	\N	\N
dataexplorer_wizard_title	dataexplorer_wizard_title	dataexplorer	\N	Filter Wizard	\N	\N	\N	\N	\N	\N	\N
dataexplorer_aggregates_distinct	dataexplorer_aggregates_distinct	dataexplorer	\N	Distinct	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_yes	dataexplorer_directory_export_dialog_yes	dataexplorer	\N	Yes, Send to Negotiator	\N	\N	\N	\N	\N	\N	\N
dataexplorer_wizard_apply	dataexplorer_wizard_apply	dataexplorer	\N	Apply	\N	\N	\N	\N	\N	\N	\N
dataexplorer_wizard_button	dataexplorer_wizard_button	dataexplorer	\N	Wizard	\N	\N	\N	\N	\N	\N	\N
dataexplorer_aggregates_group_by	dataexplorer_aggregates_group_by	dataexplorer	\N	Group by	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_no	dataexplorer_directory_export_dialog_no	dataexplorer	\N	No, I want to keep filtering	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_no_rows	dataexplorer_directory_no_rows	dataexplorer	\N	Please make sure your selection contains at least 1 row that supports the negotiator.	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_dialog_label	dataexplorer_directory_export_dialog_label	dataexplorer	\N	Some of the collections you selected do not support this functionality	\N	\N	\N	\N	\N	\N	\N
dataexplorer_aggregates_missing	dataexplorer_aggregates_missing	dataexplorer	\N	N/A	\N	\N	\N	\N	\N	\N	\N
dataexplorer_directory_export_button	dataexplorer_directory_export_button	dataexplorer	\N	Go to sample / data negotiation	\N	\N	\N	\N	\N	\N	\N
form_boolean_false	form_boolean_false	ui-form	\N	False	Onwaar	\N	\N	\N	\N	\N	\N
form_not_a_valid_url	form_not_a_valid_url	ui-form	\N	Not a valid URL	Geen geldige URL	\N	\N	\N	\N	\N	\N
form_show_optional_hint	form_show_optional_hint	ui-form	\N	Show all fields	Laat alle velden zien	\N	\N	\N	\N	\N	\N
form_below_min_value	form_below_min_value	ui-form	\N	Value is below allowed value	Waarde is onder toegestane waarde	\N	\N	\N	\N	\N	\N
form_boolean_missing	form_boolean_missing	ui-form	\N	N/A	Nvt	\N	\N	\N	\N	\N	\N
form_file_browse	form_file_browse	ui-form	\N	Browse	Selecteer	\N	\N	\N	\N	\N	\N
form_not_a_valid_number	form_not_a_valid_number	ui-form	\N	Not a valid number	Geen geldig nummer	\N	\N	\N	\N	\N	\N
form_required_field	form_required_field	ui-form	\N	This field is required	This veld is verplicht	\N	\N	\N	\N	\N	\N
form_boolean_true	form_boolean_true	ui-form	\N	True	Waar	\N	\N	\N	\N	\N	\N
form_not_a_valid_long	form_not_a_valid_long	ui-form	\N	Not a valid long value	Geen geldige long waarde	\N	\N	\N	\N	\N	\N
form_file_change	form_file_change	ui-form	\N	Change	Wijzig	\N	\N	\N	\N	\N	\N
form_validation_failed	form_validation_failed	ui-form	\N	Validation failed	Validatie mislukt	\N	\N	\N	\N	\N	\N
form_above_max_value	form_above_max_value	ui-form	\N	Value is above allowed value	Waarde is boven toegestane waarde	\N	\N	\N	\N	\N	\N
form_not_within_range	form_not_within_range	ui-form	\N	Value is outside of range	De waarde valt buiten het bereik	\N	\N	\N	\N	\N	\N
form_not_unique	form_not_unique	ui-form	\N	Not a unique value	Geen unieke waarde	\N	\N	\N	\N	\N	\N
form_hide_optional_hint	form_hide_optional_hint	ui-form	\N	Hide optional fields	Verberg optionele velden	\N	\N	\N	\N	\N	\N
form_not_a_valid_integer	form_not_a_valid_integer	ui-form	\N	Not a valid integer value	Geen geldige integer waarde	\N	\N	\N	\N	\N	\N
form_no_options	form_no_options	ui-form	\N	No options found	Geen opties gevonden	\N	\N	\N	\N	\N	\N
form_not_a_valid_email	form_not_a_valid_email	ui-form	\N	Not a valid email	Geen geldige e-mail	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sys_Language#ab857455; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_Language#ab857455" (code, name, active) FROM stdin;
en	English	t
nl	Nederlands	f
pt	português	f
es	español	f
de	Deutsch	f
it	italiano	f
fr	français	f
xx	My language	f
\.


--
-- Data for Name: sys_Plugin#4fafb60a; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_Plugin#4fafb60a" (id, label, path, description) FROM stdin;
scheduledjobs	scheduledjobs	scheduledjobs	\N
tagwizard	tagwizard	tagwizard	\N
references	references	references	\N
navigator	navigator	navigator	\N
sorta	sorta	sorta	\N
directory	directory	directory	\N
swagger	swagger	swagger	\N
usermanager	usermanager	usermanager	\N
feedback	feedback	feedback	\N
contact	contact	contact	\N
mappingservice	mappingservice	mappingservice	\N
menumanager	menumanager	menumanager	\N
scripts	scripts	scripts	\N
useraccount	useraccount	useraccount	\N
news	news	news	\N
logmanager	logmanager	logmanager	\N
permissionmanager	permissionmanager	permissionmanager	\N
redirect	redirect	redirect	\N
thememanager	thememanager	thememanager	\N
app	app	app	\N
settings	settings	settings	\N
dataexplorer	dataexplorer	dataexplorer	\N
security-ui	security-ui	security-ui	\N
void	void	void	\N
importwizard	importwizard	importwizard	\N
searchAll	searchAll	searchAll	\N
jobs	jobs	jobs	\N
data-row-edit	data-row-edit	data-row-edit	\N
home	home	home	\N
questionnaires	questionnaires	questionnaires	\N
background	background	background	\N
one-click-importer	one-click-importer	one-click-importer	\N
appmanager	appmanager	appmanager	\N
metadata-manager	metadata-manager	metadata-manager	\N
\.


--
-- Data for Name: sys_StaticContent#f1dd2665; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_StaticContent#f1dd2665" (key_, content) FROM stdin;
home	<div class="jumbotron jumbotron-fluid">\n  <div class="container">\n    <h1 class="display-4">Flexible software for scientific data</h1>\n    <p class="lead">Process, manage, query, annotate, integrate, analyse, share</p>\n    <a class="btn btn-primary btn-lg" href="https://molgenis.gitbooks.io/molgenis/content/" role="button" target="_blank'">Learn more</a>\n  </div>\n</div>
\.


--
-- Data for Name: sys_beacons_Beacon#8e99cfb8; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_beacons_Beacon#8e99cfb8" (id, name, api_version, beacon_organization, description, version, welcome_url) FROM stdin;
\.


--
-- Data for Name: sys_beacons_Beacon#8e99cfb8_data_sets; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_beacons_Beacon#8e99cfb8_data_sets" ("order", id, data_sets) FROM stdin;
\.


--
-- Data for Name: sys_beacons_BeaconDataset#17b7de29; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_beacons_BeaconDataset#17b7de29" (id, label, description, data_set_entity_type, genome_browser_attributes) FROM stdin;
\.


--
-- Data for Name: sys_beacons_BeaconOrganization#02fc7b88; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_beacons_BeaconOrganization#02fc7b88" (id, name, description, address, welcome_url, contact_url, logo_url) FROM stdin;
\.


--
-- Data for Name: sys_dec_DecoratorConfi#e9347da9_parameters; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_dec_DecoratorConfi#e9347da9_parameters" ("order", id, parameters) FROM stdin;
\.


--
-- Data for Name: sys_dec_DecoratorConfiguration#e9347da9; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_dec_DecoratorConfiguration#e9347da9" (id, "entityTypeId") FROM stdin;
\.


--
-- Data for Name: sys_dec_DecoratorParameters#0c01537a; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_dec_DecoratorParameters#0c01537a" (id, decorator, parameters) FROM stdin;
\.


--
-- Data for Name: sys_dec_DynamicDecorator#8c3531bb; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_dec_DynamicDecorator#8c3531bb" (id, label, description, schema) FROM stdin;
ownership	Ownership decorator	When entities are added to the decorated repository, their owner is set to the value of the ownerAttribute.	{\n  "title": "Questionnaire",\n  "type": "object",\n  "properties": {\n    "ownerAttribute": {\n      "type": "string",\n      "description": "Name of the owner attribute"\n    }\n  },\n  "required": [\n    "ownerAttribute"\n  ]\n}
icd10expander	ICD-10 Query Expander	Expands queries on an attribute that refers to an entity type with ICD-10 codes.	{\n  "title": "Icd10Expander",\n  "type": "object",\n  "properties": {\n    "icd10EntityTypeId": {\n      "type": "string",\n      "description": "The entity type containing the ICD-10 data."\n    },\n    "expandAttribute": {\n      "type": "string",\n      "description": "The attribute on which the query expansion will be applied."\n    }\n  },\n  "required": [\n    "icd10EntityTypeId",\n    "expandAttribute"\n  ]\n}
\.


--
-- Data for Name: sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks" ("order", id, molgenis_reference_tracks) FROM stdin;
\.


--
-- Data for Name: sys_genomebrowser_GenomeBrowserAttributes#bf815a63; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63" (id, "default", "order", pos, chr, ref, alt, stop) FROM stdin;
simple1	t	0	start	chr	\N	\N	\N
VCF	t	1	POS	#CHROM	REF	ALT	\N
full	t	2	start	chr	ref	alt	stop
simple2	t	3	POS	#CHROM	\N	\N	\N
\.


--
-- Data for Name: sys_genomebrowser_GenomeBrowserSettings#294012a4; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_genomebrowser_GenomeBrowserSettings#294012a4" (id, label, entity, genome_browser_attrs, "labelAttr", track_type, exon_key, "scoreAttr", attrs, molgenis_reference_tracks_mode, actions, feature_info_plugin) FROM stdin;
\.


--
-- Data for Name: sys_idx_IndexAction#43bbc99b; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_idx_IndexAction#43bbc99b" (id, "creationDateTime", "indexActionGroup", "actionOrder", "entityTypeId", "entityId", "indexStatus") FROM stdin;
\.


--
-- Data for Name: sys_idx_IndexActionGroup#dd7eea75; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_idx_IndexActionGroup#dd7eea75" (id, count) FROM stdin;
\.


--
-- Data for Name: sys_job_AmazonBucketJobExecution#f9fb2a28; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_AmazonBucketJobExecution#f9fb2a28" (bucket, key, expression, "accessKey", "secretKey", region, "targetEntityId", file, extension, identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_FileIngestJobExecution#091fdb52; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_FileIngestJobExecution#091fdb52" (file, url, loader, "targetEntityId", identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_IndexJobExecution#1d1bc397; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_IndexJobExecution#1d1bc397" ("indexActionJobID", identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
aaaac3fyimfhtzw2vuwyxoyaae	aaaac3fyimhubzw2vuwyxoyaae	\N	SUCCESS	Index	2019-08-22 07:38:18+00	2019-08-22 07:38:18+00	2019-08-22 07:38:26+00	9	9	Finished indexing for transaction id: [aaaac3fyimfhtzw2vuwyxoyaae]	09:38:18.330 CEST - Execution started.\n09:38:18.363 CEST - Start indexing for transaction id: [aaaac3fyimfhtzw2vuwyxoyaae]\n09:38:18.496 CEST - progress (0, Indexing sys_md_EntityType)\n09:38:21.209 CEST - progress (1, Indexing sys_md_Package)\n09:38:22.917 CEST - progress (2, Indexing sys_md_Attribute)\n09:38:24.990 CEST - progress (3, Indexing it_emx_autoid_testAutoId)\n09:38:25.126 CEST - progress (4, Indexing sys_negotiator_NegotiatorEntityConfig)\n09:38:25.273 CEST - progress (5, Indexing sys_genomebrowser_GenomeBrowserSettings)\n09:38:25.398 CEST - progress (6, Indexing sys_sec_Group)\n09:38:25.546 CEST - progress (7, Indexing sys_beacons_BeaconDataset)\n09:38:25.788 CEST - progress (8, Indexing sys_job_ScheduledJobType)\n09:38:26.021 CEST - progress (9, Executed all index actions, cleaning up the actions...)\n09:38:26.082 CEST - progress (9, Cleaned up the actions.)\n09:38:26.082 CEST - Refresh index start\n09:38:26.217 CEST - Refresh index done\n09:38:26.218 CEST - Finished indexing for transaction id: [aaaac3fyimfhtzw2vuwyxoyaae]\n09:38:26.218 CEST - Execution successful. Time spent: 7s 887ms \n	\N	\N	\N	\N
aaaac3fyipvxpzw2vuwyxoyaae	aaaac3fyipv2vzw2vuwyxoyaae	\N	SUCCESS	Index	2019-08-22 07:39:14+00	2019-08-22 07:39:14+00	2019-08-22 07:39:15+00	1	1	Finished indexing for transaction id: [aaaac3fyipvxpzw2vuwyxoyaae]	09:39:14.737 CEST - Execution started.\n09:39:14.759 CEST - Start indexing for transaction id: [aaaac3fyipvxpzw2vuwyxoyaae]\n09:39:14.778 CEST - progress (0, Indexing sys_sec_Token.aaaac3fyipvxrzw2vuwyxoyaae)\n09:39:14.871 CEST - progress (1, Executed all index actions, cleaning up the actions...)\n09:39:14.895 CEST - progress (1, Cleaned up the actions.)\n09:39:14.895 CEST - Refresh index start\n09:39:15.054 CEST - Refresh index done\n09:39:15.054 CEST - Finished indexing for transaction id: [aaaac3fyipvxpzw2vuwyxoyaae]\n09:39:15.055 CEST - Execution successful. Time spent: 317ms \n	\N	\N	\N	\N
aaaac3fyiq72xzw2vuwyxoyaae	aaaac3fyirar5zw2vuwyxoyaae	\N	SUCCESS	Index	2019-08-22 07:39:36+00	2019-08-22 07:39:36+00	2019-08-22 07:39:37+00	4	4	Finished indexing for transaction id: [aaaac3fyiq72xzw2vuwyxoyaae]	09:39:36.613 CEST - Execution started.\n09:39:36.629 CEST - Start indexing for transaction id: [aaaac3fyiq72xzw2vuwyxoyaae]\n09:39:36.664 CEST - progress (0, Indexing sys_job_FileIngestJobExecution)\n09:39:36.940 CEST - progress (1, Indexing sys_job_AmazonBucketJobExecution)\n09:39:37.191 CEST - progress (2, Indexing sys_set_StyleSheet)\n09:39:37.520 CEST - progress (3, Indexing sys_FileMeta.aaaac3fyiq74lzw2vuwyxoyaae)\n09:39:37.552 CEST - progress (4, Executed all index actions, cleaning up the actions...)\n09:39:37.581 CEST - progress (4, Cleaned up the actions.)\n09:39:37.581 CEST - Refresh index start\n09:39:37.716 CEST - Refresh index done\n09:39:37.716 CEST - Finished indexing for transaction id: [aaaac3fyiq72xzw2vuwyxoyaae]\n09:39:37.717 CEST - Execution successful. Time spent: 1s 103ms \n	\N	\N	\N	\N
aaaac3fyimhxdzw2vuwyxoyaae	aaaac3fyimidfzw2vuwyxoyaae	\N	SUCCESS	Index	2019-08-22 07:38:18+00	2019-08-22 07:38:26+00	2019-08-22 07:38:26+00	1	1	Finished indexing for transaction id: [aaaac3fyimhxdzw2vuwyxoyaae]	09:38:26.218 CEST - Execution started.\n09:38:26.226 CEST - Start indexing for transaction id: [aaaac3fyimhxdzw2vuwyxoyaae]\n09:38:26.373 CEST - progress (0, Indexing sys_ImportRun.aaaac3fyime3hzw2vuwyxoyaae)\n09:38:26.443 CEST - progress (1, Executed all index actions, cleaning up the actions...)\n09:38:26.477 CEST - progress (1, Cleaned up the actions.)\n09:38:26.477 CEST - Refresh index start\n09:38:26.594 CEST - Refresh index done\n09:38:26.595 CEST - Finished indexing for transaction id: [aaaac3fyimhxdzw2vuwyxoyaae]\n09:38:26.595 CEST - Execution successful. Time spent: 377ms \n	\N	\N	\N	\N
aaaac3fyimbajzw2vuwyxoyaae	aaaac3fyimberzw2vuwyxoyaae	\N	SUCCESS	Index	2019-08-22 07:38:14+00	2019-08-22 07:38:14+00	2019-08-22 07:38:15+00	1	1	Finished indexing for transaction id: [aaaac3fyimbajzw2vuwyxoyaae]	09:38:14.991 CEST - Execution started.\n09:38:15.004 CEST - Start indexing for transaction id: [aaaac3fyimbajzw2vuwyxoyaae]\n09:38:15.045 CEST - progress (0, Indexing sys_sec_Token.aaaac3fyimbarzw2vuwyxoyaae)\n09:38:15.113 CEST - progress (1, Executed all index actions, cleaning up the actions...)\n09:38:15.191 CEST - progress (1, Cleaned up the actions.)\n09:38:15.192 CEST - Refresh index start\n09:38:15.463 CEST - Refresh index done\n09:38:15.463 CEST - Finished indexing for transaction id: [aaaac3fyimbajzw2vuwyxoyaae]\n09:38:15.464 CEST - Execution successful. Time spent: 471ms \n	\N	\N	\N	\N
aaaac3fyime3jzw2vuwyxoyaae	aaaac3fyimfbbzw2vuwyxoyaae	\N	SUCCESS	Index	2019-08-22 07:38:16+00	2019-08-22 07:38:16+00	2019-08-22 07:38:17+00	1	1	Finished indexing for transaction id: [aaaac3fyime3jzw2vuwyxoyaae]	09:38:16.983 CEST - Execution started.\n09:38:16.993 CEST - Start indexing for transaction id: [aaaac3fyime3jzw2vuwyxoyaae]\n09:38:17.019 CEST - progress (0, Indexing sys_ImportRun.aaaac3fyime3hzw2vuwyxoyaae)\n09:38:17.063 CEST - progress (1, Executed all index actions, cleaning up the actions...)\n09:38:17.089 CEST - progress (1, Cleaned up the actions.)\n09:38:17.089 CEST - Refresh index start\n09:38:17.412 CEST - Refresh index done\n09:38:17.413 CEST - Finished indexing for transaction id: [aaaac3fyime3jzw2vuwyxoyaae]\n09:38:17.414 CEST - Execution successful. Time spent: 429ms \n	\N	\N	\N	\N
\.


--
-- Data for Name: sys_job_MappingJobExecution#9d59355f; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_MappingJobExecution#9d59355f" ("mappingProjectId", "targetEntityTypeId", "addSourceAttribute", "packageId", label, identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_OneClickImportJobExecution#c6636b72; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_OneClickImportJobExecution#c6636b72" (file, "entityTypes", package, identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_ResourceCopyJobExecution#79e3e597; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_ResourceCopyJobExecution#79e3e597" (resources, "targetPackage", identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_ResourceDeleteJobExecution#5d6022b0; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_ResourceDeleteJobExecution#5d6022b0" (resources, identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_ResourceDownloadJobExecution#3d0dbc70; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_ResourceDownloadJobExecution#3d0dbc70" (resources, identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_ScheduledJob#d2aed7e4; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_ScheduledJob#d2aed7e4" (id, name, description, "cronExpression", active, "user", "failureEmail", "successEmail", type, parameters) FROM stdin;
\.


--
-- Data for Name: sys_job_ScheduledJobType#d68c491a; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_ScheduledJobType#d68c491a" (name, label, description, "jobExecutionType", schema) FROM stdin;
BucketIngest	Bucket ingest	This job downloads a file from a URL and imports it into MOLGENIS.	sys_job_AmazonBucketJobExecution	{'title': 'Bucket Ingest Job','type': 'object','properties': { 'bucket': {'type': 'string', 'description': 'The name of the bucket.'},'key': {'type': 'string', 'description': 'Expression to match the file key'}, 'accessKey': { 'type': 'string', 'description': 'the access key to be used to login to the amazon bucket'},'secretKey': {'type': 'string', 'description': 'the secretkey to be used to login to the amazon bucket'},'expression': {'type': 'boolean', 'description': 'Is the key an expression or an exact match'},'extension': {'type': 'string', 'description': 'Optional extension of the file, is not part of the key in the bucket'},'region': {'type': 'string', 'description': 'The region where the amazon bucket is located'},'targetEntityId': {'type': 'string', 'description': 'Target EntityType ID'}},'required': ['bucket','key','accessKey','secretKey','expression','region']}
fileIngest	File ingest	This job downloads a file from a URL and imports it into MOLGENIS.	sys_job_FileIngestJobExecution	{\n  "title": "FileIngest Job",\n  "type": "object",\n  "properties": {\n    "url": {\n      "type": "string",\n      "format": "uri",\n      "description": "URL to download the file to ingest from"\n    },\n    "loader": {\n      "enum": [\n        "CSV"\n      ],\n      "description": "Loader used to ingest the file"\n    },\n    "targetEntityId": {\n      "type": "string",\n      "description": "ID of the entity to import to"\n    }\n  },\n  "required": [\n    "url",\n    "loader",\n    "targetEntityId"\n  ]\n}
mapping	Mapping	This job runs a Mapping Project.	sys_job_MappingJobExecution	{"title":"Mapping Job","type":"object","properties":{"mappingProjectId":{"type":"string","description":"The ID of the mapping project"},"targetEntityTypeId":{"type":"string","description":"The ID of the created EntityType, may be an existing EntityType"},"addSourceAttribute":{"type":"boolean","description":"Indicates if a source attribute should be added to the EntityType, ignored when mapping to an existing EntityType"},"packageId":{"type":"string","description":"The ID of the target package, ignored when mapping to an existing EntityType"},"label":{"type":"string","description":"The label of the target EntityType, ignored when mapping to an existing EntityType"}},"required":["mappingProjectId","targetEntityTypeId"]}
script	Script	This job executes a script created in the Scripts plugin.	sys_job_ScriptJobExecution	{\n  "title": "Script Job",\n  "type": "object",\n  "properties": {\n    "name": {\n      "type": "string"\n    },\n    "parameters": {\n      "type": "string"\n    }\n  },\n  "required": [\n    "name"\n  ]\n}
\.


--
-- Data for Name: sys_job_ScriptJobExecution#26f219e1; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_ScriptJobExecution#26f219e1" (name, parameters, identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_job_SortaJobExecution#3df661b2; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_job_SortaJobExecution#3df661b2" (name, "resultEntity", "sourceEntity", "ontologyIri", "deleteUrl", "Threshold", identifier, "user", status, type, "submissionDate", "startDate", "endDate", "progressInt", "progressMax", "progressMessage", log, "resultUrl", "failureEmail", "successEmail", "scheduledJobId") FROM stdin;
\.


--
-- Data for Name: sys_mail_JavaMailProperty#ddcd42a8; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_mail_JavaMailProperty#ddcd42a8" ("mailSettings", key, value) FROM stdin;
\.


--
-- Data for Name: sys_map_AttributeMapping#fdffac26; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_map_AttributeMapping#fdffac26" (identifier, "targetAttribute", "sourceAttributes", algorithm, "algorithmState") FROM stdin;
\.


--
-- Data for Name: sys_map_EntityMapping#4c287e1a; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_map_EntityMapping#4c287e1a" (identifier, "sourceEntityType", "targetEntityType") FROM stdin;
\.


--
-- Data for Name: sys_map_EntityMapping#4c287e1a_attributeMappings; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_map_EntityMapping#4c287e1a_attributeMappings" ("order", identifier, "attributeMappings") FROM stdin;
\.


--
-- Data for Name: sys_map_MappingProject#c2f22991; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_map_MappingProject#c2f22991" (identifier, name, depth) FROM stdin;
\.


--
-- Data for Name: sys_map_MappingProject#c2f22991_mappingtargets; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_map_MappingProject#c2f22991_mappingtargets" ("order", identifier, mappingtargets) FROM stdin;
\.


--
-- Data for Name: sys_map_MappingTarget#8e135dd7; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_map_MappingTarget#8e135dd7" (identifier, target) FROM stdin;
\.


--
-- Data for Name: sys_map_MappingTarget#8e135dd7_entityMappings; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_map_MappingTarget#8e135dd7_entityMappings" ("order", identifier, "entityMappings") FROM stdin;
\.


--
-- Data for Name: sys_md_Attribute#c8d9a252; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_md_Attribute#c8d9a252" (id, name, entity, "sequenceNr", type, "isIdAttribute", "isLabelAttribute", "lookupAttributeIndex", parent, "refEntityType", "isCascadeDelete", "mappedBy", "orderBy", expression, "isNullable", "isAuto", "isVisible", label, description, "isAggregatable", "enumOptions", "rangeMin", "rangeMax", "isReadOnly", "isUnique", "nullableExpression", "visibleExpression", "validationExpression", "defaultValue", "labelEn", "descriptionEn", "labelNl", "descriptionNl", "labelDe", "descriptionDe", "labelEs", "descriptionEs", "labelIt", "descriptionIt", "labelPt", "descriptionPt", "labelFr", "descriptionFr", "labelXx", "descriptionXx") FROM stdin;
aaaac3fyiel7bzw2vuwyxoyabe	id	sys_idx_IndexActionGroup	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyabi	count	sys_idx_IndexActionGroup	1	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyabe	key_	sys_StaticContent	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Key	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyabi	content	sys_StaticContent	1	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Content	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaai	name	sys_scr_ScriptType	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaai	id	sys_L10nString	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	t	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaam	msgid	sys_L10nString	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaaq	namespace	sys_L10nString	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaau	description	sys_L10nString	3	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaaq	en	sys_L10nString	4	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyabe	nl	sys_L10nString	5	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemabzw2vuwyxoyaaq	de	sys_L10nString	6	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaam	es	sys_L10nString	7	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaba	it	sys_L10nString	8	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaaq	pt	sys_L10nString	9	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyabe	fr	sys_L10nString	10	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaby	xx	sys_L10nString	11	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaae	identifier	sys_job_JobExecution	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	t	t	Job ID	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaai	user	sys_job_JobExecution	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Job owner	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaam	status	sys_job_JobExecution	2	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Job status	\N	f	PENDING,RUNNING,CANCELING,SUCCESS,FAILED,CANCELED	\N	\N	f	f	\N	\N	\N	PENDING	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaaq	type	sys_job_JobExecution	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Job type	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaau	submissionDate	sys_job_JobExecution	4	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	t	Job submission date	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaay	startDate	sys_job_JobExecution	5	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Job start date	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaa4	endDate	sys_job_JobExecution	6	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Job end date	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaba	progressInt	sys_job_JobExecution	7	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Progress	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyabe	progressMax	sys_job_JobExecution	8	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Maximum progress	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyabi	progressMessage	sys_job_JobExecution	9	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Progress message	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyabm	log	sys_job_JobExecution	10	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Log	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyabq	resultUrl	sys_job_JobExecution	11	hyperlink	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Result URL	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyabu	failureEmail	sys_job_JobExecution	12	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Failure email	Comma-separated email addresses to send email to if execution fails or is canceled	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaby	successEmail	sys_job_JobExecution	13	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Success email	Comma-separated email addresses to send email to if execution succeeds	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyab4	scheduledJobId	sys_job_JobExecution	14	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	ScheduledJob ID	ID of the ScheduledJob that was executed in this JobExecution, if applicable	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyabq	id	sys_ont_Ontology	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyabu	ontologyIRI	sys_ont_Ontology	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	IRI	IRI which is used to identify an ontology	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaby	ontologyName	sys_ont_Ontology	2	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6jzw2vuwyxoyaae	status	sys_Questionnaire	0	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	f	NOT_STARTED,OPEN,SUBMITTED	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6jzw2vuwyxoyaai	owner	sys_Questionnaire	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6jzw2vuwyxoyaam	submitDate	sys_Questionnaire	2	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Submit date	\N	f	\N	\N	\N	f	f	$('status').value() !== 'SUBMITTED'	$('status').value() === 'SUBMITTED'	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaai	name	sys_scr_ScriptParameter	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Name label	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaay	id	sys_ont_TermFrequency	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	t	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaa4	term	sys_ont_TermFrequency	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaba	frequency	sys_ont_TermFrequency	2	decimal	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyabe	occurrence	sys_ont_TermFrequency	3	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaca	id	sys_Plugin	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyace	label	sys_Plugin	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyaci	path	sys_Plugin	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Path to the plugin	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyacm	description	sys_Plugin	3	string	\N	\N	0	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaay	id	sys_md_Tag	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaa4	objectIRI	sys_md_Tag	1	text	\N	\N	0	\N	\N	\N	\N	\N	\N	t	f	t	Object IRI	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaba	label	sys_md_Tag	2	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyabe	relationIRI	sys_md_Tag	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Relation IRI	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyabi	relationLabel	sys_md_Tag	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Relation label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyabm	codeSystem	sys_md_Tag	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Code system	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaay	id	sys_ont_OntologyTermNodePath	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaa4	nodePath	sys_ont_OntologyTermNodePath	1	text	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaba	root	sys_ont_OntologyTermNodePath	2	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaae	id	sys_set_settings	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Id	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyabi	id	sys_genomebrowser_GenomeBrowserAttributes	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyabm	default	sys_genomebrowser_GenomeBrowserAttributes	1	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Default configuration	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyabq	order	sys_genomebrowser_GenomeBrowserAttributes	2	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Order	The order in which the attributes of an entity are matched to these configurations, first match wins	f	\N	\N	\N	f	t	\N	$('default').eq(true).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyabu	pos	sys_genomebrowser_GenomeBrowserAttributes	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Position attribute name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaby	chr	sys_genomebrowser_GenomeBrowserAttributes	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Chromosome attribute name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyab4	ref	sys_genomebrowser_GenomeBrowserAttributes	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Reference allele attribute name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaca	alt	sys_genomebrowser_GenomeBrowserAttributes	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Alternative allele attribute name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyace	stop	sys_genomebrowser_GenomeBrowserAttributes	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Stop position attribute name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaau	id	sys_ont_OntologyTermSynonym	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaay	ontologyTermSynonym	sys_ont_OntologyTermSynonym	1	text	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaa4	Score	sys_ont_OntologyTermSynonym	2	decimal	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaba	Combined_Score	sys_ont_OntologyTermSynonym	3	decimal	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyace	identifier	sys_ont_MatchingTaskContent	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaci	matchTerm	sys_ont_MatchingTaskContent	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Matched ontology term	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyacm	score	sys_ont_MatchingTaskContent	2	decimal	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Score of the match	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyacq	validated	sys_ont_MatchingTaskContent	3	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	Indication if the match was validated	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyabe	id	sys_dec_DynamicDecorator	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyabi	label	sys_dec_DynamicDecorator	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyabm	description	sys_dec_DynamicDecorator	2	string	\N	\N	1	\N	\N	\N	\N	\N	\N	f	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyabq	schema	sys_dec_DynamicDecorator	3	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Schema	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaca	id	sys_FileMeta	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Id	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyace	filename	sys_FileMeta	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Filename	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaci	contentType	sys_FileMeta	2	string	\N	\N	0	\N	\N	\N	\N	\N	\N	t	f	t	Content-type	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyacm	size	sys_FileMeta	3	long	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Size	File size in bytes	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyacq	url	sys_FileMeta	4	hyperlink	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	URL	File download URL	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaae	id	sys_ImportRun	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	\N	automatically generated internal id, only for internal use.	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaai	startDate	sys_ImportRun	1	datetime	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaam	endDate	sys_ImportRun	2	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaaq	username	sys_ImportRun	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaau	status	sys_ImportRun	4	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	RUNNING,FINISHED,FAILED	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaay	message	sys_ImportRun	5	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaa4	progress	sys_ImportRun	6	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaba	importedEntities	sys_ImportRun	7	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyabe	notify	sys_ImportRun	8	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Boolean to indicate whether or not to send an email on job completion	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaau	id	sys_beacons_BeaconOrganization	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Organization identifier	Unique identifier of an organization	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaay	name	sys_beacons_BeaconOrganization	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Organization name	Name of the organization	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaa4	description	sys_beacons_BeaconOrganization	2	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Organization description	Description of the organization	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaba	address	sys_beacons_BeaconOrganization	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Organization address	Address of the organization	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyabe	welcome_url	sys_beacons_BeaconOrganization	4	hyperlink	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Organization welcome URL	URL of the website of the organization	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyabi	contact_url	sys_beacons_BeaconOrganization	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Contact URL	URL with the contact for the beacon operator/maintainer	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyabm	logo_url	sys_beacons_BeaconOrganization	6	hyperlink	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Organization logo	URL to the logo (PNG/JPG format) of the organization	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaa4	id	sys_sec_RecoveryCode	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	t	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaba	userId	sys_sec_RecoveryCode	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	User identifier	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyabe	code	sys_sec_RecoveryCode	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Recovery code	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5rzw2vuwyxoyaae	registrationId	sys_sec_oidc_OidcClient	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	t	Registration ID	Registration identifier	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaae	clientId	sys_sec_oidc_OidcClient	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Client ID	Client identifier	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaai	clientSecret	sys_sec_oidc_OidcClient	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Client secret	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaam	clientName	sys_sec_oidc_OidcClient	3	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Client name	Client name to be presented to the end user	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaaq	clientAuthenticationMethod	sys_sec_oidc_OidcClient	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Authentication	Client authentication method	f	\N	\N	\N	f	f	\N	\N	\N	basic	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaau	authorizationGrantType	sys_sec_oidc_OidcClient	5	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Grant type	Authorization grant type	f	authorization_code,implicit,refresh_token	\N	\N	f	f	\N	\N	\N	authorization_code	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaay	scopes	sys_sec_oidc_OidcClient	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Scopes	Comma-separated set of scopes	f	\N	\N	\N	f	f	\N	\N	\N	openid,email,profile	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaa4	providerDetails	sys_sec_oidc_OidcClient	7	compound	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Provider details	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyaba	authorizationUri	sys_sec_oidc_OidcClient	8	hyperlink	\N	\N	\N	aaaac3fyiel5tzw2vuwyxoyaa4	\N	\N	\N	\N	\N	f	f	t	Authorization URI	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5tzw2vuwyxoyabe	tokenUri	sys_sec_oidc_OidcClient	9	hyperlink	\N	\N	\N	aaaac3fyiel5tzw2vuwyxoyaa4	\N	\N	\N	\N	\N	f	f	t	Token URI	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaae	jwkSetUri	sys_sec_oidc_OidcClient	10	hyperlink	\N	\N	\N	aaaac3fyiel5tzw2vuwyxoyaa4	\N	\N	\N	\N	\N	f	f	t	JWKS URI	JSON Web Key Set URI	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaai	userInfoUri	sys_sec_oidc_OidcClient	11	hyperlink	\N	\N	\N	aaaac3fyiel5tzw2vuwyxoyaa4	\N	\N	\N	\N	\N	f	f	t	User info URI	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaam	userNameAttributeName	sys_sec_oidc_OidcClient	12	string	\N	\N	\N	aaaac3fyiel5tzw2vuwyxoyaa4	\N	\N	\N	\N	\N	f	f	t	Username attribute	Username attribute name	f	\N	\N	\N	f	f	\N	\N	\N	sub	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaba	id	sys_sec_User	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	\N	automatically generated internal id, only for internal use.	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyabe	username	sys_sec_User	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Username	\N	f	\N	\N	\N	t	t	\N	\N	$('username').matches(/^[\\S].+[\\S]$/).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyabi	password_	sys_sec_User	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Password	This is the hashed password, enter a new plaintext password to update.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyabm	activationCode	sys_sec_User	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Activation code	Used as alternative authentication mechanism to verify user email and/or if user has lost password.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyabq	active	sys_sec_User	4	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Active	Boolean to indicate if this account can be used to login	t	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyabu	superuser	sys_sec_User	5	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Superuser	\N	t	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaby	FirstName	sys_sec_User	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	First name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyab4	MiddleNames	sys_sec_User	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Middle names	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaca	LastName	sys_sec_User	8	string	\N	\N	0	\N	\N	\N	\N	\N	\N	t	f	t	Last name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyace	Title	sys_sec_User	9	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Title	An academic title, e.g. Prof.dr, PhD	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaci	Affiliation	sys_sec_User	10	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Affiliation	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaae	Department	sys_sec_User	11	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Added from the old definition of MolgenisUser. Department of this contact.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaai	Role	sys_sec_User	12	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Indicate role of the contact, e.g. lab worker or PI.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaam	Address	sys_sec_User	13	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	The address of the Contact.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaaq	Phone	sys_sec_User	14	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	The telephone number of the Contact including the suitable area codes.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaau	Email	sys_sec_User	15	email	\N	\N	0	\N	\N	\N	\N	\N	\N	f	f	t	\N	The email address of the Contact.	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaay	Fax	sys_sec_User	16	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	The fax number of the Contact.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaa4	tollFreePhone	sys_sec_User	17	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Toll-free phone	A toll free phone number for the Contact, including suitable area codes.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaba	City	sys_sec_User	18	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Added from the old definition of MolgenisUser. City of this contact.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyabe	Country	sys_sec_User	19	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Added from the old definition of MolgenisUser. Country of this contact.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyabi	changePassword	sys_sec_User	20	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Change password	If true the user must first change his password before he can proceed	t	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyabm	use2fa	sys_sec_User	21	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Use two factor authentication	Enables two factor authentication for this user if the application supports it	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyabq	languageCode	sys_sec_User	22	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Language code	Selected language for this site.	f	en,nl,de,es,it,pt,fr,xx	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyabu	googleAccountId	sys_sec_User	23	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Google account ID	An identifier for the user, unique among all Google accounts and never reused.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaau	id	sys_FreemarkerTemplate	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Id	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaay	Name	sys_FreemarkerTemplate	1	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Name	Template name (must start with 'view-' and end with '.ftl')	f	\N	\N	\N	f	t	\N	\N	$('Name').matches(/^view-.*\\.ftl$/).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaa4	Value	sys_FreemarkerTemplate	2	script	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Value	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyace	id	sys_sec_UserSecret	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Identifer	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel57zw2vuwyxoyaae	userId	sys_sec_UserSecret	1	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	User identifier	\N	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel57zw2vuwyxoyaai	secret	sys_sec_UserSecret	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Secret	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel57zw2vuwyxoyaam	last_failed_authentication	sys_sec_UserSecret	3	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Is last successful authenticated at	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel57zw2vuwyxoyaaq	failed_login_attempts	sys_sec_UserSecret	4	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Failed login attempts	\N	f	\N	\N	\N	f	f	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaae	id	sys_ont_OntologyTermDynamicAnnotation	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaai	name	sys_ont_OntologyTermDynamicAnnotation	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaam	value	sys_ont_OntologyTermDynamicAnnotation	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaaq	label	sys_ont_OntologyTermDynamicAnnotation	3	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaam	code	sys_Language	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	Lowercase ISO 639 alpha-2 or alpha-3 code	f	\N	\N	\N	t	t	\N	\N	/^[a-z]{2,3}$/.test($('code').value())	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaaq	name	sys_Language	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaau	active	sys_Language	2	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaaq	key	sys_md_Property	0	string	t	t	0	\N	\N	\N	\N	\N	\N	f	f	t	\N	The key of the property	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaau	value	sys_md_Property	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	The value of the property	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaca	id	sys_negotiator_NegotiatorConfig	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Identifier for this config	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyace	negotiator_url	sys_negotiator_NegotiatorConfig	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Negotiator URL	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaci	username	sys_negotiator_NegotiatorConfig	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Username for the negotiator	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyacm	password	sys_negotiator_NegotiatorConfig	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Password for the negotiator	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaaq	id	sys_App	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaau	label	sys_App	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaay	description	sys_App	2	text	\N	\N	0	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaa4	isActive	sys_App	3	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Active	\N	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaba	appVersion	sys_App	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	App version	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyabe	apiDependency	sys_App	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	API dependency version	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyabi	templateContent	sys_App	6	html	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Template content	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyabm	resourceFolder	sys_App	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Resource folder	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyabq	name	sys_App	8	string	\N	\N	0	\N	\N	\N	\N	\N	\N	f	f	t	Name	The name of this app	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyabu	appConfig	sys_App	9	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Runtime Application configuration	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaby	includeMenuAndFooter	sys_App	10	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Include a menu above your app and a footer below	\N	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5lzw2vuwyxoyaae	identifier	sys_map_AttributeMapping	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5lzw2vuwyxoyaai	targetAttribute	sys_map_AttributeMapping	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5lzw2vuwyxoyaam	sourceAttributes	sys_map_AttributeMapping	2	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5lzw2vuwyxoyaaq	algorithm	sys_map_AttributeMapping	3	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5lzw2vuwyxoyaau	algorithmState	sys_map_AttributeMapping	4	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	CURATED,GENERATED_HIGH,GENERATED_LOW,DISCUSS,MISSING_TARGET	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaae	id	sys_sec_oidc_OidcUserMapping	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaai	label	sys_sec_oidc_OidcUserMapping	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaam	oidcClient	sys_sec_oidc_OidcUserMapping	2	xref	\N	\N	\N	\N	sys_sec_oidc_OidcClient	\N	\N	\N	\N	f	f	t	OIDC client	OpenID Connect client	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaaq	oidcUsername	sys_sec_oidc_OidcUserMapping	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	OIDC username	OpenID Connect username	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaau	user	sys_sec_oidc_OidcUserMapping	4	xref	\N	\N	\N	\N	sys_sec_User	\N	\N	\N	\N	f	f	t	User	MOLGENIS user	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaam	name	sys_job_SortaJobExecution	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaaq	resultEntity	sys_job_SortaJobExecution	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaau	sourceEntity	sys_job_SortaJobExecution	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaay	ontologyIri	sys_job_SortaJobExecution	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaa4	deleteUrl	sys_job_SortaJobExecution	4	hyperlink	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaba	Threshold	sys_job_SortaJobExecution	5	decimal	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7fzw2vuwyxoyaau	name	sys_job_ScriptJobExecution	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Name	Name of the script to run	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7fzw2vuwyxoyaay	parameters	sys_job_ScriptJobExecution	1	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Parameter values	\N	f	\N	\N	\N	f	f	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaba	resources	sys_job_ResourceDownloadJobExecution	0	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	resources	List of resources to be downloaded.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaam	scheme	sys_set_OpenCpuSettings	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	URI scheme	Open CPU URI scheme (e.g. http).	f	\N	\N	\N	f	f	\N	\N	\N	http	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaaq	host	sys_set_OpenCpuSettings	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	URI host	Open CPU URI host (e.g. localhost).	f	\N	\N	\N	f	f	\N	\N	\N	localhost	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaau	port	sys_set_OpenCpuSettings	2	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	URI port	Open CPU URI port (e.g. 8004).	f	\N	\N	\N	f	f	\N	\N	\N	8004	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6bzw2vuwyxoyaay	rootPath	sys_set_OpenCpuSettings	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	URI path	Open CPU URI root path (e.g. /ocpu/).	f	\N	\N	\N	f	f	\N	\N	\N	/ocpu/	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyabi	id	sys_set_StyleSheet	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyabm	name	sys_set_StyleSheet	1	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyabq	bootstrap3Theme	sys_set_StyleSheet	2	file	\N	\N	\N	\N	sys_FileMeta	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyabu	bootstrap4Theme	sys_set_StyleSheet	3	file	\N	\N	\N	\N	sys_FileMeta	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel57zw2vuwyxoyaau	id	sys_dec_DecoratorParameters	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel57zw2vuwyxoyaay	decorator	sys_dec_DecoratorParameters	1	xref	\N	\N	\N	\N	sys_dec_DynamicDecorator	\N	\N	\N	\N	f	f	t	Decorator	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel57zw2vuwyxoyaa4	parameters	sys_dec_DecoratorParameters	2	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Parameters	Decorator parameters in JSON	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyacq	general_	sys_set_dataexplorer	0	compound	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	General	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyacu	searchbox	sys_set_dataexplorer	1	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyacq	\N	\N	\N	\N	\N	f	f	t	Show search box	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyacy	item_select_panel	sys_set_dataexplorer	2	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyacq	\N	\N	\N	\N	\N	f	f	t	Show data item selection	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyac4	launch_wizard	sys_set_dataexplorer	3	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyacq	\N	\N	\N	\N	\N	f	f	t	Launch data item filter wizard	\N	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyada	header_abbreviate	sys_set_dataexplorer	4	int	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyacq	\N	\N	\N	\N	\N	f	f	t	Entity description abbreviation length	\N	f	\N	\N	\N	f	f	\N	\N	\N	180	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyade	show_navigator_link	sys_set_dataexplorer	5	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyacq	\N	\N	\N	\N	\N	t	f	t	Show a link to the navigator for the package of the selected entity	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7hzw2vuwyxoyadi	mods	sys_set_dataexplorer	6	compound	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Modules	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaae	mod_aggregates	sys_set_dataexplorer	7	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	f	f	t	Aggregates	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaai	aggregates	sys_set_dataexplorer	8	compound	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	t	f	t	Aggregates	\N	f	\N	\N	\N	f	f	\N	$('mod_aggregates').eq(true).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaam	agg_distinct	sys_set_dataexplorer	9	bool	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaai	\N	\N	\N	\N	\N	f	f	t	Distinct aggregates	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaaq	agg_distinct_overrides	sys_set_dataexplorer	10	text	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaai	\N	\N	\N	\N	\N	t	f	t	Distinct attribute overrides	JSON object that maps entity names to attribute names	f	\N	\N	\N	f	f	\N	$('agg_distinct').eq(true).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaau	mod_data	sys_set_dataexplorer	11	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	f	f	t	Data	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaay	data	sys_set_dataexplorer	12	compound	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	t	f	t	Data	\N	f	\N	\N	\N	f	f	\N	$('mod_data').eq(true).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaa4	genomebrowser	sys_set_dataexplorer	13	compound	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaay	\N	\N	\N	\N	\N	t	f	t	Genome Browser	\N	f	\N	\N	\N	f	f	\N	$('data_genome_browser').eq(true).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaba	gb_init	sys_set_dataexplorer	14	compound	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaa4	\N	\N	\N	\N	\N	t	f	t	Initialization	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyabe	gb_init_browser_links	sys_set_dataexplorer	15	text	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaba	\N	\N	\N	\N	\N	f	f	t	Browser links	\N	f	\N	\N	\N	f	f	\N	\N	\N	{Ensembl: 'http://www.ensembl.org/Homo_sapiens/Location/View?r=${chr}:${start}-${end}',UCSC: 'http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg19&position=chr${chr}:${start}-${end}',Sequence: 'http://www.derkholm.net:8080/das/hg19comp/sequence?segment=${chr}:${start},${end}'}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyabi	gb_init_coord_system	sys_set_dataexplorer	16	text	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaba	\N	\N	\N	\N	\N	f	f	t	Coordinate system	\N	f	\N	\N	\N	f	f	\N	\N	\N	{speciesName: 'Human',taxon: 9606,auth: 'GRCh',version: '37',ucscName: 'hg19'}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyabm	gb_init_location	sys_set_dataexplorer	17	text	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaba	\N	\N	\N	\N	\N	f	f	t	Location	\N	f	\N	\N	\N	f	f	\N	\N	\N	chr:'1',viewStart:10000000,viewEnd:10100000,cookieKey:'human',nopersist:true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaca	package	sys_job_OneClickImportJobExecution	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Package name	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaae	resources	sys_job_ResourceDeleteJobExecution	0	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Resources	JSON containing the resources to delete.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyace	bucket	sys_job_AmazonBucketJobExecution	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Bucket name	The name of the amazon bucket.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaae	key	sys_job_AmazonBucketJobExecution	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Key	Expression to match the file key	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyabq	gb_init_sources	sys_set_dataexplorer	18	text	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaba	\N	\N	\N	\N	\N	f	f	t	Sources	\N	f	\N	\N	\N	f	f	\N	\N	\N	[{name:'Genome',twoBitURI:'//www.biodalliance.org/datasets/hg19.2bit',tier_type: 'sequence'},{name: 'Genes',desc: 'Gene structures from GENCODE 19',bwgURI: '//www.biodalliance.org/datasets/gencode.bb',stylesheet_uri: '//www.biodalliance.org/stylesheets/gencode.xml',collapseSuperGroups: true,trixURI:'//www.biodalliance.org/datasets/geneIndex.ix'},{name: 'Repeats',desc: 'Repeat annotation from Ensembl 59',bwgURI: '//www.biodalliance.org/datasets/repeats.bb',stylesheet_uri: '//www.biodalliance.org/stylesheets/bb-repeats.xml'},{name: 'Conservation',desc: 'Conservation',bwgURI: '//www.biodalliance.org/datasets/phastCons46way.bw',noDownsample: true}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyabu	gb_init_highlight_region	sys_set_dataexplorer	19	bool	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaba	\N	\N	\N	\N	\N	f	f	t	Highlight region	\N	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaby	data_genome_browser	sys_set_dataexplorer	20	bool	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaay	\N	\N	\N	\N	\N	f	f	t	Genome Browser	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyab4	use_vue_data_row_edit	sys_set_dataexplorer	21	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	f	f	t	Edit the data row using the forms edit plugin.	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaca	mod_reports	sys_set_dataexplorer	22	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	f	f	t	Reports	\N	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyace	mod_standalone_reports	sys_set_dataexplorer	23	bool	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	t	f	t	Standalone Reports	\N	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyaci	reports	sys_set_dataexplorer	24	compound	\N	\N	\N	aaaac3fyiel7hzw2vuwyxoyadi	\N	\N	\N	\N	\N	t	f	t	Reports	\N	f	\N	\N	\N	f	f	\N	$('mod_reports').eq(true).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyacm	reports_entities	sys_set_dataexplorer	25	text	\N	\N	\N	aaaac3fyiel7jzw2vuwyxoyaci	\N	\N	\N	\N	\N	t	f	t	Reports	Comma-seperated report strings (e.g. MyDataSet:myreport,OtherDataSet:otherreport). The report name refers to an existing FreemarkerTemplate entity or file with name view-<report>-entitiesreport.ftl (e.g. view-myreport-entitiesreport.ftl)	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaae	id	sys_sec_PasswordResetToken	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaai	token	sys_sec_PasswordResetToken	1	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Token	\N	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaam	user	sys_sec_PasswordResetToken	2	xref	\N	\N	\N	\N	sys_sec_User	\N	\N	\N	\N	f	f	t	User	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaaq	expirationDate	sys_sec_PasswordResetToken	3	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Expiration date	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyacq	id	sys_ont_OntologyTermHit	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyacu	Score	sys_ont_OntologyTermHit	1	decimal	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyacy	Combined_Score	sys_ont_OntologyTermHit	2	decimal	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyac4	ontologyTermIRI	sys_ont_OntologyTermHit	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7jzw2vuwyxoyada	ontologyTermName	sys_ont_OntologyTermHit	4	text	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaae	ontologyTermSynonym	sys_ont_OntologyTermHit	5	mref	\N	\N	\N	\N	sys_ont_OntologyTermSynonym	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaai	ontologyTermDynamicAnnotation	sys_ont_OntologyTermHit	6	mref	\N	\N	\N	\N	sys_ont_OntologyTermDynamicAnnotation	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaam	nodePath	sys_ont_OntologyTermHit	7	mref	\N	\N	\N	\N	sys_ont_OntologyTermNodePath	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaaq	ontology	sys_ont_OntologyTermHit	8	xref	\N	\N	\N	\N	sys_ont_Ontology	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaby	id	sys_sec_Token	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyab4	User	sys_sec_Token	1	xref	\N	\N	\N	\N	sys_sec_User	\N	\N	\N	\N	f	f	t	\N	\N	t	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyaca	token	sys_sec_Token	2	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Token	\N	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6dzw2vuwyxoyace	expirationDate	sys_sec_Token	3	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Expiration date	When expiration date is null it will never expire	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaae	creationDate	sys_sec_Token	4	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	t	Creation date	\N	f	\N	\N	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaai	description	sys_sec_Token	5	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyabq	id	sys_idx_IndexAction	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyabu	creationDateTime	sys_idx_IndexAction	1	datetime	\N	t	\N	\N	\N	\N	\N	\N	\N	f	t	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaby	indexActionGroup	sys_idx_IndexAction	2	xref	\N	\N	\N	\N	sys_idx_IndexActionGroup	\N	\N	\N	\N	t	f	t	\N	The group that this index action belongs to	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyab4	actionOrder	sys_idx_IndexAction	3	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	The order in which the action is registered within its IndexActionJob	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaca	entityTypeId	sys_idx_IndexAction	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	The id of the entity type that needs to be indexed (e.g. myEntityType).	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyace	entityId	sys_idx_IndexAction	5	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	The id of the entity that needs to be indexed	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5pzw2vuwyxoyaci	indexStatus	sys_idx_IndexAction	6	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	The status of index action	f	FINISHED,CANCELED,FAILED,STARTED,PENDING	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7fzw2vuwyxoyaae	signup	sys_set_auth	0	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Allow users to sign up	\N	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7fzw2vuwyxoyaai	signup_moderation	sys_set_auth	1	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Sign up moderation	Admins must accept sign up requests before account activation	f	\N	\N	\N	f	f	\N	$('signup').eq(true).value()	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7fzw2vuwyxoyaam	oidcClients	sys_set_auth	2	mref	\N	\N	\N	\N	sys_sec_oidc_OidcClient	\N	\N	\N	\N	t	f	t	Authentication servers	OpenID Connect authentication servers	f	\N	\N	\N	f	f	\N	$('signup').eq(true).value() && $('signup_moderation').eq(false).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7fzw2vuwyxoyaaq	sign_in_2fa	sys_set_auth	3	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Two Factor Authentication	Enable or enforce users to sign in with Google Authenticator.	f	Disabled,Enabled,Enforced	\N	\N	f	f	\N	\N	$('sign_in_2fa').eq('Disabled').or($('signup').not()).or($('signup_moderation')).value()	Disabled	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyabm	indexActionJobID	sys_job_IndexJobExecution	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	ID of the IndexActionJob that contains the group of IndexActions that this index job execution will index.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaba	title	sys_set_app	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Application title	Displayed in browser toolbar.	f	\N	\N	\N	f	f	\N	\N	\N	MOLGENIS	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyabe	logo_href_navbar	sys_set_app	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Logo in navigation bar	HREF to logo image used instead of home plugin label	f	\N	\N	\N	f	f	\N	\N	\N	/img/Logo_Blue_Small.png	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyabi	logo_href_top	sys_set_app	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Logo above navigation bar	HREF to logo image	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyabm	logoTopMaxHeight	sys_set_app	3	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Max height of logo above navigation bar	Set max height for top logo in px	f	\N	\N	\N	f	f	\N	\N	\N	150	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyabq	footer	sys_set_app	4	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Footer text	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaai	expression	sys_job_AmazonBucketJobExecution	2	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Is key expression	Is the key an expression or an exact match	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyabu	molgenis_menu	sys_set_app	5	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Menu	JSON object that describes menu content.	f	\N	\N	\N	f	f	\N	\N	$('molgenis_menu').isValidJson().value()	{\n  "type": "menu",\n  "id": "main",\n  "label": "Home",\n  "items": [\n    {\n      "type": "plugin",\n      "id": "home",\n      "label": "Home"\n    },\n    {\n      "type": "menu",\n      "id": "importdata",\n      "label": "Import data",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "one-click-importer",\n          "label": "Quick data import"\n        },\n        {\n          "type": "plugin",\n          "id": "importwizard",\n          "label": "Advanced data import"\n        }\n      ]\n    },\n    {\n      "type": "plugin",\n      "id": "navigator",\n      "label": "Navigator"\n    },\n    {\n      "type": "plugin",\n      "id": "dataexplorer",\n      "label": "Data Explorer"\n    },\n    {\n      "type": "menu",\n      "id": "dataintegration",\n      "label": "Data Integration",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "metadata-manager",\n          "label": "Metadata Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "mappingservice",\n          "label": "Mapping Service"\n        },\n        {\n          "type": "plugin",\n          "id": "sorta",\n          "label": "SORTA"\n        },\n        {\n          "type": "plugin",\n          "id": "tagwizard",\n          "label": "Tag Wizard"\n        }\n      ]\n    },\n    {\n      "type": "menu",\n      "id": "plugins",\n      "label": "Plugins",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "searchAll",\n          "label": "Search all data"\n        },\n        {\n          "type": "plugin",\n          "id": "swagger",\n          "label": "API documentation"\n        },\n        {\n          "type": "plugin",\n          "id": "appmanager",\n          "label": "App manager"\n        },\n        {\n          "type": "plugin",\n          "id": "feedback",\n          "label": "Feedback"\n        },\n        {\n          "type": "plugin",\n          "id": "jobs",\n          "label": "Job overview"\n        },\n        {\n          "type": "plugin",\n          "id": "questionnaires",\n          "label": "Questionnaires"\n        },\n        {\n          "type": "plugin",\n          "id": "scripts",\n          "label": "Scripts"\n        }\n      ]\n    },\n    {\n      "type": "menu",\n      "id": "admin",\n      "label": "Admin",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "logmanager",\n          "label": "Log manager"\n        },\n        {\n          "type": "plugin",\n          "id": "menumanager",\n          "label": "Menu Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "permissionmanager",\n          "label": "Permission Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "scheduledjobs",\n          "label": "Scheduled Jobs"\n        },\n        {\n          "type": "plugin",\n          "id": "settings",\n          "label": "Settings"\n        },\n        {\n          "type": "plugin",\n          "id": "thememanager",\n          "label": "Theme Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "usermanager",\n          "label": "User Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "security-ui",\n          "label": "Security Manager"\n        }\n      ]\n    },\n    {\n      "type": "plugin",\n      "id": "useraccount",\n      "label": "Account"\n    }\n  ]\n}\n	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaae	language_code	sys_set_app	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Language code	ISO 639 alpha-2 or alpha-3 language code.	f	\N	\N	\N	f	f	\N	\N	\N	en	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaai	bootstrap_theme	sys_set_app	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Bootstrap theme	CSS file name of theme (see molgenis-core-ui/src/main/resources/css/themes).	f	\N	\N	\N	f	f	\N	\N	\N	bootstrap-molgenis-blue.min.css	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaam	css_href	sys_set_app	8	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	CSS href	CSS file name to add custom CSS (see molgenis-core-ui/src/main/resources/css).	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaaq	aggregate_threshold	sys_set_app	9	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Aggregate threshold	Aggregate value counts below this threshold are reported as the threshold. (e.g. a count of 1 is reported as <= 10)	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaau	custom_javascript	sys_set_app	10	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Custom javascript headers	Custom javascript headers, specified as comma separated list. These headers will be included in the molgenis header before the applications own javascript headers. Values not ending with the extension 'js' will be ignored	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaay	tracking	sys_set_app	11	compound	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Tracking	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaa4	ga_privacy_friendly	sys_set_app	12	bool	\N	\N	\N	aaaac3fyiel67zw2vuwyxoyaay	\N	\N	\N	\N	\N	f	f	t	IP anonymization	Disables the cookie wall by using privacy friendly tracking (only works if google analytics accounts are configured correctly, see below)	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyaba	ga_tracking_id	sys_set_app	13	string	\N	\N	\N	aaaac3fyiel67zw2vuwyxoyaay	\N	\N	\N	\N	\N	t	f	t	Google analytics tracking ID	Google analytics tracking ID (e.g. UA-XXXX-Y)	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyabe	ga_acc_privacy_friendly	sys_set_app	14	bool	\N	\N	\N	aaaac3fyiel67zw2vuwyxoyaay	\N	\N	\N	\N	\N	f	f	t	Google analytics account privacy friendly	Confirm that you have configured your Google Analytics account as described here: https://autoriteitpersoonsgegevens.nl/sites/default/files/atoms/files/138._handleiding_privacyvriendelijk_instellen_google_analytics_aug_2018.pdf	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyabi	ga_tracking_id_mgs	sys_set_app	15	string	\N	\N	\N	aaaac3fyiel67zw2vuwyxoyaay	\N	\N	\N	\N	\N	t	f	t	Google analytics tracking ID (MOLGENIS)	Google analytics tracking ID used by MOLGENIS	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel67zw2vuwyxoyabm	ga_acc_privacy_friendly_mgs	sys_set_app	16	bool	\N	\N	\N	aaaac3fyiel67zw2vuwyxoyaay	\N	\N	\N	\N	\N	f	f	t	Google analytics account privacy friendly (MOLGENIS)	Confirm that the MOLGENIS Google Analytics account is configured as described here: https://cbpweb.nl/sites/default/files/atoms/files/handleiding_privacyvriendelijk_instellen_google_analytics_0.pdf	f	\N	\N	\N	t	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaae	tracking_code_footer	sys_set_app	17	script	\N	\N	\N	aaaac3fyiel67zw2vuwyxoyaay	\N	\N	\N	\N	\N	t	f	t	Tracking code footer	JS tracking code that is placed in the footer HTML (e.g. PiWik). This enables the cookie wall.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaai	recaptcha	sys_set_app	18	compound	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Recaptcha	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaam	recaptcha_private_key	sys_set_app	19	string	\N	\N	\N	aaaac3fyiel7bzw2vuwyxoyaai	\N	\N	\N	\N	\N	t	f	t	Recaptcha secret	The secret needed by the server to authenticate with the google servers	f	\N	\N	\N	f	f	$('recaptcha_is_enabled').eq(false).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaaq	recaptcha_public_key	sys_set_app	20	string	\N	\N	\N	aaaac3fyiel7bzw2vuwyxoyaai	\N	\N	\N	\N	\N	t	f	t	Recaptcha site key	The site key needed by the clients to authenticate with the google servers	f	\N	\N	\N	f	f	$('recaptcha_is_enabled').eq(false).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaau	recaptcha_is_enabled	sys_set_app	21	bool	\N	\N	\N	aaaac3fyiel7bzw2vuwyxoyaai	\N	\N	\N	\N	\N	f	f	t	Enable recaptcha	Recaptcha keys need to be set	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaay	recaptcha_verify_uri	sys_set_app	22	hyperlink	\N	\N	\N	aaaac3fyiel7bzw2vuwyxoyaai	\N	\N	\N	\N	\N	f	f	t	The verifying URI for recaptcha	This URI is used to verify the token which is determining if a bot is at work here.	f	\N	\N	\N	f	f	\N	\N	\N	https://www.google.com/recaptcha/api/siteverify	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyaa4	recaptcha_bot_threshold	sys_set_app	23	decimal	\N	\N	\N	aaaac3fyiel7bzw2vuwyxoyaai	\N	\N	\N	\N	\N	f	f	t	Bot threshold	A threshold to determine if a bot is at work here (0.5 is 50% likely to be a bot).	f	\N	\N	\N	f	f	\N	\N	\N	0.5	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyabe	id	sys_ont_OntologyTerm	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyabi	ontologyTermIRI	sys_ont_OntologyTerm	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyabm	ontologyTermName	sys_ont_OntologyTerm	2	text	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyabq	ontologyTermSynonym	sys_ont_OntologyTerm	3	mref	\N	\N	\N	\N	sys_ont_OntologyTermSynonym	t	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyabu	ontologyTermDynamicAnnotation	sys_ont_OntologyTerm	4	mref	\N	\N	\N	\N	sys_ont_OntologyTermDynamicAnnotation	t	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaby	nodePath	sys_ont_OntologyTerm	5	mref	\N	\N	\N	\N	sys_ont_OntologyTermNodePath	t	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyab4	ontology	sys_ont_OntologyTerm	6	xref	\N	\N	\N	\N	sys_ont_Ontology	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyacy	id	sys_md_Package	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyac4	label	sys_md_Package	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyada	description	sys_md_Package	2	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyade	parent	sys_md_Package	3	xref	\N	\N	\N	\N	sys_md_Package	\N	\N	\N	\N	t	f	t	Parent	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyadq	tags	sys_md_Package	6	mref	\N	\N	\N	\N	sys_md_Tag	\N	\N	\N	\N	t	f	t	Tags	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyabe	file	sys_job_FileIngestJobExecution	0	xref	\N	\N	\N	\N	sys_FileMeta	\N	\N	\N	\N	t	f	t	File	The imported file.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyabi	url	sys_job_FileIngestJobExecution	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Url	Url of the file to download.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyabm	loader	sys_job_FileIngestJobExecution	2	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Loader type	\N	f	CSV	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyabq	targetEntityId	sys_job_FileIngestJobExecution	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Target EntityType ID	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyaby	file	sys_job_OneClickImportJobExecution	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Imported file	The file that was imported	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel55zw2vuwyxoyab4	entityTypes	sys_job_OneClickImportJobExecution	1	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Entity types	Imported entity types	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyabe	labelPt	sys_md_EntityType	20	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (pt)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaam	accessKey	sys_job_AmazonBucketJobExecution	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	the access key to be used to login to the amazon bucket	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaaq	secretKey	sys_job_AmazonBucketJobExecution	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	the secret key to be used to login to the amazon bucket	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaau	region	sys_job_AmazonBucketJobExecution	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Region	The region of the amazon bucket.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaay	targetEntityId	sys_job_AmazonBucketJobExecution	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Target EntityType ID	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaa4	file	sys_job_AmazonBucketJobExecution	7	xref	\N	\N	\N	\N	sys_FileMeta	\N	\N	\N	\N	t	f	t	File	The imported file.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaba	extension	sys_job_AmazonBucketJobExecution	8	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Extension	Optional extension of the file, is not part of the key in the bucket	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyabi	name	sys_scr_Script	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Name	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyabm	type	sys_scr_Script	1	xref	\N	\N	\N	\N	sys_scr_ScriptType	\N	\N	\N	\N	f	f	t	Type	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyabq	content	sys_scr_Script	2	script	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Content	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyabu	generateToken	sys_scr_Script	3	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Generate security token	\N	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyaby	resultFileExtension	sys_scr_Script	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Result file extension	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7pzw2vuwyxoyab4	parameters	sys_scr_Script	5	mref	\N	\N	\N	\N	sys_scr_ScriptParameter	\N	\N	\N	\N	t	f	t	Parameters	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyabu	identifier	sys_map_EntityMapping	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaby	sourceEntityType	sys_map_EntityMapping	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyab4	targetEntityType	sys_map_EntityMapping	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaca	attributeMappings	sys_map_EntityMapping	3	mref	\N	\N	\N	\N	sys_map_AttributeMapping	t	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaau	mappingProjectId	sys_job_MappingJobExecution	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Mapping Project ID	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaay	targetEntityTypeId	sys_job_MappingJobExecution	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Target Entity Type ID	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaa4	addSourceAttribute	sys_job_MappingJobExecution	2	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Add source attribute	If the target entity type should have a 'source' attribute. Ignored when mapping to an existing entity type	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaba	packageId	sys_job_MappingJobExecution	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Package	The destination package of the target entity type. Ignored when mapping to an existing entity type.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyabe	label	sys_job_MappingJobExecution	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label	The label of the target entity type. Ignored when mapping to an existing entity type.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaam	resources	sys_job_ResourceCopyJobExecution	0	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Resources	JSON containing the resources to copy.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6xzw2vuwyxoyaaq	targetPackage	sys_job_ResourceCopyJobExecution	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Target package	The ID of the package to copy the resources to.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaca	host	sys_set_MailSettings	0	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	SMTP server host.	f	\N	\N	\N	f	f	\N	\N	\N	smtp.gmail.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyace	port	sys_set_MailSettings	1	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	SMTP server port.	f	\N	\N	\N	f	f	\N	\N	\N	587	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaae	protocol	sys_set_MailSettings	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	Protocol used by the SMTP server.	f	\N	\N	\N	f	f	\N	\N	\N	smtp	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaai	username	sys_set_MailSettings	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Login user of the SMTP server.	f	\N	\N	\N	f	f	\N	\N	\N	molgenis	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaam	password	sys_set_MailSettings	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Login password of the SMTP server.	f	\N	\N	\N	f	f	\N	\N	\N	wQf#=5C&VeD>5[>/	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaaq	defaultEncoding	sys_set_MailSettings	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	Default MimeMessage encoding.	f	\N	\N	\N	f	f	\N	\N	\N	UTF-8	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaau	startTlsEnabled	sys_set_MailSettings	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Do you need TLS with for SMTP server.	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaay	waitQuit	sys_set_MailSettings	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Do you quit when you wait?.	f	\N	\N	\N	f	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaa4	auth	sys_set_MailSettings	8	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	Is authentication required for SMTP server.	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaba	fromAddress	sys_set_MailSettings	9	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	The default from address for SMTP server.	f	\N	\N	\N	f	f	\N	\N	\N	molgenis+admin@gmail.com	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyabi	testConnection	sys_set_MailSettings	11	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	Indicates if the connection should be tested when saving these settings.	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyabq	id	sys_md_EntityType	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyabu	label	sys_md_EntityType	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaby	description	sys_md_EntityType	2	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyab4	package	sys_md_EntityType	3	xref	\N	\N	\N	\N	sys_md_Package	\N	\N	\N	\N	t	f	t	Package	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyace	isAbstract	sys_md_EntityType	5	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Abstract	\N	f	\N	\N	\N	t	f	\N	\N	\N	false	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaci	extends	sys_md_EntityType	6	xref	\N	\N	\N	\N	sys_md_EntityType	\N	\N	\N	\N	t	f	t	Extends	\N	f	\N	\N	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyacm	tags	sys_md_EntityType	7	mref	\N	\N	\N	\N	sys_md_Tag	\N	\N	\N	\N	t	f	t	Tags	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyacq	backend	sys_md_EntityType	8	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Backend	Backend data store	f	PostgreSQL	\N	\N	t	f	\N	\N	\N	PostgreSQL	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyacu	indexingDepth	sys_md_EntityType	9	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Indexing depth	1 = index attributes and referenced entities (default) 2 = index attributes, referenced entities and entities referenced by referenced entities	f	\N	1	\N	f	f	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel75zw2vuwyxoyaae	labelEn	sys_md_EntityType	10	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (en)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaae	descriptionEn	sys_md_EntityType	11	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (en)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaau	labelNl	sys_md_EntityType	12	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (nl)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaay	descriptionNl	sys_md_EntityType	13	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (nl)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyabi	labelDe	sys_md_EntityType	14	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (de)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemabzw2vuwyxoyaae	descriptionDe	sys_md_EntityType	15	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (de)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemabzw2vuwyxoyaau	labelEs	sys_md_EntityType	16	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (es)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemadzw2vuwyxoyaae	descriptionEs	sys_md_EntityType	17	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (es)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaaq	labelIt	sys_md_EntityType	18	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (it)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaau	descriptionIt	sys_md_EntityType	19	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (it)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaae	descriptionPt	sys_md_EntityType	21	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (pt)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaau	labelFr	sys_md_EntityType	22	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (fr)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaay	descriptionFr	sys_md_EntityType	23	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (fr)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyabi	labelXx	sys_md_EntityType	24	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (xx)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyabm	descriptionXx	sys_md_EntityType	25	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (xx)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaci	mailSettings	sys_mail_JavaMailProperty	0	xref	\N	\N	\N	\N	sys_set_MailSettings	\N	\N	\N	\N	f	f	f	MailSettings	Reference to the (unique) MailSettings entity that these properties belong to.	f	\N	\N	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaae	id	sys_dec_DecoratorConfiguration	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaai	entityTypeId	sys_dec_DecoratorConfiguration	1	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Entity Type Identifier	\N	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5jzw2vuwyxoyaam	parameters	sys_dec_DecoratorConfiguration	2	mref	\N	\N	\N	\N	sys_dec_DecoratorParameters	\N	\N	\N	\N	f	f	t	Decorator Parameters	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyaci	identifier	sys_map_MappingTarget	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyacm	entityMappings	sys_map_MappingTarget	1	mref	\N	\N	\N	\N	sys_map_EntityMapping	t	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5nzw2vuwyxoyacq	target	sys_map_MappingTarget	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7rzw2vuwyxoyaae	id	sys_sec_Group	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7rzw2vuwyxoyaai	name	sys_sec_Group	1	string	\N	\N	0	\N	\N	\N	\N	\N	\N	f	f	t	Name	Name of the group. Use kebab-case, e.g. my-group.	f	\N	\N	\N	f	t	\N	\N	$('name').matches(/^[a-z][a-z0-9]*(-[a-z0-9]+)*$/).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7rzw2vuwyxoyaam	label	sys_sec_Group	2	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaae	labelEn	sys_sec_Group	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaai	labelNl	sys_sec_Group	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaam	labelDe	sys_sec_Group	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaaq	labelEs	sys_sec_Group	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaau	labelIt	sys_sec_Group	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaay	labelPt	sys_sec_Group	8	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaa4	labelFr	sys_sec_Group	9	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyaba	labelXx	sys_sec_Group	10	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7tzw2vuwyxoyabe	description	sys_sec_Group	11	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaae	descriptionEn	sys_sec_Group	12	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaai	descriptionNl	sys_sec_Group	13	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaam	descriptionDe	sys_sec_Group	14	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaaq	descriptionEs	sys_sec_Group	15	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaau	descriptionIt	sys_sec_Group	16	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaay	descriptionPt	sys_sec_Group	17	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaa4	descriptionFr	sys_sec_Group	18	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyaba	descriptionXx	sys_sec_Group	19	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyabe	public	sys_sec_Group	20	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Publicly visible	Indication if this group is publicly visible.	f	\N	\N	\N	f	f	\N	\N	\N	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyabm	rootPackage	sys_sec_Group	22	xref	\N	\N	\N	\N	sys_md_Package	t	\N	\N	\N	f	f	t	Root package	Package where this Group's resources reside.	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaay	identifier	sys_map_MappingProject	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaa4	name	sys_map_MappingProject	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyaba	depth	sys_map_MappingProject	2	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	1	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5vzw2vuwyxoyabe	mappingtargets	sys_map_MappingProject	3	mref	\N	\N	\N	\N	sys_map_MappingTarget	t	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyabm	name	sys_job_ScheduledJobType	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	f	t	Name	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyabq	label	sys_job_ScheduledJobType	1	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7bzw2vuwyxoyabu	description	sys_job_ScheduledJobType	2	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaae	jobExecutionType	sys_job_ScheduledJobType	3	xref	\N	\N	\N	\N	sys_md_EntityType	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7dzw2vuwyxoyaai	schema	sys_job_ScheduledJobType	4	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	JSON Schema for the job parameters	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3nzw2vuwyxoyaae	id	sys_sec_Role	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3nzw2vuwyxoyaai	name	sys_sec_Role	1	string	\N	\N	0	\N	\N	\N	\N	\N	\N	f	f	t	Name	Name of the Role. Use screaming snake case, e.g. MY_ROLE.	f	\N	\N	\N	t	t	\N	\N	$('name').matches(/^[A-Z]+[A-Z0-9]*(_[A-Z0-9]+)*$/).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3nzw2vuwyxoyaam	label	sys_sec_Role	2	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaae	labelEn	sys_sec_Role	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaai	labelNl	sys_sec_Role	4	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaam	labelDe	sys_sec_Role	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaaq	labelEs	sys_sec_Role	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaau	labelIt	sys_sec_Role	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaay	labelPt	sys_sec_Role	8	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaa4	labelFr	sys_sec_Role	9	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyaba	labelXx	sys_sec_Role	10	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3tzw2vuwyxoyabe	description	sys_sec_Role	11	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3vzw2vuwyxoyaae	descriptionEn	sys_sec_Role	12	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3xzw2vuwyxoyaae	descriptionNl	sys_sec_Role	13	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3xzw2vuwyxoyaai	descriptionDe	sys_sec_Role	14	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3xzw2vuwyxoyaam	descriptionEs	sys_sec_Role	15	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3xzw2vuwyxoyaaq	descriptionIt	sys_sec_Role	16	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3xzw2vuwyxoyaau	descriptionPt	sys_sec_Role	17	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3xzw2vuwyxoyaay	descriptionFr	sys_sec_Role	18	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3xzw2vuwyxoyaa4	descriptionXx	sys_sec_Role	19	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3zzw2vuwyxoyaae	group	sys_sec_Role	20	xref	\N	\N	\N	\N	sys_sec_Group	\N	\N	\N	\N	t	f	t	Group	Optional reference to the group in which this is a Role.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel3zzw2vuwyxoyaai	includes	sys_sec_Role	21	mref	\N	\N	\N	\N	sys_sec_Role	\N	\N	\N	\N	t	f	t	Includes	These roles are included with this role.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyabu	id	sys_beacons_BeaconDataset	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Beacon dataset identifier	Unique identifier of an beacon dataset	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaby	label	sys_beacons_BeaconDataset	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Beacon dataset label	Label of beacon dataset	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyab4	description	sys_beacons_BeaconDataset	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Beacon dataset description	Description of beacon dataset	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaca	data_set_entity_type	sys_beacons_BeaconDataset	3	xref	\N	\N	\N	\N	sys_md_EntityType	\N	\N	\N	\N	f	f	t	Beacon dataset entityType	Beacon dataset entityType	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyace	genome_browser_attributes	sys_beacons_BeaconDataset	4	xref	\N	\N	\N	\N	sys_genomebrowser_GenomeBrowserAttributes	\N	\N	\N	\N	f	f	t	GenomeBrowser attributes	GenomeBrowser attributes for the beacon dataset	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6nzw2vuwyxoyaae	id	sys_md_Attribute	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	f	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaae	name	sys_md_Attribute	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Name	\N	f	\N	\N	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaai	entity	sys_md_Attribute	2	xref	\N	\N	\N	\N	sys_md_EntityType	\N	\N	\N	\N	f	f	t	Entity	\N	f	\N	\N	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaam	sequenceNr	sys_md_Attribute	3	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Sequence number	Number that defines order of attributes in a entity	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaaq	type	sys_md_Attribute	4	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Data type	\N	f	bool,categorical,categoricalmref,compound,date,datetime,decimal,email,enum,file,html,hyperlink,int,long,mref,onetomany,script,string,text,xref	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaau	isIdAttribute	sys_md_Attribute	5	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	ID attribute	\N	f	\N	\N	\N	f	f	\N	\N	$('isIdAttribute').eq(false).or($('isIdAttribute').isNull()).or($('isIdAttribute').eq(true).and($('type').eq('email').or($('type').eq('hyperlink')).or($('type').eq('int')).or($('type').eq('long')).or($('type').eq('string')).or($('type').isNull())).and($('isNullable').eq(false))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaay	isLabelAttribute	sys_md_Attribute	6	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label attribute	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaa4	lookupAttributeIndex	sys_md_Attribute	7	int	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Lookup attribute index	\N	f	\N	\N	\N	f	f	\N	\N	$('lookupAttributeIndex').isNull().or($('lookupAttributeIndex').isNull().not().and($('type').matches(/^(categorical|categoricalmref|file|mref|onetomany|xref)$/).not())).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyaba	parent	sys_md_Attribute	8	xref	\N	\N	\N	\N	sys_md_Attribute	\N	\N	\N	\N	t	f	t	Attribute parent	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaae	refEntityType	sys_md_Attribute	10	xref	\N	\N	\N	\N	sys_md_EntityType	\N	\N	\N	\N	t	f	t	Referenced entity	\N	f	\N	\N	\N	f	f	\N	\N	$('refEntityType').isNull().and($('type').matches(/^(categorical|categoricalmref|file|mref|onetomany|xref)$/).not()).or($('refEntityType').isNull().not().and($('type').matches(/^(categorical|categoricalmref|file|mref|onetomany|xref)$/))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaai	isCascadeDelete	sys_md_Attribute	11	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Cascade delete	Delete corresponding referenced entities on delete	f	\N	\N	\N	f	f	\N	\N	$('isCascadeDelete').isNull().or($('refEntityType').isNull().not()).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaam	mappedBy	sys_md_Attribute	12	xref	\N	\N	\N	\N	sys_md_Attribute	\N	\N	\N	\N	t	f	t	Mapped by	Attribute in the referenced entity that owns the relationship of a onetomany attribute	f	\N	\N	\N	t	f	\N	\N	$('mappedBy').isNull().and($('type').eq('onetomany').not()).or($('mappedBy').isNull().not().and($('type').eq('onetomany'))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaaq	orderBy	sys_md_Attribute	13	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Order by	Order expression that defines entity collection order of a onetomany attribute (e.g. "attr0", "attr0,ASC", "attr0,DESC" or "attr0,ASC;attr1,DESC"	f	\N	\N	\N	f	f	\N	\N	$('orderBy').isNull().or($('orderBy').matches(/^\\w+(,(ASC|DESC))?(;\\w+(,(ASC|DESC))?)*$/).and($('type').eq('onetomany'))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaau	expression	sys_md_Attribute	14	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Expression	Computed value expression in Magma JavaScript	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaay	isNullable	sys_md_Attribute	15	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Nillable	\N	f	\N	\N	\N	f	f	\N	\N	$('isNullable').eq(true).or($('nullableExpression').isNull()).value()	true	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaa4	isAuto	sys_md_Attribute	16	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Auto	Auto generated values	f	\N	\N	\N	f	f	\N	\N	$('isAuto').eq(false).or($('isAuto').eq(true).and($('isIdAttribute').eq(true).and($('type').eq('string').or($('type').isNull())))).or($('isAuto').eq(true).and($('isIdAttribute').eq(false).or($('isIdAttribute').isNull())).and($('type').matches(/^(date|datetime)$/))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaba	isVisible	sys_md_Attribute	17	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Visible	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyabe	label	sys_md_Attribute	18	string	\N	\N	0	\N	\N	\N	\N	\N	\N	t	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyabi	description	sys_md_Attribute	19	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyabm	isAggregatable	sys_md_Attribute	20	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Aggregatable	\N	f	\N	\N	\N	f	f	\N	\N	$('isAggregatable').isNull().or($('isAggregatable').eq(false)).or($('type').matches(/^(categorical|categoricalmref|file|mref|onetomany|xref)$/).and($('isNullable').eq(false))).or($('type').matches(/^(categorical|categoricalmref|file|mref|onetomany|xref)$/).not()).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyabq	enumOptions	sys_md_Attribute	21	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Enum values	For data type ENUM	f	\N	\N	\N	f	f	\N	\N	$('enumOptions').isNull().and($('type').eq('enum').not()).or($('enumOptions').isNull().not().and($('type').eq('enum'))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyabu	rangeMin	sys_md_Attribute	22	long	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Range min	\N	f	\N	\N	\N	f	f	\N	\N	$('rangeMin').isNull().or($('rangeMin').isNull().not().and($('type').matches(/^(int|long)$/))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaby	rangeMax	sys_md_Attribute	23	long	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Range max	\N	f	\N	\N	\N	f	f	\N	\N	$('rangeMax').isNull().or($('rangeMax').isNull().not().and($('type').matches(/^(int|long)$/))).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyab4	isReadOnly	sys_md_Attribute	24	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Read-only	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaca	isUnique	sys_md_Attribute	25	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Unique	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyace	tags	sys_md_Attribute	26	mref	\N	\N	\N	\N	sys_md_Tag	\N	\N	\N	\N	t	f	t	Tags	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyaci	nullableExpression	sys_md_Attribute	27	script	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Nullable expression	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6rzw2vuwyxoyacm	visibleExpression	sys_md_Attribute	28	script	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Visible expression	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaae	validationExpression	sys_md_Attribute	29	script	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Validation expression	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6tzw2vuwyxoyaai	defaultValue	sys_md_Attribute	30	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Default value	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaai	labelEn	sys_md_Attribute	31	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (en)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaam	descriptionEn	sys_md_Attribute	32	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (en)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaa4	labelNl	sys_md_Attribute	33	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (nl)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel77zw2vuwyxoyaba	descriptionNl	sys_md_Attribute	34	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (nl)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemabzw2vuwyxoyaai	labelDe	sys_md_Attribute	35	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (de)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemabzw2vuwyxoyaam	descriptionDe	sys_md_Attribute	36	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (de)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaae	labelEs	sys_md_Attribute	37	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (es)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaai	descriptionEs	sys_md_Attribute	38	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (es)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaay	labelIt	sys_md_Attribute	39	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (it)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemafzw2vuwyxoyaa4	descriptionIt	sys_md_Attribute	40	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (it)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaai	labelPt	sys_md_Attribute	41	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (pt)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaam	descriptionPt	sys_md_Attribute	42	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (pt)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaa4	labelFr	sys_md_Attribute	43	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (fr)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyaba	descriptionFr	sys_md_Attribute	44	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (fr)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyabq	labelXx	sys_md_Attribute	45	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Label (xx)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiemahzw2vuwyxoyabu	descriptionXx	sys_md_Attribute	46	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description (xx)	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaam	id	sys_job_ScheduledJob	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	t	\N	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaaq	name	sys_job_ScheduledJob	1	string	\N	t	0	\N	\N	\N	\N	\N	\N	f	f	t	Name	\N	f	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaau	description	sys_job_ScheduledJob	2	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Description	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaay	cronExpression	sys_job_ScheduledJob	3	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Cron expression	Cron expression. A cron expression is a string comprised of 6 or 7 fields separated by white space. These fields are: Seconds, Minutes, Hours, Day of month, Month, Day of week, and optionally Year. An example input is 0 0 12 * * ? for a job that fires at noon every day. See http://www.quartz-scheduler.org/documentation/quartz-2.3.0/tutorials/tutorial-lesson-06.html	f	\N	\N	\N	f	f	\N	\N	$('cronExpression').matches(/^\\s*($|#|\\w+\\s*=|(\\?|\\*|(?:[0-5]?\\d)(?:(?:-|\\/|\\,)(?:[0-5]?\\d))?(?:,(?:[0-5]?\\d)(?:(?:-|\\/|\\,)(?:[0-5]?\\d))?)*)\\s+(\\?|\\*|(?:[0-5]?\\d)(?:(?:-|\\/|\\,)(?:[0-5]?\\d))?(?:,(?:[0-5]?\\d)(?:(?:-|\\/|\\,)(?:[0-5]?\\d))?)*)\\s+(\\?|\\*|(?:[01]?\\d|2[0-3])(?:(?:-|\\/|\\,)(?:[01]?\\d|2[0-3]))?(?:,(?:[01]?\\d|2[0-3])(?:(?:-|\\/|\\,)(?:[01]?\\d|2[0-3]))?)*)\\s+(\\?|\\*|(?:0?[1-9]|[12]\\d|3[01])(?:(?:-|\\/|\\,)(?:0?[1-9]|[12]\\d|3[01]))?(?:,(?:0?[1-9]|[12]\\d|3[01])(?:(?:-|\\/|\\,)(?:0?[1-9]|[12]\\d|3[01]))?)*)\\s+(\\?|\\*|(?:[1-9]|1[012])(?:(?:-|\\/|\\,)(?:[1-9]|1[012]))?(?:L|W)?(?:,(?:[1-9]|1[012])(?:(?:-|\\/|\\,)(?:[1-9]|1[012]))?(?:L|W)?)*|\\?|\\*|(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(?:(?:-)(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))?(?:,(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(?:(?:-)(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))?)*)\\s+(\\?|\\*|(?:[0-6])(?:(?:-|\\/|\\,|#)(?:[0-6]))?(?:L)?(?:,(?:[0-6])(?:(?:-|\\/|\\,|#)(?:[0-6]))?(?:L)?)*|\\?|\\*|(?:MON|TUE|WED|THU|FRI|SAT|SUN)(?:(?:-)(?:MON|TUE|WED|THU|FRI|SAT|SUN))?(?:,(?:MON|TUE|WED|THU|FRI|SAT|SUN)(?:(?:-)(?:MON|TUE|WED|THU|FRI|SAT|SUN))?)*)(|\\s)+(\\?|\\*|(?:|\\d{4})(?:(?:-|\\/|\\,)(?:|\\d{4}))?(?:,(?:|\\d{4})(?:(?:-|\\/|\\,)(?:|\\d{4}))?)*))$/).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaa4	active	sys_job_ScheduledJob	4	bool	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Active	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyaba	user	sys_job_ScheduledJob	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Username	Name of the user to run the job as. Will be automatically filled in by the system.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyabe	failureEmail	sys_job_ScheduledJob	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Failure email	Comma-separated list of emails. Leave blank if you don't want to receive emails if the jobs failed.	f	\N	\N	\N	f	f	\N	\N	$('failureEmail').matches(/^[\\W]*([\\w+\\-.%]+@[\\w\\-.]+\\.[A-Za-z]{2,4}[\\W]*,{1}[\\W]*)*([\\w+\\-.%]+@[\\w\\-.]+\\.[A-Za-z]{2,4})[\\W]*$|^$|undefined|null/).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyabi	successEmail	sys_job_ScheduledJob	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Success email	Comma-separated list of emails. Leave blank if you don't want to receive emails if the jobs succeed.	f	\N	\N	\N	f	f	\N	\N	$('successEmail').matches(/^[\\W]*([\\w+\\-.%]+@[\\w\\-.]+\\.[A-Za-z]{2,4}[\\W]*,{1}[\\W]*)*([\\w+\\-.%]+@[\\w\\-.]+\\.[A-Za-z]{2,4})[\\W]*$|^$|undefined|null/).value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyabm	type	sys_job_ScheduledJob	8	categorical	\N	\N	\N	\N	sys_job_ScheduledJobType	\N	\N	\N	\N	f	f	t	\N	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6fzw2vuwyxoyabq	parameters	sys_job_ScheduledJob	9	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Job parameters	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyabe	id	sys_sec_MembershipInvitation	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	t	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyabi	token	sys_sec_MembershipInvitation	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Token	The token used when responding to this invitation.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyabm	email	sys_sec_MembershipInvitation	2	email	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Email	Email address of the invited user.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyabq	from	sys_sec_MembershipInvitation	3	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	From	The proposed start date of the membership.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyabu	to	sys_sec_MembershipInvitation	4	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	To	The proposed end date of the membership.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaby	role	sys_sec_MembershipInvitation	5	xref	\N	\N	\N	\N	sys_sec_Role	\N	\N	\N	\N	f	f	t	Role	The role that the user will join the group in.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyab4	invitedBy	sys_sec_MembershipInvitation	6	xref	\N	\N	\N	\N	sys_sec_User	\N	\N	\N	\N	f	f	t	Invited by	The group manager who created this invitation.	t	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaca	issued	sys_sec_MembershipInvitation	7	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	t	t	Issued	The moment this invitation was issued.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyace	lastUpdate	sys_sec_MembershipInvitation	8	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Last update	The moment this invitation was last updated.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyaci	invitationText	sys_sec_MembershipInvitation	9	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Invitation text	Custom text used to invite the user.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyacm	declineReason	sys_sec_MembershipInvitation	10	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Decline reason	Reason provided by the invited User on why they declined the invitation.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7lzw2vuwyxoyacq	status	sys_sec_MembershipInvitation	11	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	\N	\N	t	PENDING,ACCEPTED,REVOKED,EXPIRED,DECLINED	\N	\N	f	f	\N	\N	\N	PENDING	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyabu	id	sys_sec_RoleMembership	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	t	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaby	user	sys_sec_RoleMembership	1	xref	\N	\N	\N	\N	sys_sec_User	\N	\N	\N	\N	f	f	t	User	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyab4	role	sys_sec_RoleMembership	2	xref	\N	\N	\N	\N	sys_sec_Role	\N	\N	\N	\N	f	f	t	Role	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaca	from	sys_sec_RoleMembership	3	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	From	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaae	to	sys_sec_RoleMembership	4	datetime	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	To	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyabm	id	sys_negotiator_NegotiatorEntityConfig	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Identifier	Identifier for this entity config	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyabq	entity	sys_negotiator_NegotiatorEntityConfig	1	xref	\N	\N	\N	\N	sys_md_EntityType	\N	\N	\N	\N	f	f	t	Entity to use in negotiator	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyabu	negotiatorConfig	sys_negotiator_NegotiatorEntityConfig	2	xref	\N	\N	\N	\N	sys_negotiator_NegotiatorConfig	\N	\N	\N	\N	f	f	t	General negotiator settings	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaby	collectionId	sys_negotiator_NegotiatorEntityConfig	3	xref	\N	\N	\N	\N	sys_md_Attribute	\N	\N	\N	\N	f	f	t	Attribute containing the collection	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyab4	biobankId	sys_negotiator_NegotiatorEntityConfig	4	xref	\N	\N	\N	\N	sys_md_Attribute	\N	\N	\N	\N	f	f	t	Attribute containing the biobank	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6vzw2vuwyxoyaca	enabledExpression	sys_negotiator_NegotiatorEntityConfig	5	script	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Negotiator enabled expression	Expression to determine if the row is enabled for usage with the negotiator	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyabq	id	sys_genomebrowser_GenomeBrowserSettings	0	string	t	f	\N	\N	\N	\N	\N	\N	\N	f	t	t	Identifier	\N	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyabu	label	sys_genomebrowser_GenomeBrowserSettings	1	string	\N	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Label	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaby	entity	sys_genomebrowser_GenomeBrowserSettings	2	xref	\N	\N	\N	\N	sys_md_EntityType	\N	\N	\N	\N	f	f	t	Entity	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyab4	genome_browser_attrs	sys_genomebrowser_GenomeBrowserSettings	3	xref	\N	\N	\N	\N	sys_genomebrowser_GenomeBrowserAttributes	\N	\N	\N	\N	f	f	t	Genomic attributes	Reference to the Genome Browser Attributes entity to tell the genome browser which attributes should be used for chromosome, positions, reference allele and alternative allele	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyaca	labelAttr	sys_genomebrowser_GenomeBrowserSettings	4	xref	\N	\N	\N	\N	sys_md_Attribute	\N	\N	\N	\N	f	f	t	Label Attribute	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5zzw2vuwyxoyace	track_type	sys_genomebrowser_GenomeBrowserSettings	5	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Track type	The track type which determines how dalliance will render the track	f	VARIANT,NUMERIC,EXON	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaae	exon_key	sys_genomebrowser_GenomeBrowserSettings	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Exon/intron key	Value to distinguish Exon and intron values, if the key is present in the label attributes we assume this is an exon	f	\N	\N	\N	f	f	\N	$('track_type').eq('EXON').value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaai	scoreAttr	sys_genomebrowser_GenomeBrowserSettings	7	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Score attributes	Name of the attribute that can be used for the score	f	\N	\N	\N	f	f	\N	$('track_type').eq('NUMERIC').value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaam	attrs	sys_genomebrowser_GenomeBrowserSettings	8	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Feature popup attributes	Comma separated list of label:attr pairs that should be shown in the genome browser popup, example: "'Reference Allele:REF,Alternative Allele:ALT'"	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaaq	molgenis_reference_tracks_mode	sys_genomebrowser_GenomeBrowserSettings	9	enum	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Reference track mode	Setting to determine if all suitable molgenis entities should be shown as reference track in the genomebrowser, only those configured, or none	f	ALL,CONFIGURED,NONE	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaau	molgenis_reference_tracks	sys_genomebrowser_GenomeBrowserSettings	10	mref	\N	\N	\N	\N	sys_genomebrowser_GenomeBrowserSettings	\N	\N	\N	\N	t	f	t	Reference tracks	the genome browser settings that should be shown as reference tracks	f	\N	\N	\N	f	f	!($('molgenis_reference_tracks_mode').eq('CONFIGURED')).value()	$('molgenis_reference_tracks_mode').eq('CONFIGURED').value()	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaay	actions	sys_genomebrowser_GenomeBrowserSettings	11	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Actions	a javascript array containing object that specify actions to be available in the genome browser popup, format: [{label:"action1" run:"alert('action1')"},{label:"action2" run:"alert('action2')"}]	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel53zw2vuwyxoyaa4	feature_info_plugin	sys_genomebrowser_GenomeBrowserSettings	12	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Feature info plugin	contents of the addFeaturePlugin method ('function(f, info) {YOUR_CODE_HERE}')	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaae	id	sys_beacons_Beacon	0	string	t	t	\N	\N	\N	\N	\N	\N	\N	f	f	t	Beacon identifier	Unique identifier of the beacon	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaai	name	sys_beacons_Beacon	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	Beacon name	Name of the beacon	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaam	api_version	sys_beacons_Beacon	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	t	API version	Version of the API provided by the beacon	f	\N	\N	\N	f	f	\N	\N	\N	v0.3.0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaaq	beacon_organization	sys_beacons_Beacon	3	xref	\N	\N	\N	\N	sys_beacons_BeaconOrganization	\N	\N	\N	\N	t	f	t	Beacon organization	Organization owning the beacon	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaau	description	sys_beacons_Beacon	4	text	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Beacon description	 Description of the beacon	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaay	version	sys_beacons_Beacon	5	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Beacon version	 Version of the beacon	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaa4	welcome_url	sys_beacons_Beacon	6	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	Welcome URL	URL to the welcome page for this beacon	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel5xzw2vuwyxoyaba	data_sets	sys_beacons_Beacon	7	mref	\N	\N	\N	\N	sys_beacons_BeaconDataset	\N	\N	\N	\N	f	f	t	Beacon datasets	Data sets served by the beacon	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyab4	ontologyTerms	sys_ont_Ontology	3	onetomany	\N	\N	\N	\N	sys_ont_OntologyTerm	t	aaaac3fyiel7dzw2vuwyxoyab4	\N	\N	t	f	t	Terms	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyadi	children	sys_md_Package	4	onetomany	\N	\N	\N	\N	sys_md_Package	\N	aaaac3fyiel7xzw2vuwyxoyade	label,ASC	\N	t	f	t	Children	\N	f	\N	\N	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyadm	entityTypes	sys_md_Package	5	onetomany	\N	\N	\N	\N	sys_md_EntityType	\N	aaaac3fyiel7xzw2vuwyxoyab4	label,ASC	\N	t	f	t	Entity types	\N	f	\N	\N	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyabe	props	sys_set_MailSettings	10	onetomany	\N	\N	\N	\N	sys_mail_JavaMailProperty	\N	aaaac3fyiel6fzw2vuwyxoyaci	key,ASC	\N	t	f	t	Properties	JavaMail properties. The default values are tuned to connect with Google mail.If you want to connect to a different provider, these properties should be edited in the Data Explorer.Select the sys_mail_JavaMailProperty entity.	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7xzw2vuwyxoyaca	attributes	sys_md_EntityType	4	onetomany	\N	\N	\N	\N	sys_md_Attribute	\N	aaaac3fyiel6pzw2vuwyxoyaai	sequenceNr,ASC	\N	t	f	t	Attributes	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel7vzw2vuwyxoyabi	roles	sys_sec_Group	21	onetomany	\N	\N	\N	\N	sys_sec_Role	t	aaaac3fyiel3zzw2vuwyxoyaae	\N	\N	t	f	t	Roles	Roles a User can have within this Group	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyiel6pzw2vuwyxoyabe	children	sys_md_Attribute	9	onetomany	\N	\N	\N	\N	sys_md_Attribute	t	aaaac3fyiel6pzw2vuwyxoyaba	sequenceNr,ASC	\N	t	f	t	Attribute parts	\N	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyimfg7zw2vuwyxoyaai	id	it_emx_autoid_testAutoId	0	string	t	t	0	\N	\N	\N	\N	\N	\N	f	t	t	\N	identifier	f	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyimfhdzw2vuwyxoyaae	firstName	it_emx_autoid_testAutoId	1	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	first name	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyimfhdzw2vuwyxoyaai	lastName	it_emx_autoid_testAutoId	2	string	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	f	t	\N	family name	f	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sys_md_Attribute#c8d9a252_tags; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_md_Attribute#c8d9a252_tags" ("order", id, tags) FROM stdin;
\.


--
-- Data for Name: sys_md_EntityType#6a3870a0; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_md_EntityType#6a3870a0" (id, label, description, package, "isAbstract", extends, backend, "indexingDepth", "labelEn", "descriptionEn", "labelNl", "descriptionNl", "labelDe", "descriptionDe", "labelEs", "descriptionEs", "labelIt", "descriptionIt", "labelPt", "descriptionPt", "labelFr", "descriptionFr", "labelXx", "descriptionXx") FROM stdin;
sys_idx_IndexActionGroup	Index action group	This entity is used to group the index actions.	sys_idx	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_StaticContent	Static content	\N	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_scr_ScriptType	Script type	\N	sys_scr	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_L10nString	Localization	Translated language strings	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_JobExecution	Job execution	\N	sys_job	t	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_Questionnaire	Questionnaire	\N	sys	t	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_scr_ScriptParameter	Script parameter	\N	sys_scr	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_TermFrequency	Term frequency	\N	sys_ont	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_Plugin	Plugin	\N	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_md_Tag	Tag	Semantic tags that can be applied to entities, attributes and other data	sys_md	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_OntologyTermNodePath	Ontology term node path	\N	sys_ont	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_set_settings	Settings	\N	sys_set	t	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_genomebrowser_GenomeBrowserAttributes	Genome Browser Attributes	\N	sys_genomebrowser	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_OntologyTermSynonym	Ontology term synonym	\N	sys_ont	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_MatchingTaskContent	Matching task content	\N	sys_ont	t	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_dec_DynamicDecorator	Decorator	\N	sys_dec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_FileMeta	File metadata	\N	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ImportRun	Import	Data import reports	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_beacons_BeaconOrganization	Beacon organization	Organization owning a beacon	sys_beacons	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_RecoveryCode	Recovery Code	Codes for recovering an account when using two factor authorisation	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_oidc_OidcClient	OIDC client	OpenID Connect client registration	sys_sec_oidc	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_User	User	Anyone who can login	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_FreemarkerTemplate	Freemarker template	\N	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_UserSecret	User Secret	Secret that is used to authenticate user with 2 factor authentication	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_OntologyTermDynamicAnnotation	Ontology term dynamic annotation	\N	sys_ont	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_Language	Language	Web application languages	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_md_Property	Property	Abstract class for key/value properties.	sys_md	t	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_negotiator_NegotiatorConfig	Negotiator Config	\N	sys_negotiator	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_App	App	\N	sys	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_map_AttributeMapping	Attribute mapping	\N	sys_map	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_oidc_OidcUserMapping	OIDC user mapping	Mapping of OpenID Connect users to MOLGENIS users	sys_sec_oidc	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_SortaJobExecution	SORTA job execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_ScriptJobExecution	Script job execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_ResourceDownloadJobExecution	Download job execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_set_OpenCpuSettings	OpenCPU settings	OpenCPU, a framework for embedded scientific computing and reproducible research, settings.	sys_set	f	sys_set_settings	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_set_StyleSheet	StyleSheet	\N	sys_set	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_dec_DecoratorParameters	Decorator Parameters	\N	sys_dec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_set_dataexplorer	Data explorer settings	Settings for the data explorer plugin.	sys_set	f	sys_set_settings	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_PasswordResetToken	Password reset token	\N	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_OntologyTermHit	Ontology term hit	\N	sys_ont	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_Token	Token	\N	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_idx_IndexAction	Index action	\N	sys_idx	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_set_auth	Authentication settings	Settings for authentication methods and user sign-up.	sys_set	f	sys_set_settings	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_IndexJobExecution	Index job execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_set_app	Application settings	General application settings.	sys_set	f	sys_set_settings	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_OntologyTerm	Ontology term	\N	sys_ont	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_FileIngestJobExecution	File ingest job execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_OneClickImportJobExecution	One click import job execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_ResourceDeleteJobExecution	Resource Delete Job Execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_AmazonBucketJobExecution	Amazon Bucket file ingest job execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_scr_Script	Script	\N	sys_scr	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_map_EntityMapping	Entity mapping	\N	sys_map	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_MappingJobExecution	Mapping Job Execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_ResourceCopyJobExecution	Resource Copy Job Execution	\N	sys_job	f	sys_job_JobExecution	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_mail_JavaMailProperty	Mail sender properties	See https://javamail.java.net/nonav/docs/api/ for a description of the properties you can use.	sys_mail	f	sys_md_Property	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_dec_DecoratorConfiguration	Decorator Configuration	Configuration entity to configure which dynamic decorators should be applied to an entity type.	sys_dec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_map_MappingTarget	Mapping target	\N	sys_map	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_map_MappingProject	Mapping project	\N	sys_map	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_ScheduledJobType	Scheduled Job Type	\N	sys_job	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_Role	Role	\N	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_beacons_BeaconDataset	Beacon dataset	Dataset for a beacon	sys_beacons	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_job_ScheduledJob	Scheduled job	\N	sys_job	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_MembershipInvitation	MembershipInvitation	An Invitation for a User to join a Group in a certain Role.	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_RoleMembership	Role Membership	Records the fact that a User is a member of a Role during an interval.	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_negotiator_NegotiatorEntityConfig	Negotiator Entity Config	\N	sys_negotiator	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_genomebrowser_GenomeBrowserSettings	Genome Browser Settings	\N	sys_genomebrowser	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_beacons_Beacon	Beacon	A Beacon based on ga4gh beacon API. See https://github.com/ga4gh for more information	sys_beacons	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_ont_Ontology	Ontology	\N	sys_ont	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_md_Package	Package	Grouping of related entities	sys_md	f	\N	PostgreSQL	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_set_MailSettings	Mail settings	Configuration properties for email support. Will be used to send email from Molgenis. See also the MailSenderProp entity.	sys_set	f	sys_set_settings	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_md_EntityType	Entity type	Meta data for entity classes	sys_md	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_sec_Group	Group	A number of people that work together or share certain beliefs.	sys_sec	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
sys_md_Attribute	Attribute	Meta data for attributes	sys_md	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
it_emx_autoid_testAutoId	testAutoId	\N	it_emx_autoid	f	\N	PostgreSQL	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sys_md_EntityType#6a3870a0_tags; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_md_EntityType#6a3870a0_tags" ("order", id, tags) FROM stdin;
\.


--
-- Data for Name: sys_md_Package#a6dc6fe7; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_md_Package#a6dc6fe7" (id, label, description, parent) FROM stdin;
sys	System	Package containing all system entities	\N
sys_sec	Security	Package containing security related entities	sys
sys_beacons	Beacons	\N	sys
sys_genomebrowser	Genome Browser	\N	sys
sys_job	Jobs	Package containing al job related entities	sys
sys_mail	Mail	Mail properties	sys
sys_set	Settings	Application and plugin settings	sys
sys_scr	Script	\N	sys
sys_ont	Ontology	\N	sys
sys_idx	Index	\N	sys
sys_sec_oidc	OpenID Connect	OpenID Connect authentication	sys_sec
sys_map	Mapper	\N	sys
sys_negotiator	Negotiator	\N	sys
sys_dec	Decorator	Package containing entities concerning dynamic decorators	sys
sys_md	Meta	Package containing all meta data entities	sys
it	it	\N	\N
it_emx	it_emx	\N	it
it_emx_autoid	it_emx_autoid	\N	it_emx
\.


--
-- Data for Name: sys_md_Package#a6dc6fe7_tags; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_md_Package#a6dc6fe7_tags" ("order", id, tags) FROM stdin;
\.


--
-- Data for Name: sys_md_Tag#c2d685da; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_md_Tag#c2d685da" (id, "objectIRI", label, "relationIRI", "relationLabel", "codeSystem") FROM stdin;
\.


--
-- Data for Name: sys_negotiator_NegotiatorConfig#aced883a; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_negotiator_NegotiatorConfig#aced883a" (id, negotiator_url, username, password) FROM stdin;
\.


--
-- Data for Name: sys_negotiator_NegotiatorEntityConfig#9a61747d; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_negotiator_NegotiatorEntityConfig#9a61747d" (id, entity, "negotiatorConfig", "collectionId", "biobankId", "enabledExpression") FROM stdin;
\.


--
-- Data for Name: sys_ont_Ontology#49a81949; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_Ontology#49a81949" (id, "ontologyIRI", "ontologyName") FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTerm#f0034aa0; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTerm#f0034aa0" (id, "ontologyTermIRI", "ontologyTermName", ontology) FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTerm#f0034aa0_nodePath; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTerm#f0034aa0_nodePath" ("order", id, "nodePath") FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation" ("order", id, "ontologyTermDynamicAnnotation") FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym" ("order", id, "ontologyTermSynonym") FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTermDynamicAnnotation#6454b1f8; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTermDynamicAnnotation#6454b1f8" (id, name, value, label) FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTermHi#9ce87f6a_nodePath; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTermHi#9ce87f6a_nodePath" ("order", id, "nodePath") FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation" ("order", id, "ontologyTermDynamicAnnotation") FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym" ("order", id, "ontologyTermSynonym") FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTermHit#9ce87f6a; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTermHit#9ce87f6a" (id, "Score", "Combined_Score", "ontologyTermIRI", "ontologyTermName", ontology) FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTermNodePath#adc5397c; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTermNodePath#adc5397c" (id, "nodePath", root) FROM stdin;
\.


--
-- Data for Name: sys_ont_OntologyTermSynonym#ce764ed4; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_OntologyTermSynonym#ce764ed4" (id, "ontologyTermSynonym", "Score", "Combined_Score") FROM stdin;
\.


--
-- Data for Name: sys_ont_TermFrequency#aef76974; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_ont_TermFrequency#aef76974" (id, term, frequency, occurrence) FROM stdin;
\.


--
-- Data for Name: sys_scr_Script#354cd12b; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_scr_Script#354cd12b" (name, type, content, "generateToken", "resultFileExtension") FROM stdin;
\.


--
-- Data for Name: sys_scr_Script#354cd12b_parameters; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_scr_Script#354cd12b_parameters" ("order", name, parameters) FROM stdin;
\.


--
-- Data for Name: sys_scr_ScriptParameter#88bc2dd2; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_scr_ScriptParameter#88bc2dd2" (name) FROM stdin;
\.


--
-- Data for Name: sys_scr_ScriptType#3e8906a6; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_scr_ScriptType#3e8906a6" (name) FROM stdin;
python
R
JavaScript (Magma)
JavaScript
\.


--
-- Data for Name: sys_sec_Group#d325f6e2; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_Group#d325f6e2" (id, name, label, "labelEn", "labelNl", "labelDe", "labelEs", "labelIt", "labelPt", "labelFr", "labelXx", description, "descriptionEn", "descriptionNl", "descriptionDe", "descriptionEs", "descriptionIt", "descriptionPt", "descriptionFr", "descriptionXx", public, "rootPackage") FROM stdin;
\.


--
-- Data for Name: sys_sec_MembershipInvitation#27f7958b; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_MembershipInvitation#27f7958b" (id, token, email, "from", "to", role, "invitedBy", issued, "lastUpdate", "invitationText", "declineReason", status) FROM stdin;
\.


--
-- Data for Name: sys_sec_PasswordResetToken#a04705dd; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_PasswordResetToken#a04705dd" (id, token, "user", "expirationDate") FROM stdin;
\.


--
-- Data for Name: sys_sec_RecoveryCode#a3192a80; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_RecoveryCode#a3192a80" (id, "userId", code) FROM stdin;
\.


--
-- Data for Name: sys_sec_Role#b6639604; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_Role#b6639604" (id, name, label, "labelEn", "labelNl", "labelDe", "labelEs", "labelIt", "labelPt", "labelFr", "labelXx", description, "descriptionEn", "descriptionNl", "descriptionDe", "descriptionEs", "descriptionIt", "descriptionPt", "descriptionFr", "descriptionXx", "group") FROM stdin;
aaaac3fyifn4bzw2vuwyxoyaai	ANONYMOUS	Anonymous	Anonymous	Anoniem	\N	\N	\N	\N	\N	\N	Role for permissions granted to all users, including unauthenticated users.	Role for permissions granted to all users, including unauthenticated users.	Rol voor alle gebruikers, inclusief ongeauthenticeerde gebruikers.	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4bzw2vuwyxoyaam	USER	User	User	Gebruiker	\N	\N	\N	\N	\N	\N	All authenticated users are a member of this Role.	All authenticated users are a member of this role.	Alle geauthenticeerde gebruikers hebben deze rol.	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4dzw2vuwyxoyaam	ACL_TAKE_OWNERSHIP	Take resource ownership	\N	\N	\N	\N	\N	\N	\N	\N	Role granting the permission to change resource ownership.	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4dzw2vuwyxoyaaq	ACL_MODIFY_AUDITING	Modify access control auditing	\N	\N	\N	\N	\N	\N	\N	\N	Role granting the permission to modify auditing details.	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4dzw2vuwyxoyaau	ACL_GENERAL_CHANGES	General access control changes	\N	\N	\N	\N	\N	\N	\N	\N	Role granting the permission to make general access control list changes.	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4dzw2vuwyxoyaai	METRICS	View metrics	\N	\N	\N	\N	\N	\N	\N	\N	Role granting the permission to view metrics.	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4bzw2vuwyxoyaaq	VIEWER	Viewer	\N	\N	\N	\N	\N	\N	\N	\N	Role containing permissions needed to view data. This role is included in all group viewer roles.	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4bzw2vuwyxoyaau	EDITOR	Editor	\N	\N	\N	\N	\N	\N	\N	\N	Role containing permissions needed to edit data. This role is included in all group editor roles.	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4dzw2vuwyxoyaae	MANAGER	Manager	\N	\N	\N	\N	\N	\N	\N	\N	Role containing permissions needed to manage groups. This role is included in all group manager roles.	\N	\N	\N	\N	\N	\N	\N	\N	\N
aaaac3fyifn4dzw2vuwyxoyaay	SU	Superuser	\N	\N	\N	\N	\N	\N	\N	\N	Role granted to superusers.	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sys_sec_Role#b6639604_includes; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_Role#b6639604_includes" ("order", id, includes) FROM stdin;
0	aaaac3fyifn4bzw2vuwyxoyaam	aaaac3fyifn4bzw2vuwyxoyaai
0	aaaac3fyifn4bzw2vuwyxoyaau	aaaac3fyifn4bzw2vuwyxoyaaq
0	aaaac3fyifn4dzw2vuwyxoyaae	aaaac3fyifn4bzw2vuwyxoyaau
0	aaaac3fyifn4dzw2vuwyxoyaay	aaaac3fyifn4dzw2vuwyxoyaam
1	aaaac3fyifn4dzw2vuwyxoyaay	aaaac3fyifn4dzw2vuwyxoyaaq
2	aaaac3fyifn4dzw2vuwyxoyaay	aaaac3fyifn4dzw2vuwyxoyaau
3	aaaac3fyifn4dzw2vuwyxoyaay	aaaac3fyifn4dzw2vuwyxoyaai
\.


--
-- Data for Name: sys_sec_RoleMembership#2f0e0432; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_RoleMembership#2f0e0432" (id, "user", role, "from", "to") FROM stdin;
\.


--
-- Data for Name: sys_sec_Token#2dc001d0; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_Token#2dc001d0" (id, "User", token, "expirationDate", "creationDate", description) FROM stdin;
aaaac3fyimbarzw2vuwyxoyaae	aaaac3fyifn37zw2vuwyxoyaae	5b673a3e32e545c78f61c551becfebe3	2019-08-22 09:38:14+00	2019-08-22 07:38:14+00	REST API login
aaaac3fyipvxrzw2vuwyxoyaae	aaaac3fyifn37zw2vuwyxoyaae	admintoken	\N	2019-08-22 07:39:14+00	\N
\.


--
-- Data for Name: sys_sec_User#953f6cde; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_User#953f6cde" (id, username, password_, "activationCode", active, superuser, "FirstName", "MiddleNames", "LastName", "Title", "Affiliation", "Department", "Role", "Address", "Phone", "Email", "Fax", "tollFreePhone", "City", "Country", "changePassword", use2fa, "languageCode", "googleAccountId") FROM stdin;
aaaac3fyifn37zw2vuwyxoyaae	admin	$2a$10$Uhqk8sOwlV.66Mf2DwIZnOYXyfteY14vIFZ1nu/Nks9.PXJ4m3iD2	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	molgenis+admin@gmail.com	\N	\N	\N	\N	f	f	\N	\N
aaaac3fyifn4bzw2vuwyxoyaae	anonymous	$2a$10$RaFSfKzQpInRdB3MFX.u/.2opcXlpP2UwZRiro4lx9yHruwV4Y6ci	\N	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	molgenis+anonymous@gmail.com	\N	\N	\N	\N	f	f	\N	\N
\.


--
-- Data for Name: sys_sec_UserSecret#f51533c3; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_UserSecret#f51533c3" (id, "userId", secret, last_failed_authentication, failed_login_attempts) FROM stdin;
\.


--
-- Data for Name: sys_sec_oidc_OidcClient#3e7b1b4d; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_oidc_OidcClient#3e7b1b4d" ("registrationId", "clientId", "clientSecret", "clientName", "clientAuthenticationMethod", "authorizationGrantType", scopes, "authorizationUri", "tokenUri", "jwkSetUri", "userInfoUri", "userNameAttributeName") FROM stdin;
\.


--
-- Data for Name: sys_sec_oidc_OidcUserMapping#72060861; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_sec_oidc_OidcUserMapping#72060861" (id, label, "oidcClient", "oidcUsername", "user") FROM stdin;
\.


--
-- Data for Name: sys_set_MailSettings#6daa44ed; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_set_MailSettings#6daa44ed" (host, port, protocol, username, password, "defaultEncoding", "startTlsEnabled", "waitQuit", auth, "fromAddress", "testConnection", id) FROM stdin;
smtp.gmail.com	587	smtp	molgenis	wQf#=5C&VeD>5[>/	UTF-8	true	false	true	molgenis+admin@gmail.com	t	MailSettings
\.


--
-- Data for Name: sys_set_OpenCpuSettings#0ec0e4e8; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_set_OpenCpuSettings#0ec0e4e8" (scheme, host, port, "rootPath", id) FROM stdin;
http	localhost	8004	/ocpu/	OpenCpuSettings
\.


--
-- Data for Name: sys_set_StyleSheet#9d5413fc; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_set_StyleSheet#9d5413fc" (id, name, "bootstrap3Theme", "bootstrap4Theme") FROM stdin;
bootstrap-molgenis-red.min.css	bootstrap-molgenis-red.min.css	aaaac3fyigv4bzw2vuwyxoyaai	aaaac3fyigwadzw2vuwyxoyaae
bootstrap-spacelab.min.css	bootstrap-spacelab.min.css	aaaac3fyigwdpzw2vuwyxoyaai	aaaac3fyigwgfzw2vuwyxoyaae
bootstrap-cerulean.min.css	bootstrap-cerulean.min.css	aaaac3fyigwjnzw2vuwyxoyaai	aaaac3fyigwofzw2vuwyxoyaae
bootstrap-paper.min.css	bootstrap-paper.min.css	aaaac3fyigwrvzw2vuwyxoyaai	\N
bootstrap-readable.min.css	bootstrap-readable.min.css	aaaac3fyigwvhzw2vuwyxoyaai	\N
bootstrap-slate.min.css	bootstrap-slate.min.css	aaaac3fyigwytzw2vuwyxoyaai	aaaac3fyigw3pzw2vuwyxoyaae
bootstrap-molgenis-blue.min.css	bootstrap-molgenis-blue.min.css	aaaac3fyigw6tzw2vuwyxoyaai	aaaac3fyigxa7zw2vuwyxoyaae
bootstrap-cyborg.min.css	bootstrap-cyborg.min.css	aaaac3fyigxefzw2vuwyxoyaai	aaaac3fyigxgtzw2vuwyxoyaae
bootstrap-flatly.min.css	bootstrap-flatly.min.css	aaaac3fyigxjpzw2vuwyxoyaai	aaaac3fyigxmbzw2vuwyxoyaae
bootstrap-yeti.min.css	bootstrap-yeti.min.css	aaaac3fyigxpnzw2vuwyxoyaai	aaaac3fyigxtfzw2vuwyxoyaae
bootstrap-darkly.min.css	bootstrap-darkly.min.css	aaaac3fyigxwpzw2vuwyxoyaai	aaaac3fyigxz5zw2vuwyxoyaae
bootstrap-cosmo.min.css	bootstrap-cosmo.min.css	aaaac3fyigx5hzw2vuwyxoyaai	aaaac3fyigyahzw2vuwyxoyaae
bootstrap-journal.min.css	bootstrap-journal.min.css	aaaac3fyigyddzw2vuwyxoyaai	aaaac3fyigyftzw2vuwyxoyaae
bootstrap-united.min.css	bootstrap-united.min.css	aaaac3fyigyijzw2vuwyxoyaai	aaaac3fyigykrzw2vuwyxoyaae
bootstrap-lumen.min.css	bootstrap-lumen.min.css	aaaac3fyigynlzw2vuwyxoyaai	aaaac3fyigyqhzw2vuwyxoyaae
bootstrap-superhero.min.css	bootstrap-superhero.min.css	aaaac3fyigytvzw2vuwyxoyaai	aaaac3fyigywjzw2vuwyxoyaae
bootstrap-sandstone.min.css	bootstrap-sandstone.min.css	aaaac3fyigyzdzw2vuwyxoyaai	aaaac3fyigy3vzw2vuwyxoyaae
bootstrap-basic.min.css	bootstrap-basic.min.css	aaaac3fyigy6hzw2vuwyxoyaai	aaaac3fyigzanzw2vuwyxoyaae
bootstrap-molgenis-green.min.css	bootstrap-molgenis-green.min.css	aaaac3fyigzdfzw2vuwyxoyaai	aaaac3fyigzfnzw2vuwyxoyaae
bootstrap-simplex.min.css	bootstrap-simplex.min.css	aaaac3fyigzihzw2vuwyxoyaai	aaaac3fyigzkrzw2vuwyxoyaae
bootstrap-molgenis.min.css	bootstrap-molgenis.min.css	aaaac3fyigznpzw2vuwyxoyaai	aaaac3fyigzqxzw2vuwyxoyaae
bootstrap-ibd.min.css	bootstrap-ibd.min.css	aaaac3fyigzudzw2vuwyxoyaai	\N
\.


--
-- Data for Name: sys_set_app#4f91996f; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_set_app#4f91996f" (title, logo_href_navbar, logo_href_top, "logoTopMaxHeight", footer, molgenis_menu, language_code, bootstrap_theme, css_href, aggregate_threshold, custom_javascript, ga_privacy_friendly, ga_tracking_id, ga_acc_privacy_friendly, ga_tracking_id_mgs, ga_acc_privacy_friendly_mgs, tracking_code_footer, recaptcha_private_key, recaptcha_public_key, recaptcha_is_enabled, recaptcha_verify_uri, recaptcha_bot_threshold, id) FROM stdin;
MOLGENIS	/img/Logo_Blue_Small.png	\N	150	\N	{\n  "type": "menu",\n  "id": "main",\n  "label": "Home",\n  "items": [\n    {\n      "type": "plugin",\n      "id": "home",\n      "label": "Home"\n    },\n    {\n      "type": "menu",\n      "id": "importdata",\n      "label": "Import data",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "one-click-importer",\n          "label": "Quick data import"\n        },\n        {\n          "type": "plugin",\n          "id": "importwizard",\n          "label": "Advanced data import"\n        }\n      ]\n    },\n    {\n      "type": "plugin",\n      "id": "navigator",\n      "label": "Navigator"\n    },\n    {\n      "type": "plugin",\n      "id": "dataexplorer",\n      "label": "Data Explorer"\n    },\n    {\n      "type": "menu",\n      "id": "dataintegration",\n      "label": "Data Integration",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "metadata-manager",\n          "label": "Metadata Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "mappingservice",\n          "label": "Mapping Service"\n        },\n        {\n          "type": "plugin",\n          "id": "sorta",\n          "label": "SORTA"\n        },\n        {\n          "type": "plugin",\n          "id": "tagwizard",\n          "label": "Tag Wizard"\n        }\n      ]\n    },\n    {\n      "type": "menu",\n      "id": "plugins",\n      "label": "Plugins",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "searchAll",\n          "label": "Search all data"\n        },\n        {\n          "type": "plugin",\n          "id": "swagger",\n          "label": "API documentation"\n        },\n        {\n          "type": "plugin",\n          "id": "appmanager",\n          "label": "App manager"\n        },\n        {\n          "type": "plugin",\n          "id": "feedback",\n          "label": "Feedback"\n        },\n        {\n          "type": "plugin",\n          "id": "jobs",\n          "label": "Job overview"\n        },\n        {\n          "type": "plugin",\n          "id": "questionnaires",\n          "label": "Questionnaires"\n        },\n        {\n          "type": "plugin",\n          "id": "scripts",\n          "label": "Scripts"\n        }\n      ]\n    },\n    {\n      "type": "menu",\n      "id": "admin",\n      "label": "Admin",\n      "items": [\n        {\n          "type": "plugin",\n          "id": "logmanager",\n          "label": "Log manager"\n        },\n        {\n          "type": "plugin",\n          "id": "menumanager",\n          "label": "Menu Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "permissionmanager",\n          "label": "Permission Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "scheduledjobs",\n          "label": "Scheduled Jobs"\n        },\n        {\n          "type": "plugin",\n          "id": "settings",\n          "label": "Settings"\n        },\n        {\n          "type": "plugin",\n          "id": "thememanager",\n          "label": "Theme Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "usermanager",\n          "label": "User Manager"\n        },\n        {\n          "type": "plugin",\n          "id": "security-ui",\n          "label": "Security Manager"\n        }\n      ]\n    },\n    {\n      "type": "plugin",\n      "id": "useraccount",\n      "label": "Account"\n    }\n  ]\n}\n	en	bootstrap-molgenis-blue.min.css	\N	\N	\N	t	\N	f	\N	t	\N	\N	\N	f	https://www.google.com/recaptcha/api/siteverify	0.5	app
\.


--
-- Data for Name: sys_set_auth#98c4c015; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_set_auth#98c4c015" (signup, signup_moderation, sign_in_2fa, id) FROM stdin;
f	t	Disabled	auth
\.


--
-- Data for Name: sys_set_auth#98c4c015_oidcClients; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_set_auth#98c4c015_oidcClients" ("order", id, "oidcClients") FROM stdin;
\.


--
-- Data for Name: sys_set_dataexplorer#76c80fb0; Type: TABLE DATA; Schema: public; Owner: molgenis
--

COPY public."sys_set_dataexplorer#76c80fb0" (searchbox, item_select_panel, launch_wizard, header_abbreviate, show_navigator_link, mod_aggregates, agg_distinct, agg_distinct_overrides, mod_data, gb_init_browser_links, gb_init_coord_system, gb_init_location, gb_init_sources, gb_init_highlight_region, data_genome_browser, use_vue_data_row_edit, mod_reports, mod_standalone_reports, reports_entities, id) FROM stdin;
t	t	f	180	t	t	t	\N	t	{Ensembl: 'http://www.ensembl.org/Homo_sapiens/Location/View?r=${chr}:${start}-${end}',UCSC: 'http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg19&position=chr${chr}:${start}-${end}',Sequence: 'http://www.derkholm.net:8080/das/hg19comp/sequence?segment=${chr}:${start},${end}'}	{speciesName: 'Human',taxon: 9606,auth: 'GRCh',version: '37',ucscName: 'hg19'}	chr:'1',viewStart:10000000,viewEnd:10100000,cookieKey:'human',nopersist:true	[{name:'Genome',twoBitURI:'//www.biodalliance.org/datasets/hg19.2bit',tier_type: 'sequence'},{name: 'Genes',desc: 'Gene structures from GENCODE 19',bwgURI: '//www.biodalliance.org/datasets/gencode.bb',stylesheet_uri: '//www.biodalliance.org/stylesheets/gencode.xml',collapseSuperGroups: true,trixURI:'//www.biodalliance.org/datasets/geneIndex.ix'},{name: 'Repeats',desc: 'Repeat annotation from Ensembl 59',bwgURI: '//www.biodalliance.org/datasets/repeats.bb',stylesheet_uri: '//www.biodalliance.org/stylesheets/bb-repeats.xml'},{name: 'Conservation',desc: 'Conservation',bwgURI: '//www.biodalliance.org/datasets/phastCons46way.bw',noDownsample: true}]	f	t	t	t	f	\N	dataexplorer
\.


--
-- Name: acl_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: molgenis
--

SELECT pg_catalog.setval('public.acl_class_id_seq', 9, true);


--
-- Name: acl_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: molgenis
--

SELECT pg_catalog.setval('public.acl_entry_id_seq', 83, true);


--
-- Name: acl_object_identity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: molgenis
--

SELECT pg_catalog.setval('public.acl_object_identity_id_seq', 169, true);


--
-- Name: acl_sid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: molgenis
--

SELECT pg_catalog.setval('public.acl_sid_id_seq', 7, true);


--
-- Name: Version Version_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."Version"
    ADD CONSTRAINT "Version_pkey" PRIMARY KEY (id);


--
-- Name: acl_class acl_class_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_class
    ADD CONSTRAINT acl_class_pkey PRIMARY KEY (id);


--
-- Name: acl_entry acl_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_entry
    ADD CONSTRAINT acl_entry_pkey PRIMARY KEY (id);


--
-- Name: acl_object_identity acl_object_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_object_identity
    ADD CONSTRAINT acl_object_identity_pkey PRIMARY KEY (id);


--
-- Name: acl_sid acl_sid_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_sid
    ADD CONSTRAINT acl_sid_pkey PRIMARY KEY (id);


--
-- Name: it_emx_autoid_testAutoId#46feeb51 it_emx_autoid_testA#46feeb51_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."it_emx_autoid_testAutoId#46feeb51"
    ADD CONSTRAINT "it_emx_autoid_testA#46feeb51_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_App#1723bf4f sys_App#1723bf4f_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_App#1723bf4f"
    ADD CONSTRAINT "sys_App#1723bf4f_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_App#1723bf4f sys_App#1723bf4f_name_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_App#1723bf4f"
    ADD CONSTRAINT "sys_App#1723bf4f_name_key" UNIQUE (name);


--
-- Name: sys_FileMeta#76d84794 sys_FileMeta#76d84794_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_FileMeta#76d84794"
    ADD CONSTRAINT "sys_FileMeta#76d84794_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_FileMeta#76d84794 sys_FileMeta#76d84794_url_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_FileMeta#76d84794"
    ADD CONSTRAINT "sys_FileMeta#76d84794_url_key" UNIQUE (url);


--
-- Name: sys_FreemarkerTemplate#1b0d9d12 sys_FreemarkerTempl#1b0d9d12_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_FreemarkerTemplate#1b0d9d12"
    ADD CONSTRAINT "sys_FreemarkerTempl#1b0d9d12_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_FreemarkerTemplate#1b0d9d12 sys_FreemarkerTempla#1b0d9d12_Name_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_FreemarkerTemplate#1b0d9d12"
    ADD CONSTRAINT "sys_FreemarkerTempla#1b0d9d12_Name_key" UNIQUE ("Name");


--
-- Name: sys_ImportRun#5ed65642 sys_ImportRun#5ed65642_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ImportRun#5ed65642"
    ADD CONSTRAINT "sys_ImportRun#5ed65642_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_L10nString#95a21e09 sys_L10nString#95a21e09_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_L10nString#95a21e09"
    ADD CONSTRAINT "sys_L10nString#95a21e09_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_Language#ab857455 sys_Language#ab857455_code_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_Language#ab857455"
    ADD CONSTRAINT "sys_Language#ab857455_code_pkey" PRIMARY KEY (code);


--
-- Name: sys_Plugin#4fafb60a sys_Plugin#4fafb60a_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_Plugin#4fafb60a"
    ADD CONSTRAINT "sys_Plugin#4fafb60a_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_Plugin#4fafb60a sys_Plugin#4fafb60a_label_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_Plugin#4fafb60a"
    ADD CONSTRAINT "sys_Plugin#4fafb60a_label_key" UNIQUE (label);


--
-- Name: sys_Plugin#4fafb60a sys_Plugin#4fafb60a_path_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_Plugin#4fafb60a"
    ADD CONSTRAINT "sys_Plugin#4fafb60a_path_key" UNIQUE (path);


--
-- Name: sys_StaticContent#f1dd2665 sys_StaticContent#f1dd2665_key__pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_StaticContent#f1dd2665"
    ADD CONSTRAINT "sys_StaticContent#f1dd2665_key__pkey" PRIMARY KEY (key_);


--
-- Name: sys_beacons_Beacon#8e99cfb8_data_sets sys_beacons_Beacon#8e99cfb8_data_sets_id_data_sets_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_Beacon#8e99cfb8_data_sets"
    ADD CONSTRAINT "sys_beacons_Beacon#8e99cfb8_data_sets_id_data_sets_key" UNIQUE (id, data_sets);


--
-- Name: sys_beacons_Beacon#8e99cfb8_data_sets sys_beacons_Beacon#8e99cfb8_data_sets_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_Beacon#8e99cfb8_data_sets"
    ADD CONSTRAINT "sys_beacons_Beacon#8e99cfb8_data_sets_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_beacons_Beacon#8e99cfb8 sys_beacons_Beacon#8e99cfb8_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_Beacon#8e99cfb8"
    ADD CONSTRAINT "sys_beacons_Beacon#8e99cfb8_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_beacons_BeaconDataset#17b7de29 sys_beacons_BeaconD#17b7de29_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_BeaconDataset#17b7de29"
    ADD CONSTRAINT "sys_beacons_BeaconD#17b7de29_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_beacons_BeaconOrganization#02fc7b88 sys_beacons_BeaconO#02fc7b88_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_BeaconOrganization#02fc7b88"
    ADD CONSTRAINT "sys_beacons_BeaconO#02fc7b88_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_dec_DecoratorConfiguration#e9347da9 sys_dec_DecoratorCo#e9347da9_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorConfiguration#e9347da9"
    ADD CONSTRAINT "sys_dec_DecoratorCo#e9347da9_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_dec_DecoratorConfiguration#e9347da9 sys_dec_DecoratorCon#e9347da9_entityTypeId_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorConfiguration#e9347da9"
    ADD CONSTRAINT "sys_dec_DecoratorCon#e9347da9_entityTypeId_key" UNIQUE ("entityTypeId");


--
-- Name: sys_dec_DecoratorConfi#e9347da9_parameters sys_dec_DecoratorConfi#e9347da9_parameters_id_parameters_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorConfi#e9347da9_parameters"
    ADD CONSTRAINT "sys_dec_DecoratorConfi#e9347da9_parameters_id_parameters_key" UNIQUE (id, parameters);


--
-- Name: sys_dec_DecoratorConfi#e9347da9_parameters sys_dec_DecoratorConfi#e9347da9_parameters_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorConfi#e9347da9_parameters"
    ADD CONSTRAINT "sys_dec_DecoratorConfi#e9347da9_parameters_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_dec_DecoratorParameters#0c01537a sys_dec_DecoratorPa#0c01537a_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorParameters#0c01537a"
    ADD CONSTRAINT "sys_dec_DecoratorPa#0c01537a_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_dec_DynamicDecorator#8c3531bb sys_dec_DynamicDeco#8c3531bb_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DynamicDecorator#8c3531bb"
    ADD CONSTRAINT "sys_dec_DynamicDeco#8c3531bb_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_genomebrowser_GenomeBrowserSettings#294012a4 sys_genomebrowser_G#294012a4_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_GenomeBrowserSettings#294012a4"
    ADD CONSTRAINT "sys_genomebrowser_G#294012a4_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_genomebrowser_GenomeBrowserAttributes#bf815a63 sys_genomebrowser_G#bf815a63_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63"
    ADD CONSTRAINT "sys_genomebrowser_G#bf815a63_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_genomebrowser_GenomeBrowserAttributes#bf815a63 sys_genomebrowser_Ge#bf815a63_order_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63"
    ADD CONSTRAINT "sys_genomebrowser_Ge#bf815a63_order_key" UNIQUE ("order");


--
-- Name: sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks sys_genomebrowser_Geno#294012a4_molgenis_reference_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks"
    ADD CONSTRAINT "sys_genomebrowser_Geno#294012a4_molgenis_reference_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks sys_genomebrowser_Geno#294012a_id_molgenis_reference_tracks_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks"
    ADD CONSTRAINT "sys_genomebrowser_Geno#294012a_id_molgenis_reference_tracks_key" UNIQUE (id, molgenis_reference_tracks);


--
-- Name: sys_idx_IndexAction#43bbc99b sys_idx_IndexAction#43bbc99b_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_idx_IndexAction#43bbc99b"
    ADD CONSTRAINT "sys_idx_IndexAction#43bbc99b_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_idx_IndexActionGroup#dd7eea75 sys_idx_IndexAction#dd7eea75_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_idx_IndexActionGroup#dd7eea75"
    ADD CONSTRAINT "sys_idx_IndexAction#dd7eea75_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_job_AmazonBucketJobExecution#f9fb2a28 sys_job_AmazonBucke#f9fb2a28_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_AmazonBucketJobExecution#f9fb2a28"
    ADD CONSTRAINT "sys_job_AmazonBucke#f9fb2a28_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_FileIngestJobExecution#091fdb52 sys_job_FileIngestJ#091fdb52_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_FileIngestJobExecution#091fdb52"
    ADD CONSTRAINT "sys_job_FileIngestJ#091fdb52_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_IndexJobExecution#1d1bc397 sys_job_IndexJobExe#1d1bc397_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_IndexJobExecution#1d1bc397"
    ADD CONSTRAINT "sys_job_IndexJobExe#1d1bc397_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_MappingJobExecution#9d59355f sys_job_MappingJobE#9d59355f_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_MappingJobExecution#9d59355f"
    ADD CONSTRAINT "sys_job_MappingJobE#9d59355f_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_OneClickImportJobExecution#c6636b72 sys_job_OneClickImp#c6636b72_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_OneClickImportJobExecution#c6636b72"
    ADD CONSTRAINT "sys_job_OneClickImp#c6636b72_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_ResourceCopyJobExecution#79e3e597 sys_job_ResourceCop#79e3e597_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ResourceCopyJobExecution#79e3e597"
    ADD CONSTRAINT "sys_job_ResourceCop#79e3e597_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_ResourceDeleteJobExecution#5d6022b0 sys_job_ResourceDel#5d6022b0_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ResourceDeleteJobExecution#5d6022b0"
    ADD CONSTRAINT "sys_job_ResourceDel#5d6022b0_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_ResourceDownloadJobExecution#3d0dbc70 sys_job_ResourceDow#3d0dbc70_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ResourceDownloadJobExecution#3d0dbc70"
    ADD CONSTRAINT "sys_job_ResourceDow#3d0dbc70_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_ScheduledJob#d2aed7e4 sys_job_ScheduledJo#d2aed7e4_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ScheduledJob#d2aed7e4"
    ADD CONSTRAINT "sys_job_ScheduledJo#d2aed7e4_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_job_ScheduledJobType#d68c491a sys_job_ScheduledJo#d68c491a_name_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ScheduledJobType#d68c491a"
    ADD CONSTRAINT "sys_job_ScheduledJo#d68c491a_name_pkey" PRIMARY KEY (name);


--
-- Name: sys_job_ScheduledJob#d2aed7e4 sys_job_ScheduledJob#d2aed7e4_name_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ScheduledJob#d2aed7e4"
    ADD CONSTRAINT "sys_job_ScheduledJob#d2aed7e4_name_key" UNIQUE (name);


--
-- Name: sys_job_ScriptJobExecution#26f219e1 sys_job_ScriptJobEx#26f219e1_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ScriptJobExecution#26f219e1"
    ADD CONSTRAINT "sys_job_ScriptJobEx#26f219e1_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_job_SortaJobExecution#3df661b2 sys_job_SortaJobExe#3df661b2_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_SortaJobExecution#3df661b2"
    ADD CONSTRAINT "sys_job_SortaJobExe#3df661b2_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_mail_JavaMailProperty#ddcd42a8 sys_mail_JavaMailPr#ddcd42a8_key_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_mail_JavaMailProperty#ddcd42a8"
    ADD CONSTRAINT "sys_mail_JavaMailPr#ddcd42a8_key_pkey" PRIMARY KEY (key);


--
-- Name: sys_map_AttributeMapping#fdffac26 sys_map_AttributeMa#fdffac26_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_AttributeMapping#fdffac26"
    ADD CONSTRAINT "sys_map_AttributeMa#fdffac26_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_map_EntityMapping#4c287e1a sys_map_EntityMappi#4c287e1a_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_EntityMapping#4c287e1a"
    ADD CONSTRAINT "sys_map_EntityMappi#4c287e1a_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_map_EntityMapping#4c287e1a_attributeMappings sys_map_EntityMapping#4c287e1a_attributeMa_order_identifier_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_EntityMapping#4c287e1a_attributeMappings"
    ADD CONSTRAINT "sys_map_EntityMapping#4c287e1a_attributeMa_order_identifier_key" UNIQUE ("order", identifier);


--
-- Name: sys_map_EntityMapping#4c287e1a_attributeMappings sys_map_EntityMapping#4c287e1a_identifier_attributeMappings_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_EntityMapping#4c287e1a_attributeMappings"
    ADD CONSTRAINT "sys_map_EntityMapping#4c287e1a_identifier_attributeMappings_key" UNIQUE (identifier, "attributeMappings");


--
-- Name: sys_map_MappingProject#c2f22991 sys_map_MappingProj#c2f22991_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingProject#c2f22991"
    ADD CONSTRAINT "sys_map_MappingProj#c2f22991_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_map_MappingProject#c2f22991_mappingtargets sys_map_MappingProject#c2f22991_m_identifier_mappingtargets_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingProject#c2f22991_mappingtargets"
    ADD CONSTRAINT "sys_map_MappingProject#c2f22991_m_identifier_mappingtargets_key" UNIQUE (identifier, mappingtargets);


--
-- Name: sys_map_MappingProject#c2f22991_mappingtargets sys_map_MappingProject#c2f22991_mappingtar_order_identifier_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingProject#c2f22991_mappingtargets"
    ADD CONSTRAINT "sys_map_MappingProject#c2f22991_mappingtar_order_identifier_key" UNIQUE ("order", identifier);


--
-- Name: sys_map_MappingTarget#8e135dd7 sys_map_MappingTarg#8e135dd7_identifier_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingTarget#8e135dd7"
    ADD CONSTRAINT "sys_map_MappingTarg#8e135dd7_identifier_pkey" PRIMARY KEY (identifier);


--
-- Name: sys_map_MappingTarget#8e135dd7_entityMappings sys_map_MappingTarget#8e135dd7_en_identifier_entityMappings_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingTarget#8e135dd7_entityMappings"
    ADD CONSTRAINT "sys_map_MappingTarget#8e135dd7_en_identifier_entityMappings_key" UNIQUE (identifier, "entityMappings");


--
-- Name: sys_map_MappingTarget#8e135dd7_entityMappings sys_map_MappingTarget#8e135dd7_entityMappi_order_identifier_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingTarget#8e135dd7_entityMappings"
    ADD CONSTRAINT "sys_map_MappingTarget#8e135dd7_entityMappi_order_identifier_key" UNIQUE ("order", identifier);


--
-- Name: sys_md_Attribute#c8d9a252 sys_md_Attribute#c8d9a252_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_md_Attribute#c8d9a252_tags sys_md_Attribute#c8d9a252_tags_id_tags_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252_tags"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_tags_id_tags_key" UNIQUE (id, tags);


--
-- Name: sys_md_Attribute#c8d9a252_tags sys_md_Attribute#c8d9a252_tags_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252_tags"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_tags_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_md_EntityType#6a3870a0 sys_md_EntityType#6a3870a0_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_EntityType#6a3870a0"
    ADD CONSTRAINT "sys_md_EntityType#6a3870a0_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_md_EntityType#6a3870a0_tags sys_md_EntityType#6a3870a0_tags_id_tags_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_EntityType#6a3870a0_tags"
    ADD CONSTRAINT "sys_md_EntityType#6a3870a0_tags_id_tags_key" UNIQUE (id, tags);


--
-- Name: sys_md_EntityType#6a3870a0_tags sys_md_EntityType#6a3870a0_tags_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_EntityType#6a3870a0_tags"
    ADD CONSTRAINT "sys_md_EntityType#6a3870a0_tags_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_md_Package#a6dc6fe7 sys_md_Package#a6dc6fe7_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Package#a6dc6fe7"
    ADD CONSTRAINT "sys_md_Package#a6dc6fe7_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_md_Package#a6dc6fe7_tags sys_md_Package#a6dc6fe7_tags_id_tags_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Package#a6dc6fe7_tags"
    ADD CONSTRAINT "sys_md_Package#a6dc6fe7_tags_id_tags_key" UNIQUE (id, tags);


--
-- Name: sys_md_Package#a6dc6fe7_tags sys_md_Package#a6dc6fe7_tags_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Package#a6dc6fe7_tags"
    ADD CONSTRAINT "sys_md_Package#a6dc6fe7_tags_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_md_Tag#c2d685da sys_md_Tag#c2d685da_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Tag#c2d685da"
    ADD CONSTRAINT "sys_md_Tag#c2d685da_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_negotiator_NegotiatorEntityConfig#9a61747d sys_negotiator_Nego#9a61747d_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_negotiator_NegotiatorEntityConfig#9a61747d"
    ADD CONSTRAINT "sys_negotiator_Nego#9a61747d_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_negotiator_NegotiatorConfig#aced883a sys_negotiator_Nego#aced883a_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_negotiator_NegotiatorConfig#aced883a"
    ADD CONSTRAINT "sys_negotiator_Nego#aced883a_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_ont_Ontology#49a81949 sys_ont_Ontology#49a81949_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_Ontology#49a81949"
    ADD CONSTRAINT "sys_ont_Ontology#49a81949_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_ont_OntologyTermDynamicAnnotation#6454b1f8 sys_ont_OntologyTer#6454b1f8_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermDynamicAnnotation#6454b1f8"
    ADD CONSTRAINT "sys_ont_OntologyTer#6454b1f8_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_ont_OntologyTermHit#9ce87f6a sys_ont_OntologyTer#9ce87f6a_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHit#9ce87f6a"
    ADD CONSTRAINT "sys_ont_OntologyTer#9ce87f6a_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_ont_OntologyTermNodePath#adc5397c sys_ont_OntologyTer#adc5397c_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermNodePath#adc5397c"
    ADD CONSTRAINT "sys_ont_OntologyTer#adc5397c_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_ont_OntologyTermSynonym#ce764ed4 sys_ont_OntologyTer#ce764ed4_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermSynonym#ce764ed4"
    ADD CONSTRAINT "sys_ont_OntologyTer#ce764ed4_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_ont_OntologyTerm#f0034aa0 sys_ont_OntologyTer#f0034aa0_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0"
    ADD CONSTRAINT "sys_ont_OntologyTer#f0034aa0_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation sys_ont_OntologyTerm#f0034aa0_id_ontologyTermDynamicAnnotat_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_id_ontologyTermDynamicAnnotat_key" UNIQUE (id, "ontologyTermDynamicAnnotation");


--
-- Name: sys_ont_OntologyTerm#f0034aa0_nodePath sys_ont_OntologyTerm#f0034aa0_nodePath_id_nodePath_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_nodePath_id_nodePath_key" UNIQUE (id, "nodePath");


--
-- Name: sys_ont_OntologyTerm#f0034aa0_nodePath sys_ont_OntologyTerm#f0034aa0_nodePath_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_nodePath_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym sys_ont_OntologyTerm#f0034aa0_ontolo_id_ontologyTermSynonym_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_ontolo_id_ontologyTermSynonym_key" UNIQUE (id, "ontologyTermSynonym");


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicA_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicA_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_nodePath sys_ont_OntologyTermHi#9ce87f6a_nodePath_id_nodePath_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_nodePath_id_nodePath_key" UNIQUE (id, "nodePath");


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_nodePath sys_ont_OntologyTermHi#9ce87f6a_nodePath_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_nodePath_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym sys_ont_OntologyTermHi#9ce87f6a_onto_id_ontologyTermSynonym_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_onto_id_ontologyTermSynonym_key" UNIQUE (id, "ontologyTermSynonym");


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynami_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynami_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynony_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynony_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation sys_ont_OntologyTermHi#9ce87f_id_ontologyTermDynamicAnnotat_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f_id_ontologyTermDynamicAnnotat_key" UNIQUE (id, "ontologyTermDynamicAnnotation");


--
-- Name: sys_ont_TermFrequency#aef76974 sys_ont_TermFrequen#aef76974_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_TermFrequency#aef76974"
    ADD CONSTRAINT "sys_ont_TermFrequen#aef76974_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_scr_Script#354cd12b sys_scr_Script#354cd12b_name_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_Script#354cd12b"
    ADD CONSTRAINT "sys_scr_Script#354cd12b_name_pkey" PRIMARY KEY (name);


--
-- Name: sys_scr_Script#354cd12b_parameters sys_scr_Script#354cd12b_parameters_name_parameters_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_Script#354cd12b_parameters"
    ADD CONSTRAINT "sys_scr_Script#354cd12b_parameters_name_parameters_key" UNIQUE (name, parameters);


--
-- Name: sys_scr_Script#354cd12b_parameters sys_scr_Script#354cd12b_parameters_order_name_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_Script#354cd12b_parameters"
    ADD CONSTRAINT "sys_scr_Script#354cd12b_parameters_order_name_key" UNIQUE ("order", name);


--
-- Name: sys_scr_ScriptParameter#88bc2dd2 sys_scr_ScriptParam#88bc2dd2_name_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_ScriptParameter#88bc2dd2"
    ADD CONSTRAINT "sys_scr_ScriptParam#88bc2dd2_name_pkey" PRIMARY KEY (name);


--
-- Name: sys_scr_ScriptType#3e8906a6 sys_scr_ScriptType#3e8906a6_name_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_ScriptType#3e8906a6"
    ADD CONSTRAINT "sys_scr_ScriptType#3e8906a6_name_pkey" PRIMARY KEY (name);


--
-- Name: sys_sec_Group#d325f6e2 sys_sec_Group#d325f6e2_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Group#d325f6e2"
    ADD CONSTRAINT "sys_sec_Group#d325f6e2_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_Group#d325f6e2 sys_sec_Group#d325f6e2_name_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Group#d325f6e2"
    ADD CONSTRAINT "sys_sec_Group#d325f6e2_name_key" UNIQUE (name);


--
-- Name: sys_sec_Group#d325f6e2 sys_sec_Group#d325f6e2_rootPackage_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Group#d325f6e2"
    ADD CONSTRAINT "sys_sec_Group#d325f6e2_rootPackage_key" UNIQUE ("rootPackage");


--
-- Name: sys_sec_MembershipInvitation#27f7958b sys_sec_MembershipI#27f7958b_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_MembershipInvitation#27f7958b"
    ADD CONSTRAINT "sys_sec_MembershipI#27f7958b_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_PasswordResetToken#a04705dd sys_sec_PasswordRes#a04705dd_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_PasswordResetToken#a04705dd"
    ADD CONSTRAINT "sys_sec_PasswordRes#a04705dd_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_PasswordResetToken#a04705dd sys_sec_PasswordRese#a04705dd_token_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_PasswordResetToken#a04705dd"
    ADD CONSTRAINT "sys_sec_PasswordRese#a04705dd_token_key" UNIQUE (token);


--
-- Name: sys_sec_PasswordResetToken#a04705dd sys_sec_PasswordRese#a04705dd_user_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_PasswordResetToken#a04705dd"
    ADD CONSTRAINT "sys_sec_PasswordRese#a04705dd_user_key" UNIQUE ("user");


--
-- Name: sys_sec_RecoveryCode#a3192a80 sys_sec_RecoveryCod#a3192a80_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_RecoveryCode#a3192a80"
    ADD CONSTRAINT "sys_sec_RecoveryCod#a3192a80_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_Role#b6639604 sys_sec_Role#b6639604_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Role#b6639604"
    ADD CONSTRAINT "sys_sec_Role#b6639604_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_Role#b6639604_includes sys_sec_Role#b6639604_includes_id_includes_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Role#b6639604_includes"
    ADD CONSTRAINT "sys_sec_Role#b6639604_includes_id_includes_key" UNIQUE (id, includes);


--
-- Name: sys_sec_Role#b6639604_includes sys_sec_Role#b6639604_includes_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Role#b6639604_includes"
    ADD CONSTRAINT "sys_sec_Role#b6639604_includes_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_sec_Role#b6639604 sys_sec_Role#b6639604_name_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Role#b6639604"
    ADD CONSTRAINT "sys_sec_Role#b6639604_name_key" UNIQUE (name);


--
-- Name: sys_sec_RoleMembership#2f0e0432 sys_sec_RoleMembers#2f0e0432_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_RoleMembership#2f0e0432"
    ADD CONSTRAINT "sys_sec_RoleMembers#2f0e0432_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_Token#2dc001d0 sys_sec_Token#2dc001d0_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Token#2dc001d0"
    ADD CONSTRAINT "sys_sec_Token#2dc001d0_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_Token#2dc001d0 sys_sec_Token#2dc001d0_token_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Token#2dc001d0"
    ADD CONSTRAINT "sys_sec_Token#2dc001d0_token_key" UNIQUE (token);


--
-- Name: sys_sec_User#953f6cde sys_sec_User#953f6cde_Email_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_User#953f6cde"
    ADD CONSTRAINT "sys_sec_User#953f6cde_Email_key" UNIQUE ("Email");


--
-- Name: sys_sec_User#953f6cde sys_sec_User#953f6cde_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_User#953f6cde"
    ADD CONSTRAINT "sys_sec_User#953f6cde_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_User#953f6cde sys_sec_User#953f6cde_username_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_User#953f6cde"
    ADD CONSTRAINT "sys_sec_User#953f6cde_username_key" UNIQUE (username);


--
-- Name: sys_sec_UserSecret#f51533c3 sys_sec_UserSecret#f51533c3_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_UserSecret#f51533c3"
    ADD CONSTRAINT "sys_sec_UserSecret#f51533c3_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_UserSecret#f51533c3 sys_sec_UserSecret#f51533c3_userId_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_UserSecret#f51533c3"
    ADD CONSTRAINT "sys_sec_UserSecret#f51533c3_userId_key" UNIQUE ("userId");


--
-- Name: sys_sec_oidc_OidcClient#3e7b1b4d sys_sec_oidc_OidcCl#3e7b1b4d_registrationId_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_oidc_OidcClient#3e7b1b4d"
    ADD CONSTRAINT "sys_sec_oidc_OidcCl#3e7b1b4d_registrationId_pkey" PRIMARY KEY ("registrationId");


--
-- Name: sys_sec_oidc_OidcClient#3e7b1b4d sys_sec_oidc_OidcCli#3e7b1b4d_clientId_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_oidc_OidcClient#3e7b1b4d"
    ADD CONSTRAINT "sys_sec_oidc_OidcCli#3e7b1b4d_clientId_key" UNIQUE ("clientId");


--
-- Name: sys_sec_oidc_OidcClient#3e7b1b4d sys_sec_oidc_OidcCli#3e7b1b4d_clientName_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_oidc_OidcClient#3e7b1b4d"
    ADD CONSTRAINT "sys_sec_oidc_OidcCli#3e7b1b4d_clientName_key" UNIQUE ("clientName");


--
-- Name: sys_sec_oidc_OidcUserMapping#72060861 sys_sec_oidc_OidcUs#72060861_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_oidc_OidcUserMapping#72060861"
    ADD CONSTRAINT "sys_sec_oidc_OidcUs#72060861_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_sec_oidc_OidcUserMapping#72060861 sys_sec_oidc_OidcUse#72060861_label_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_oidc_OidcUserMapping#72060861"
    ADD CONSTRAINT "sys_sec_oidc_OidcUse#72060861_label_key" UNIQUE (label);


--
-- Name: sys_set_MailSettings#6daa44ed sys_set_MailSetting#6daa44ed_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_MailSettings#6daa44ed"
    ADD CONSTRAINT "sys_set_MailSetting#6daa44ed_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_set_OpenCpuSettings#0ec0e4e8 sys_set_OpenCpuSett#0ec0e4e8_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_OpenCpuSettings#0ec0e4e8"
    ADD CONSTRAINT "sys_set_OpenCpuSett#0ec0e4e8_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_set_StyleSheet#9d5413fc sys_set_StyleSheet#9d5413fc_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_StyleSheet#9d5413fc"
    ADD CONSTRAINT "sys_set_StyleSheet#9d5413fc_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_set_app#4f91996f sys_set_app#4f91996f_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_app#4f91996f"
    ADD CONSTRAINT "sys_set_app#4f91996f_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_set_auth#98c4c015 sys_set_auth#98c4c015_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_auth#98c4c015"
    ADD CONSTRAINT "sys_set_auth#98c4c015_id_pkey" PRIMARY KEY (id);


--
-- Name: sys_set_auth#98c4c015_oidcClients sys_set_auth#98c4c015_oidcClients_id_oidcClients_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_auth#98c4c015_oidcClients"
    ADD CONSTRAINT "sys_set_auth#98c4c015_oidcClients_id_oidcClients_key" UNIQUE (id, "oidcClients");


--
-- Name: sys_set_auth#98c4c015_oidcClients sys_set_auth#98c4c015_oidcClients_order_id_key; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_auth#98c4c015_oidcClients"
    ADD CONSTRAINT "sys_set_auth#98c4c015_oidcClients_order_id_key" UNIQUE ("order", id);


--
-- Name: sys_set_dataexplorer#76c80fb0 sys_set_dataexplore#76c80fb0_id_pkey; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_dataexplorer#76c80fb0"
    ADD CONSTRAINT "sys_set_dataexplore#76c80fb0_id_pkey" PRIMARY KEY (id);


--
-- Name: acl_sid unique_uk_1; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_sid
    ADD CONSTRAINT unique_uk_1 UNIQUE (sid, principal);


--
-- Name: acl_class unique_uk_2; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_class
    ADD CONSTRAINT unique_uk_2 UNIQUE (class);


--
-- Name: acl_object_identity unique_uk_3; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_object_identity
    ADD CONSTRAINT unique_uk_3 UNIQUE (object_id_class, object_id_identity);


--
-- Name: acl_entry unique_uk_4; Type: CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_entry
    ADD CONSTRAINT unique_uk_4 UNIQUE (acl_object_identity, ace_order);


--
-- Name: sys_beacon#8e99cfb8_data_sets_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_beacon#8e99cfb8_data_sets_id_idx" ON public."sys_beacons_Beacon#8e99cfb8_data_sets" USING btree (id);


--
-- Name: sys_dec_De#e9347da9_parameters_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_dec_De#e9347da9_parameters_id_idx" ON public."sys_dec_DecoratorConfi#e9347da9_parameters" USING btree (id);


--
-- Name: sys_genome#294012a4_molgenis_r#29a78256_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_genome#294012a4_molgenis_r#29a78256_id_idx" ON public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks" USING btree (id);


--
-- Name: sys_map_En#4c287e1a_attributeMappings_identifier_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_map_En#4c287e1a_attributeMappings_identifier_idx" ON public."sys_map_EntityMapping#4c287e1a_attributeMappings" USING btree (identifier);


--
-- Name: sys_map_Ma#8e135dd7_entityMappings_identifier_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_map_Ma#8e135dd7_entityMappings_identifier_idx" ON public."sys_map_MappingTarget#8e135dd7_entityMappings" USING btree (identifier);


--
-- Name: sys_map_Ma#c2f22991_mappingtargets_identifier_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_map_Ma#c2f22991_mappingtargets_identifier_idx" ON public."sys_map_MappingProject#c2f22991_mappingtargets" USING btree (identifier);


--
-- Name: sys_md_Att#c8d9a252_tags_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_md_Att#c8d9a252_tags_id_idx" ON public."sys_md_Attribute#c8d9a252_tags" USING btree (id);


--
-- Name: sys_md_Ent#6a3870a0_tags_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_md_Ent#6a3870a0_tags_id_idx" ON public."sys_md_EntityType#6a3870a0_tags" USING btree (id);


--
-- Name: sys_md_Pac#a6dc6fe7_tags_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_md_Pac#a6dc6fe7_tags_id_idx" ON public."sys_md_Package#a6dc6fe7_tags" USING btree (id);


--
-- Name: sys_ont_On#9ce87f6a_nodePath_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_ont_On#9ce87f6a_nodePath_id_idx" ON public."sys_ont_OntologyTermHi#9ce87f6a_nodePath" USING btree (id);


--
-- Name: sys_ont_On#9ce87f6a_ontologyTe#9c359a9b_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_ont_On#9ce87f6a_ontologyTe#9c359a9b_id_idx" ON public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation" USING btree (id);


--
-- Name: sys_ont_On#9ce87f6a_ontologyTermSynonym_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_ont_On#9ce87f6a_ontologyTermSynonym_id_idx" ON public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym" USING btree (id);


--
-- Name: sys_ont_On#f0034aa0_nodePath_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_ont_On#f0034aa0_nodePath_id_idx" ON public."sys_ont_OntologyTerm#f0034aa0_nodePath" USING btree (id);


--
-- Name: sys_ont_On#f0034aa0_ontologyTe#2624ef97_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_ont_On#f0034aa0_ontologyTe#2624ef97_id_idx" ON public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation" USING btree (id);


--
-- Name: sys_ont_On#f0034aa0_ontologyTermSynonym_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_ont_On#f0034aa0_ontologyTermSynonym_id_idx" ON public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym" USING btree (id);


--
-- Name: sys_scr_Sc#354cd12b_parameters_name_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_scr_Sc#354cd12b_parameters_name_idx" ON public."sys_scr_Script#354cd12b_parameters" USING btree (name);


--
-- Name: sys_sec_Ro#b6639604_includes_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_sec_Ro#b6639604_includes_id_idx" ON public."sys_sec_Role#b6639604_includes" USING btree (id);


--
-- Name: sys_set_au#98c4c015_oidcClients_id_idx; Type: INDEX; Schema: public; Owner: molgenis
--

CREATE INDEX "sys_set_au#98c4c015_oidcClients_id_idx" ON public."sys_set_auth#98c4c015_oidcClients" USING btree (id);


--
-- Name: it_emx_autoid_testAutoId#46feeb51 update_trigger_it_emx_autoid_testAutoId#46feeb51; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_it_emx_autoid_testAutoId#46feeb51" AFTER UPDATE ON public."it_emx_autoid_testAutoId#46feeb51" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_it_emx_autoid_testAutoId#46feeb51"();


--
-- Name: sys_App#1723bf4f update_trigger_sys_App#1723bf4f; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_App#1723bf4f" AFTER UPDATE ON public."sys_App#1723bf4f" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_App#1723bf4f"();


--
-- Name: sys_FileMeta#76d84794 update_trigger_sys_FileMeta#76d84794; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_FileMeta#76d84794" AFTER UPDATE ON public."sys_FileMeta#76d84794" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_FileMeta#76d84794"();


--
-- Name: sys_FreemarkerTemplate#1b0d9d12 update_trigger_sys_FreemarkerTemplate#1b0d9d12; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_FreemarkerTemplate#1b0d9d12" AFTER UPDATE ON public."sys_FreemarkerTemplate#1b0d9d12" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_FreemarkerTemplate#1b0d9d12"();


--
-- Name: sys_ImportRun#5ed65642 update_trigger_sys_ImportRun#5ed65642; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ImportRun#5ed65642" AFTER UPDATE ON public."sys_ImportRun#5ed65642" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ImportRun#5ed65642"();


--
-- Name: sys_L10nString#95a21e09 update_trigger_sys_L10nString#95a21e09; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_L10nString#95a21e09" AFTER UPDATE ON public."sys_L10nString#95a21e09" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_L10nString#95a21e09"();


--
-- Name: sys_Language#ab857455 update_trigger_sys_Language#ab857455; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_Language#ab857455" AFTER UPDATE ON public."sys_Language#ab857455" FOR EACH ROW WHEN (((old.code)::text IS DISTINCT FROM (new.code)::text)) EXECUTE PROCEDURE public."validate_update_sys_Language#ab857455"();


--
-- Name: sys_Plugin#4fafb60a update_trigger_sys_Plugin#4fafb60a; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_Plugin#4fafb60a" AFTER UPDATE ON public."sys_Plugin#4fafb60a" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR ((old.path)::text IS DISTINCT FROM (new.path)::text))) EXECUTE PROCEDURE public."validate_update_sys_Plugin#4fafb60a"();


--
-- Name: sys_StaticContent#f1dd2665 update_trigger_sys_StaticContent#f1dd2665; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_StaticContent#f1dd2665" AFTER UPDATE ON public."sys_StaticContent#f1dd2665" FOR EACH ROW WHEN (((old.key_)::text IS DISTINCT FROM (new.key_)::text)) EXECUTE PROCEDURE public."validate_update_sys_StaticContent#f1dd2665"();


--
-- Name: sys_beacons_Beacon#8e99cfb8 update_trigger_sys_beacons_Beacon#8e99cfb8; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_beacons_Beacon#8e99cfb8" AFTER UPDATE ON public."sys_beacons_Beacon#8e99cfb8" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_beacons_Beacon#8e99cfb8"();


--
-- Name: sys_beacons_BeaconDataset#17b7de29 update_trigger_sys_beacons_BeaconDataset#17b7de29; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_beacons_BeaconDataset#17b7de29" AFTER UPDATE ON public."sys_beacons_BeaconDataset#17b7de29" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_beacons_BeaconDataset#17b7de29"();


--
-- Name: sys_beacons_BeaconOrganization#02fc7b88 update_trigger_sys_beacons_BeaconOrganization#02fc7b88; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_beacons_BeaconOrganization#02fc7b88" AFTER UPDATE ON public."sys_beacons_BeaconOrganization#02fc7b88" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_beacons_BeaconOrganization#02fc7b88"();


--
-- Name: sys_dec_DecoratorConfiguration#e9347da9 update_trigger_sys_dec_DecoratorConfiguration#e9347da9; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_dec_DecoratorConfiguration#e9347da9" AFTER UPDATE ON public."sys_dec_DecoratorConfiguration#e9347da9" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_dec_DecoratorConfiguration#e9347da9"();


--
-- Name: sys_dec_DecoratorParameters#0c01537a update_trigger_sys_dec_DecoratorParameters#0c01537a; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_dec_DecoratorParameters#0c01537a" AFTER UPDATE ON public."sys_dec_DecoratorParameters#0c01537a" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_dec_DecoratorParameters#0c01537a"();


--
-- Name: sys_dec_DynamicDecorator#8c3531bb update_trigger_sys_dec_DynamicDecorator#8c3531bb; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_dec_DynamicDecorator#8c3531bb" AFTER UPDATE ON public."sys_dec_DynamicDecorator#8c3531bb" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_dec_DynamicDecorator#8c3531bb"();


--
-- Name: sys_genomebrowser_GenomeBrowserAttributes#bf815a63 update_trigger_sys_genomebrowser_GenomeBrowserAttribut#bf815a63; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_genomebrowser_GenomeBrowserAttribut#bf815a63" AFTER UPDATE ON public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_genomebrowser_GenomeBrowserAttribu#bf815a63"();


--
-- Name: sys_genomebrowser_GenomeBrowserSettings#294012a4 update_trigger_sys_genomebrowser_GenomeBrowserSettings#294012a4; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_genomebrowser_GenomeBrowserSettings#294012a4" AFTER UPDATE ON public."sys_genomebrowser_GenomeBrowserSettings#294012a4" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_genomebrowser_GenomeBrowserSetting#294012a4"();


--
-- Name: sys_idx_IndexAction#43bbc99b update_trigger_sys_idx_IndexAction#43bbc99b; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_idx_IndexAction#43bbc99b" AFTER UPDATE ON public."sys_idx_IndexAction#43bbc99b" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_idx_IndexAction#43bbc99b"();


--
-- Name: sys_idx_IndexActionGroup#dd7eea75 update_trigger_sys_idx_IndexActionGroup#dd7eea75; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_idx_IndexActionGroup#dd7eea75" AFTER UPDATE ON public."sys_idx_IndexActionGroup#dd7eea75" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_idx_IndexActionGroup#dd7eea75"();


--
-- Name: sys_job_AmazonBucketJobExecution#f9fb2a28 update_trigger_sys_job_AmazonBucketJobExecution#f9fb2a28; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_AmazonBucketJobExecution#f9fb2a28" AFTER UPDATE ON public."sys_job_AmazonBucketJobExecution#f9fb2a28" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_AmazonBucketJobExecution#f9fb2a28"();


--
-- Name: sys_job_FileIngestJobExecution#091fdb52 update_trigger_sys_job_FileIngestJobExecution#091fdb52; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_FileIngestJobExecution#091fdb52" AFTER UPDATE ON public."sys_job_FileIngestJobExecution#091fdb52" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_FileIngestJobExecution#091fdb52"();


--
-- Name: sys_job_IndexJobExecution#1d1bc397 update_trigger_sys_job_IndexJobExecution#1d1bc397; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_IndexJobExecution#1d1bc397" AFTER UPDATE ON public."sys_job_IndexJobExecution#1d1bc397" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_IndexJobExecution#1d1bc397"();


--
-- Name: sys_job_MappingJobExecution#9d59355f update_trigger_sys_job_MappingJobExecution#9d59355f; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_MappingJobExecution#9d59355f" AFTER UPDATE ON public."sys_job_MappingJobExecution#9d59355f" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_MappingJobExecution#9d59355f"();


--
-- Name: sys_job_OneClickImportJobExecution#c6636b72 update_trigger_sys_job_OneClickImportJobExecution#c6636b72; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_OneClickImportJobExecution#c6636b72" AFTER UPDATE ON public."sys_job_OneClickImportJobExecution#c6636b72" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_OneClickImportJobExecution#c6636b72"();


--
-- Name: sys_job_ResourceCopyJobExecution#79e3e597 update_trigger_sys_job_ResourceCopyJobExecution#79e3e597; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_ResourceCopyJobExecution#79e3e597" AFTER UPDATE ON public."sys_job_ResourceCopyJobExecution#79e3e597" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_ResourceCopyJobExecution#79e3e597"();


--
-- Name: sys_job_ResourceDeleteJobExecution#5d6022b0 update_trigger_sys_job_ResourceDeleteJobExecution#5d6022b0; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_ResourceDeleteJobExecution#5d6022b0" AFTER UPDATE ON public."sys_job_ResourceDeleteJobExecution#5d6022b0" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_ResourceDeleteJobExecution#5d6022b0"();


--
-- Name: sys_job_ResourceDownloadJobExecution#3d0dbc70 update_trigger_sys_job_ResourceDownloadJobExecution#3d0dbc70; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_ResourceDownloadJobExecution#3d0dbc70" AFTER UPDATE ON public."sys_job_ResourceDownloadJobExecution#3d0dbc70" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_ResourceDownloadJobExecution#3d0dbc70"();


--
-- Name: sys_job_ScheduledJob#d2aed7e4 update_trigger_sys_job_ScheduledJob#d2aed7e4; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_ScheduledJob#d2aed7e4" AFTER UPDATE ON public."sys_job_ScheduledJob#d2aed7e4" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_ScheduledJob#d2aed7e4"();


--
-- Name: sys_job_ScheduledJobType#d68c491a update_trigger_sys_job_ScheduledJobType#d68c491a; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_ScheduledJobType#d68c491a" AFTER UPDATE ON public."sys_job_ScheduledJobType#d68c491a" FOR EACH ROW WHEN (((old.name)::text IS DISTINCT FROM (new.name)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_ScheduledJobType#d68c491a"();


--
-- Name: sys_job_ScriptJobExecution#26f219e1 update_trigger_sys_job_ScriptJobExecution#26f219e1; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_ScriptJobExecution#26f219e1" AFTER UPDATE ON public."sys_job_ScriptJobExecution#26f219e1" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_ScriptJobExecution#26f219e1"();


--
-- Name: sys_job_SortaJobExecution#3df661b2 update_trigger_sys_job_SortaJobExecution#3df661b2; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_job_SortaJobExecution#3df661b2" AFTER UPDATE ON public."sys_job_SortaJobExecution#3df661b2" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_job_SortaJobExecution#3df661b2"();


--
-- Name: sys_mail_JavaMailProperty#ddcd42a8 update_trigger_sys_mail_JavaMailProperty#ddcd42a8; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_mail_JavaMailProperty#ddcd42a8" AFTER UPDATE ON public."sys_mail_JavaMailProperty#ddcd42a8" FOR EACH ROW WHEN ((((old."mailSettings")::text IS DISTINCT FROM (new."mailSettings")::text) OR ((old.key)::text IS DISTINCT FROM (new.key)::text))) EXECUTE PROCEDURE public."validate_update_sys_mail_JavaMailProperty#ddcd42a8"();


--
-- Name: sys_map_AttributeMapping#fdffac26 update_trigger_sys_map_AttributeMapping#fdffac26; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_map_AttributeMapping#fdffac26" AFTER UPDATE ON public."sys_map_AttributeMapping#fdffac26" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_map_AttributeMapping#fdffac26"();


--
-- Name: sys_map_EntityMapping#4c287e1a update_trigger_sys_map_EntityMapping#4c287e1a; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_map_EntityMapping#4c287e1a" AFTER UPDATE ON public."sys_map_EntityMapping#4c287e1a" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_map_EntityMapping#4c287e1a"();


--
-- Name: sys_map_MappingProject#c2f22991 update_trigger_sys_map_MappingProject#c2f22991; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_map_MappingProject#c2f22991" AFTER UPDATE ON public."sys_map_MappingProject#c2f22991" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_map_MappingProject#c2f22991"();


--
-- Name: sys_map_MappingTarget#8e135dd7 update_trigger_sys_map_MappingTarget#8e135dd7; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_map_MappingTarget#8e135dd7" AFTER UPDATE ON public."sys_map_MappingTarget#8e135dd7" FOR EACH ROW WHEN (((old.identifier)::text IS DISTINCT FROM (new.identifier)::text)) EXECUTE PROCEDURE public."validate_update_sys_map_MappingTarget#8e135dd7"();


--
-- Name: sys_md_Attribute#c8d9a252 update_trigger_sys_md_Attribute#c8d9a252; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_md_Attribute#c8d9a252" AFTER UPDATE ON public."sys_md_Attribute#c8d9a252" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR ((old.name)::text IS DISTINCT FROM (new.name)::text) OR ((old.entity)::text IS DISTINCT FROM (new.entity)::text) OR ((old."mappedBy")::text IS DISTINCT FROM (new."mappedBy")::text))) EXECUTE PROCEDURE public."validate_update_sys_md_Attribute#c8d9a252"();


--
-- Name: sys_md_EntityType#6a3870a0 update_trigger_sys_md_EntityType#6a3870a0; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_md_EntityType#6a3870a0" AFTER UPDATE ON public."sys_md_EntityType#6a3870a0" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR (old."isAbstract" IS DISTINCT FROM new."isAbstract") OR ((old.extends)::text IS DISTINCT FROM (new.extends)::text) OR ((old.backend)::text IS DISTINCT FROM (new.backend)::text))) EXECUTE PROCEDURE public."validate_update_sys_md_EntityType#6a3870a0"();


--
-- Name: sys_md_Package#a6dc6fe7 update_trigger_sys_md_Package#a6dc6fe7; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_md_Package#a6dc6fe7" AFTER UPDATE ON public."sys_md_Package#a6dc6fe7" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_md_Package#a6dc6fe7"();


--
-- Name: sys_md_Tag#c2d685da update_trigger_sys_md_Tag#c2d685da; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_md_Tag#c2d685da" AFTER UPDATE ON public."sys_md_Tag#c2d685da" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_md_Tag#c2d685da"();


--
-- Name: sys_negotiator_NegotiatorConfig#aced883a update_trigger_sys_negotiator_NegotiatorConfig#aced883a; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_negotiator_NegotiatorConfig#aced883a" AFTER UPDATE ON public."sys_negotiator_NegotiatorConfig#aced883a" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_negotiator_NegotiatorConfig#aced883a"();


--
-- Name: sys_negotiator_NegotiatorEntityConfig#9a61747d update_trigger_sys_negotiator_NegotiatorEntityConfig#9a61747d; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_negotiator_NegotiatorEntityConfig#9a61747d" AFTER UPDATE ON public."sys_negotiator_NegotiatorEntityConfig#9a61747d" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_negotiator_NegotiatorEntityConfig#9a61747d"();


--
-- Name: sys_ont_Ontology#49a81949 update_trigger_sys_ont_Ontology#49a81949; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ont_Ontology#49a81949" AFTER UPDATE ON public."sys_ont_Ontology#49a81949" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ont_Ontology#49a81949"();


--
-- Name: sys_ont_OntologyTerm#f0034aa0 update_trigger_sys_ont_OntologyTerm#f0034aa0; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ont_OntologyTerm#f0034aa0" AFTER UPDATE ON public."sys_ont_OntologyTerm#f0034aa0" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ont_OntologyTerm#f0034aa0"();


--
-- Name: sys_ont_OntologyTermDynamicAnnotation#6454b1f8 update_trigger_sys_ont_OntologyTermDynamicAnnotation#6454b1f8; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ont_OntologyTermDynamicAnnotation#6454b1f8" AFTER UPDATE ON public."sys_ont_OntologyTermDynamicAnnotation#6454b1f8" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ont_OntologyTermDynamicAnnotation#6454b1f8"();


--
-- Name: sys_ont_OntologyTermHit#9ce87f6a update_trigger_sys_ont_OntologyTermHit#9ce87f6a; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ont_OntologyTermHit#9ce87f6a" AFTER UPDATE ON public."sys_ont_OntologyTermHit#9ce87f6a" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ont_OntologyTermHit#9ce87f6a"();


--
-- Name: sys_ont_OntologyTermNodePath#adc5397c update_trigger_sys_ont_OntologyTermNodePath#adc5397c; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ont_OntologyTermNodePath#adc5397c" AFTER UPDATE ON public."sys_ont_OntologyTermNodePath#adc5397c" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ont_OntologyTermNodePath#adc5397c"();


--
-- Name: sys_ont_OntologyTermSynonym#ce764ed4 update_trigger_sys_ont_OntologyTermSynonym#ce764ed4; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ont_OntologyTermSynonym#ce764ed4" AFTER UPDATE ON public."sys_ont_OntologyTermSynonym#ce764ed4" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ont_OntologyTermSynonym#ce764ed4"();


--
-- Name: sys_ont_TermFrequency#aef76974 update_trigger_sys_ont_TermFrequency#aef76974; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_ont_TermFrequency#aef76974" AFTER UPDATE ON public."sys_ont_TermFrequency#aef76974" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_ont_TermFrequency#aef76974"();


--
-- Name: sys_scr_Script#354cd12b update_trigger_sys_scr_Script#354cd12b; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_scr_Script#354cd12b" AFTER UPDATE ON public."sys_scr_Script#354cd12b" FOR EACH ROW WHEN (((old.name)::text IS DISTINCT FROM (new.name)::text)) EXECUTE PROCEDURE public."validate_update_sys_scr_Script#354cd12b"();


--
-- Name: sys_scr_ScriptParameter#88bc2dd2 update_trigger_sys_scr_ScriptParameter#88bc2dd2; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_scr_ScriptParameter#88bc2dd2" AFTER UPDATE ON public."sys_scr_ScriptParameter#88bc2dd2" FOR EACH ROW WHEN (((old.name)::text IS DISTINCT FROM (new.name)::text)) EXECUTE PROCEDURE public."validate_update_sys_scr_ScriptParameter#88bc2dd2"();


--
-- Name: sys_scr_ScriptType#3e8906a6 update_trigger_sys_scr_ScriptType#3e8906a6; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_scr_ScriptType#3e8906a6" AFTER UPDATE ON public."sys_scr_ScriptType#3e8906a6" FOR EACH ROW WHEN (((old.name)::text IS DISTINCT FROM (new.name)::text)) EXECUTE PROCEDURE public."validate_update_sys_scr_ScriptType#3e8906a6"();


--
-- Name: sys_sec_Group#d325f6e2 update_trigger_sys_sec_Group#d325f6e2; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_Group#d325f6e2" AFTER UPDATE ON public."sys_sec_Group#d325f6e2" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR ((old."rootPackage")::text IS DISTINCT FROM (new."rootPackage")::text))) EXECUTE PROCEDURE public."validate_update_sys_sec_Group#d325f6e2"();


--
-- Name: sys_sec_MembershipInvitation#27f7958b update_trigger_sys_sec_MembershipInvitation#27f7958b; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_MembershipInvitation#27f7958b" AFTER UPDATE ON public."sys_sec_MembershipInvitation#27f7958b" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_sec_MembershipInvitation#27f7958b"();


--
-- Name: sys_sec_PasswordResetToken#a04705dd update_trigger_sys_sec_PasswordResetToken#a04705dd; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_PasswordResetToken#a04705dd" AFTER UPDATE ON public."sys_sec_PasswordResetToken#a04705dd" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR ((old."user")::text IS DISTINCT FROM (new."user")::text))) EXECUTE PROCEDURE public."validate_update_sys_sec_PasswordResetToken#a04705dd"();


--
-- Name: sys_sec_RecoveryCode#a3192a80 update_trigger_sys_sec_RecoveryCode#a3192a80; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_RecoveryCode#a3192a80" AFTER UPDATE ON public."sys_sec_RecoveryCode#a3192a80" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_sec_RecoveryCode#a3192a80"();


--
-- Name: sys_sec_Role#b6639604 update_trigger_sys_sec_Role#b6639604; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_Role#b6639604" AFTER UPDATE ON public."sys_sec_Role#b6639604" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR ((old.name)::text IS DISTINCT FROM (new.name)::text))) EXECUTE PROCEDURE public."validate_update_sys_sec_Role#b6639604"();


--
-- Name: sys_sec_RoleMembership#2f0e0432 update_trigger_sys_sec_RoleMembership#2f0e0432; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_RoleMembership#2f0e0432" AFTER UPDATE ON public."sys_sec_RoleMembership#2f0e0432" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_sec_RoleMembership#2f0e0432"();


--
-- Name: sys_sec_Token#2dc001d0 update_trigger_sys_sec_Token#2dc001d0; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_Token#2dc001d0" AFTER UPDATE ON public."sys_sec_Token#2dc001d0" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR (old."creationDate" IS DISTINCT FROM new."creationDate"))) EXECUTE PROCEDURE public."validate_update_sys_sec_Token#2dc001d0"();


--
-- Name: sys_sec_User#953f6cde update_trigger_sys_sec_User#953f6cde; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_User#953f6cde" AFTER UPDATE ON public."sys_sec_User#953f6cde" FOR EACH ROW WHEN ((((old.id)::text IS DISTINCT FROM (new.id)::text) OR ((old.username)::text IS DISTINCT FROM (new.username)::text))) EXECUTE PROCEDURE public."validate_update_sys_sec_User#953f6cde"();


--
-- Name: sys_sec_UserSecret#f51533c3 update_trigger_sys_sec_UserSecret#f51533c3; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_UserSecret#f51533c3" AFTER UPDATE ON public."sys_sec_UserSecret#f51533c3" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_sec_UserSecret#f51533c3"();


--
-- Name: sys_sec_oidc_OidcClient#3e7b1b4d update_trigger_sys_sec_oidc_OidcClient#3e7b1b4d; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_oidc_OidcClient#3e7b1b4d" AFTER UPDATE ON public."sys_sec_oidc_OidcClient#3e7b1b4d" FOR EACH ROW WHEN (((old."registrationId")::text IS DISTINCT FROM (new."registrationId")::text)) EXECUTE PROCEDURE public."validate_update_sys_sec_oidc_OidcClient#3e7b1b4d"();


--
-- Name: sys_sec_oidc_OidcUserMapping#72060861 update_trigger_sys_sec_oidc_OidcUserMapping#72060861; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_sec_oidc_OidcUserMapping#72060861" AFTER UPDATE ON public."sys_sec_oidc_OidcUserMapping#72060861" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_sec_oidc_OidcUserMapping#72060861"();


--
-- Name: sys_set_MailSettings#6daa44ed update_trigger_sys_set_MailSettings#6daa44ed; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_set_MailSettings#6daa44ed" AFTER UPDATE ON public."sys_set_MailSettings#6daa44ed" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_set_MailSettings#6daa44ed"();


--
-- Name: sys_set_OpenCpuSettings#0ec0e4e8 update_trigger_sys_set_OpenCpuSettings#0ec0e4e8; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_set_OpenCpuSettings#0ec0e4e8" AFTER UPDATE ON public."sys_set_OpenCpuSettings#0ec0e4e8" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_set_OpenCpuSettings#0ec0e4e8"();


--
-- Name: sys_set_StyleSheet#9d5413fc update_trigger_sys_set_StyleSheet#9d5413fc; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_set_StyleSheet#9d5413fc" AFTER UPDATE ON public."sys_set_StyleSheet#9d5413fc" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_set_StyleSheet#9d5413fc"();


--
-- Name: sys_set_app#4f91996f update_trigger_sys_set_app#4f91996f; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_set_app#4f91996f" AFTER UPDATE ON public."sys_set_app#4f91996f" FOR EACH ROW WHEN (((old.ga_acc_privacy_friendly_mgs IS DISTINCT FROM new.ga_acc_privacy_friendly_mgs) OR ((old.id)::text IS DISTINCT FROM (new.id)::text))) EXECUTE PROCEDURE public."validate_update_sys_set_app#4f91996f"();


--
-- Name: sys_set_auth#98c4c015 update_trigger_sys_set_auth#98c4c015; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_set_auth#98c4c015" AFTER UPDATE ON public."sys_set_auth#98c4c015" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_set_auth#98c4c015"();


--
-- Name: sys_set_dataexplorer#76c80fb0 update_trigger_sys_set_dataexplorer#76c80fb0; Type: TRIGGER; Schema: public; Owner: molgenis
--

CREATE TRIGGER "update_trigger_sys_set_dataexplorer#76c80fb0" AFTER UPDATE ON public."sys_set_dataexplorer#76c80fb0" FOR EACH ROW WHEN (((old.id)::text IS DISTINCT FROM (new.id)::text)) EXECUTE PROCEDURE public."validate_update_sys_set_dataexplorer#76c80fb0"();


--
-- Name: acl_object_identity foreign_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_object_identity
    ADD CONSTRAINT foreign_fk_1 FOREIGN KEY (parent_object) REFERENCES public.acl_object_identity(id);


--
-- Name: acl_object_identity foreign_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_object_identity
    ADD CONSTRAINT foreign_fk_2 FOREIGN KEY (object_id_class) REFERENCES public.acl_class(id) ON DELETE CASCADE;


--
-- Name: acl_object_identity foreign_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_object_identity
    ADD CONSTRAINT foreign_fk_3 FOREIGN KEY (owner_sid) REFERENCES public.acl_sid(id);


--
-- Name: acl_entry foreign_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_entry
    ADD CONSTRAINT foreign_fk_4 FOREIGN KEY (acl_object_identity) REFERENCES public.acl_object_identity(id) ON DELETE CASCADE;


--
-- Name: acl_entry foreign_fk_5; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public.acl_entry
    ADD CONSTRAINT foreign_fk_5 FOREIGN KEY (sid) REFERENCES public.acl_sid(id);


--
-- Name: sys_beacons_Beacon#8e99cfb8 sys_beacons_Beacon#8e99cfb8_beacon_organization_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_Beacon#8e99cfb8"
    ADD CONSTRAINT "sys_beacons_Beacon#8e99cfb8_beacon_organization_fkey" FOREIGN KEY (beacon_organization) REFERENCES public."sys_beacons_BeaconOrganization#02fc7b88"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_beacons_Beacon#8e99cfb8_data_sets sys_beacons_Beacon#8e99cfb8_data_sets_data_sets_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_Beacon#8e99cfb8_data_sets"
    ADD CONSTRAINT "sys_beacons_Beacon#8e99cfb8_data_sets_data_sets_fkey" FOREIGN KEY (data_sets) REFERENCES public."sys_beacons_BeaconDataset#17b7de29"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_beacons_Beacon#8e99cfb8_data_sets sys_beacons_Beacon#8e99cfb8_data_sets_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_Beacon#8e99cfb8_data_sets"
    ADD CONSTRAINT "sys_beacons_Beacon#8e99cfb8_data_sets_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_beacons_Beacon#8e99cfb8"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_beacons_BeaconDataset#17b7de29 sys_beacons_BeaconD#17b7de29_data_set_entity_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_BeaconDataset#17b7de29"
    ADD CONSTRAINT "sys_beacons_BeaconD#17b7de29_data_set_entity_type_fkey" FOREIGN KEY (data_set_entity_type) REFERENCES public."sys_md_EntityType#6a3870a0"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_beacons_BeaconDataset#17b7de29 sys_beacons_BeaconD#17b7de29_genome_browser_attributes_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_beacons_BeaconDataset#17b7de29"
    ADD CONSTRAINT "sys_beacons_BeaconD#17b7de29_genome_browser_attributes_fkey" FOREIGN KEY (genome_browser_attributes) REFERENCES public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_dec_DecoratorConfi#e9347da9_parameters sys_dec_DecoratorConfi#e9347da9_parameters_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorConfi#e9347da9_parameters"
    ADD CONSTRAINT "sys_dec_DecoratorConfi#e9347da9_parameters_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_dec_DecoratorConfiguration#e9347da9"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_dec_DecoratorConfi#e9347da9_parameters sys_dec_DecoratorConfi#e9347da9_parameters_parameters_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorConfi#e9347da9_parameters"
    ADD CONSTRAINT "sys_dec_DecoratorConfi#e9347da9_parameters_parameters_fkey" FOREIGN KEY (parameters) REFERENCES public."sys_dec_DecoratorParameters#0c01537a"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_dec_DecoratorParameters#0c01537a sys_dec_DecoratorPa#0c01537a_decorator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_dec_DecoratorParameters#0c01537a"
    ADD CONSTRAINT "sys_dec_DecoratorPa#0c01537a_decorator_fkey" FOREIGN KEY (decorator) REFERENCES public."sys_dec_DynamicDecorator#8c3531bb"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_genomebrowser_GenomeBrowserSettings#294012a4 sys_genomebrowser_G#294012a4_entity_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_GenomeBrowserSettings#294012a4"
    ADD CONSTRAINT "sys_genomebrowser_G#294012a4_entity_fkey" FOREIGN KEY (entity) REFERENCES public."sys_md_EntityType#6a3870a0"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_genomebrowser_GenomeBrowserSettings#294012a4 sys_genomebrowser_G#294012a4_genome_browser_attrs_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_GenomeBrowserSettings#294012a4"
    ADD CONSTRAINT "sys_genomebrowser_G#294012a4_genome_browser_attrs_fkey" FOREIGN KEY (genome_browser_attrs) REFERENCES public."sys_genomebrowser_GenomeBrowserAttributes#bf815a63"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_genomebrowser_GenomeBrowserSettings#294012a4 sys_genomebrowser_G#294012a4_labelAttr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_GenomeBrowserSettings#294012a4"
    ADD CONSTRAINT "sys_genomebrowser_G#294012a4_labelAttr_fkey" FOREIGN KEY ("labelAttr") REFERENCES public."sys_md_Attribute#c8d9a252"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks sys_genomebrowser_Geno#294012a4__molgenis_reference_tracks_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks"
    ADD CONSTRAINT "sys_genomebrowser_Geno#294012a4__molgenis_reference_tracks_fkey" FOREIGN KEY (molgenis_reference_tracks) REFERENCES public."sys_genomebrowser_GenomeBrowserSettings#294012a4"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks sys_genomebrowser_Geno#294012a4_molgenis_reference_trac_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_genomebrowser_Geno#294012a4_molgenis_reference_tracks"
    ADD CONSTRAINT "sys_genomebrowser_Geno#294012a4_molgenis_reference_trac_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_genomebrowser_GenomeBrowserSettings#294012a4"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_idx_IndexAction#43bbc99b sys_idx_IndexAction#43bbc99b_indexActionGroup_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_idx_IndexAction#43bbc99b"
    ADD CONSTRAINT "sys_idx_IndexAction#43bbc99b_indexActionGroup_fkey" FOREIGN KEY ("indexActionGroup") REFERENCES public."sys_idx_IndexActionGroup#dd7eea75"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_job_AmazonBucketJobExecution#f9fb2a28 sys_job_AmazonBucke#f9fb2a28_file_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_AmazonBucketJobExecution#f9fb2a28"
    ADD CONSTRAINT "sys_job_AmazonBucke#f9fb2a28_file_fkey" FOREIGN KEY (file) REFERENCES public."sys_FileMeta#76d84794"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_job_FileIngestJobExecution#091fdb52 sys_job_FileIngestJ#091fdb52_file_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_FileIngestJobExecution#091fdb52"
    ADD CONSTRAINT "sys_job_FileIngestJ#091fdb52_file_fkey" FOREIGN KEY (file) REFERENCES public."sys_FileMeta#76d84794"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_job_ScheduledJob#d2aed7e4 sys_job_ScheduledJo#d2aed7e4_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ScheduledJob#d2aed7e4"
    ADD CONSTRAINT "sys_job_ScheduledJo#d2aed7e4_type_fkey" FOREIGN KEY (type) REFERENCES public."sys_job_ScheduledJobType#d68c491a"(name) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_job_ScheduledJobType#d68c491a sys_job_ScheduledJo#d68c491a_jobExecutionType_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_job_ScheduledJobType#d68c491a"
    ADD CONSTRAINT "sys_job_ScheduledJo#d68c491a_jobExecutionType_fkey" FOREIGN KEY ("jobExecutionType") REFERENCES public."sys_md_EntityType#6a3870a0"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_mail_JavaMailProperty#ddcd42a8 sys_mail_JavaMailPr#ddcd42a8_mailSettings_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_mail_JavaMailProperty#ddcd42a8"
    ADD CONSTRAINT "sys_mail_JavaMailPr#ddcd42a8_mailSettings_fkey" FOREIGN KEY ("mailSettings") REFERENCES public."sys_set_MailSettings#6daa44ed"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_map_EntityMapping#4c287e1a_attributeMappings sys_map_EntityMapping#4c287e1a_attributeMapping_identifier_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_EntityMapping#4c287e1a_attributeMappings"
    ADD CONSTRAINT "sys_map_EntityMapping#4c287e1a_attributeMapping_identifier_fkey" FOREIGN KEY (identifier) REFERENCES public."sys_map_EntityMapping#4c287e1a"(identifier) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_map_EntityMapping#4c287e1a_attributeMappings sys_map_EntityMapping#4c287e1a_attribute_attributeMappings_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_EntityMapping#4c287e1a_attributeMappings"
    ADD CONSTRAINT "sys_map_EntityMapping#4c287e1a_attribute_attributeMappings_fkey" FOREIGN KEY ("attributeMappings") REFERENCES public."sys_map_AttributeMapping#fdffac26"(identifier) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_map_MappingProject#c2f22991_mappingtargets sys_map_MappingProject#c2f22991_mappingtarg_mappingtargets_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingProject#c2f22991_mappingtargets"
    ADD CONSTRAINT "sys_map_MappingProject#c2f22991_mappingtarg_mappingtargets_fkey" FOREIGN KEY (mappingtargets) REFERENCES public."sys_map_MappingTarget#8e135dd7"(identifier) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_map_MappingProject#c2f22991_mappingtargets sys_map_MappingProject#c2f22991_mappingtargets_identifier_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingProject#c2f22991_mappingtargets"
    ADD CONSTRAINT "sys_map_MappingProject#c2f22991_mappingtargets_identifier_fkey" FOREIGN KEY (identifier) REFERENCES public."sys_map_MappingProject#c2f22991"(identifier) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_map_MappingTarget#8e135dd7_entityMappings sys_map_MappingTarget#8e135dd7_entityMappin_entityMappings_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingTarget#8e135dd7_entityMappings"
    ADD CONSTRAINT "sys_map_MappingTarget#8e135dd7_entityMappin_entityMappings_fkey" FOREIGN KEY ("entityMappings") REFERENCES public."sys_map_EntityMapping#4c287e1a"(identifier) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_map_MappingTarget#8e135dd7_entityMappings sys_map_MappingTarget#8e135dd7_entityMappings_identifier_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_map_MappingTarget#8e135dd7_entityMappings"
    ADD CONSTRAINT "sys_map_MappingTarget#8e135dd7_entityMappings_identifier_fkey" FOREIGN KEY (identifier) REFERENCES public."sys_map_MappingTarget#8e135dd7"(identifier) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Attribute#c8d9a252 sys_md_Attribute#c8d9a252_entity_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_entity_fkey" FOREIGN KEY (entity) REFERENCES public."sys_md_EntityType#6a3870a0"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Attribute#c8d9a252 sys_md_Attribute#c8d9a252_mappedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_mappedBy_fkey" FOREIGN KEY ("mappedBy") REFERENCES public."sys_md_Attribute#c8d9a252"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Attribute#c8d9a252 sys_md_Attribute#c8d9a252_parent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_parent_fkey" FOREIGN KEY (parent) REFERENCES public."sys_md_Attribute#c8d9a252"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Attribute#c8d9a252 sys_md_Attribute#c8d9a252_refEntityType_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_refEntityType_fkey" FOREIGN KEY ("refEntityType") REFERENCES public."sys_md_EntityType#6a3870a0"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Attribute#c8d9a252_tags sys_md_Attribute#c8d9a252_tags_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252_tags"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_tags_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_md_Attribute#c8d9a252"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Attribute#c8d9a252_tags sys_md_Attribute#c8d9a252_tags_tags_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Attribute#c8d9a252_tags"
    ADD CONSTRAINT "sys_md_Attribute#c8d9a252_tags_tags_fkey" FOREIGN KEY (tags) REFERENCES public."sys_md_Tag#c2d685da"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_EntityType#6a3870a0 sys_md_EntityType#6a3870a0_extends_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_EntityType#6a3870a0"
    ADD CONSTRAINT "sys_md_EntityType#6a3870a0_extends_fkey" FOREIGN KEY (extends) REFERENCES public."sys_md_EntityType#6a3870a0"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_EntityType#6a3870a0 sys_md_EntityType#6a3870a0_package_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_EntityType#6a3870a0"
    ADD CONSTRAINT "sys_md_EntityType#6a3870a0_package_fkey" FOREIGN KEY (package) REFERENCES public."sys_md_Package#a6dc6fe7"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_EntityType#6a3870a0_tags sys_md_EntityType#6a3870a0_tags_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_EntityType#6a3870a0_tags"
    ADD CONSTRAINT "sys_md_EntityType#6a3870a0_tags_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_md_EntityType#6a3870a0"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_EntityType#6a3870a0_tags sys_md_EntityType#6a3870a0_tags_tags_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_EntityType#6a3870a0_tags"
    ADD CONSTRAINT "sys_md_EntityType#6a3870a0_tags_tags_fkey" FOREIGN KEY (tags) REFERENCES public."sys_md_Tag#c2d685da"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Package#a6dc6fe7 sys_md_Package#a6dc6fe7_parent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Package#a6dc6fe7"
    ADD CONSTRAINT "sys_md_Package#a6dc6fe7_parent_fkey" FOREIGN KEY (parent) REFERENCES public."sys_md_Package#a6dc6fe7"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Package#a6dc6fe7_tags sys_md_Package#a6dc6fe7_tags_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Package#a6dc6fe7_tags"
    ADD CONSTRAINT "sys_md_Package#a6dc6fe7_tags_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_md_Package#a6dc6fe7"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_md_Package#a6dc6fe7_tags sys_md_Package#a6dc6fe7_tags_tags_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_md_Package#a6dc6fe7_tags"
    ADD CONSTRAINT "sys_md_Package#a6dc6fe7_tags_tags_fkey" FOREIGN KEY (tags) REFERENCES public."sys_md_Tag#c2d685da"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_negotiator_NegotiatorEntityConfig#9a61747d sys_negotiator_Nego#9a61747d_biobankId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_negotiator_NegotiatorEntityConfig#9a61747d"
    ADD CONSTRAINT "sys_negotiator_Nego#9a61747d_biobankId_fkey" FOREIGN KEY ("biobankId") REFERENCES public."sys_md_Attribute#c8d9a252"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_negotiator_NegotiatorEntityConfig#9a61747d sys_negotiator_Nego#9a61747d_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_negotiator_NegotiatorEntityConfig#9a61747d"
    ADD CONSTRAINT "sys_negotiator_Nego#9a61747d_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public."sys_md_Attribute#c8d9a252"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_negotiator_NegotiatorEntityConfig#9a61747d sys_negotiator_Nego#9a61747d_entity_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_negotiator_NegotiatorEntityConfig#9a61747d"
    ADD CONSTRAINT "sys_negotiator_Nego#9a61747d_entity_fkey" FOREIGN KEY (entity) REFERENCES public."sys_md_EntityType#6a3870a0"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_negotiator_NegotiatorEntityConfig#9a61747d sys_negotiator_Nego#9a61747d_negotiatorConfig_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_negotiator_NegotiatorEntityConfig#9a61747d"
    ADD CONSTRAINT "sys_negotiator_Nego#9a61747d_negotiatorConfig_fkey" FOREIGN KEY ("negotiatorConfig") REFERENCES public."sys_negotiator_NegotiatorConfig#aced883a"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTermHit#9ce87f6a sys_ont_OntologyTer#9ce87f6a_ontology_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHit#9ce87f6a"
    ADD CONSTRAINT "sys_ont_OntologyTer#9ce87f6a_ontology_fkey" FOREIGN KEY (ontology) REFERENCES public."sys_ont_Ontology#49a81949"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTerm#f0034aa0 sys_ont_OntologyTer#f0034aa0_ontology_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0"
    ADD CONSTRAINT "sys_ont_OntologyTer#f0034aa0_ontology_fkey" FOREIGN KEY (ontology) REFERENCES public."sys_ont_Ontology#49a81949"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTerm#f0034aa0_nodePath sys_ont_OntologyTerm#f0034aa0_nodePath_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_nodePath_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_ont_OntologyTerm#f0034aa0"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTerm#f0034aa0_nodePath sys_ont_OntologyTerm#f0034aa0_nodePath_nodePath_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_nodePath_nodePath_fkey" FOREIGN KEY ("nodePath") REFERENCES public."sys_ont_OntologyTermNodePath#adc5397c"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnota_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_ont_OntologyTerm#f0034aa0"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotatio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_ontologyTermDynamicAnnotatio_fkey" FOREIGN KEY ("ontologyTermDynamicAnnotation") REFERENCES public."sys_ont_OntologyTermDynamicAnnotation#6454b1f8"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_ont_OntologyTerm#f0034aa0"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym sys_ont_OntologyTerm#f0034aa0_ontology_ontologyTermSynonym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTerm#f0034aa0_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTerm#f0034aa0_ontology_ontologyTermSynonym_fkey" FOREIGN KEY ("ontologyTermSynonym") REFERENCES public."sys_ont_OntologyTermSynonym#ce764ed4"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_nodePath sys_ont_OntologyTermHi#9ce87f6a_nodePath_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_nodePath_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_ont_OntologyTermHit#9ce87f6a"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_nodePath sys_ont_OntologyTermHi#9ce87f6a_nodePath_nodePath_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_nodePath"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_nodePath_nodePath_fkey" FOREIGN KEY ("nodePath") REFERENCES public."sys_ont_OntologyTermNodePath#adc5397c"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym sys_ont_OntologyTermHi#9ce87f6a_ontolo_ontologyTermSynonym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_ontolo_ontologyTermSynonym_fkey" FOREIGN KEY ("ontologyTermSynonym") REFERENCES public."sys_ont_OntologyTermSynonym#ce764ed4"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnno_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_ont_OntologyTermHit#9ce87f6a"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f6a_ontologyTermSynonym_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_ont_OntologyTermHit#9ce87f6a"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation sys_ont_OntologyTermHi#9ce87f_ontologyTermDynamicAnnotatio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_ont_OntologyTermHi#9ce87f6a_ontologyTermDynamicAnnotation"
    ADD CONSTRAINT "sys_ont_OntologyTermHi#9ce87f_ontologyTermDynamicAnnotatio_fkey" FOREIGN KEY ("ontologyTermDynamicAnnotation") REFERENCES public."sys_ont_OntologyTermDynamicAnnotation#6454b1f8"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_scr_Script#354cd12b_parameters sys_scr_Script#354cd12b_parameters_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_Script#354cd12b_parameters"
    ADD CONSTRAINT "sys_scr_Script#354cd12b_parameters_name_fkey" FOREIGN KEY (name) REFERENCES public."sys_scr_Script#354cd12b"(name) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_scr_Script#354cd12b_parameters sys_scr_Script#354cd12b_parameters_parameters_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_Script#354cd12b_parameters"
    ADD CONSTRAINT "sys_scr_Script#354cd12b_parameters_parameters_fkey" FOREIGN KEY (parameters) REFERENCES public."sys_scr_ScriptParameter#88bc2dd2"(name) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_scr_Script#354cd12b sys_scr_Script#354cd12b_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_scr_Script#354cd12b"
    ADD CONSTRAINT "sys_scr_Script#354cd12b_type_fkey" FOREIGN KEY (type) REFERENCES public."sys_scr_ScriptType#3e8906a6"(name) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_Group#d325f6e2 sys_sec_Group#d325f6e2_rootPackage_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Group#d325f6e2"
    ADD CONSTRAINT "sys_sec_Group#d325f6e2_rootPackage_fkey" FOREIGN KEY ("rootPackage") REFERENCES public."sys_md_Package#a6dc6fe7"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_MembershipInvitation#27f7958b sys_sec_MembershipI#27f7958b_invitedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_MembershipInvitation#27f7958b"
    ADD CONSTRAINT "sys_sec_MembershipI#27f7958b_invitedBy_fkey" FOREIGN KEY ("invitedBy") REFERENCES public."sys_sec_User#953f6cde"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_MembershipInvitation#27f7958b sys_sec_MembershipI#27f7958b_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_MembershipInvitation#27f7958b"
    ADD CONSTRAINT "sys_sec_MembershipI#27f7958b_role_fkey" FOREIGN KEY (role) REFERENCES public."sys_sec_Role#b6639604"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_PasswordResetToken#a04705dd sys_sec_PasswordRes#a04705dd_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_PasswordResetToken#a04705dd"
    ADD CONSTRAINT "sys_sec_PasswordRes#a04705dd_user_fkey" FOREIGN KEY ("user") REFERENCES public."sys_sec_User#953f6cde"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_Role#b6639604 sys_sec_Role#b6639604_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Role#b6639604"
    ADD CONSTRAINT "sys_sec_Role#b6639604_group_fkey" FOREIGN KEY ("group") REFERENCES public."sys_sec_Group#d325f6e2"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_Role#b6639604_includes sys_sec_Role#b6639604_includes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Role#b6639604_includes"
    ADD CONSTRAINT "sys_sec_Role#b6639604_includes_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_sec_Role#b6639604"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_Role#b6639604_includes sys_sec_Role#b6639604_includes_includes_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Role#b6639604_includes"
    ADD CONSTRAINT "sys_sec_Role#b6639604_includes_includes_fkey" FOREIGN KEY (includes) REFERENCES public."sys_sec_Role#b6639604"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_RoleMembership#2f0e0432 sys_sec_RoleMembers#2f0e0432_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_RoleMembership#2f0e0432"
    ADD CONSTRAINT "sys_sec_RoleMembers#2f0e0432_role_fkey" FOREIGN KEY (role) REFERENCES public."sys_sec_Role#b6639604"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_RoleMembership#2f0e0432 sys_sec_RoleMembers#2f0e0432_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_RoleMembership#2f0e0432"
    ADD CONSTRAINT "sys_sec_RoleMembers#2f0e0432_user_fkey" FOREIGN KEY ("user") REFERENCES public."sys_sec_User#953f6cde"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_Token#2dc001d0 sys_sec_Token#2dc001d0_User_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_Token#2dc001d0"
    ADD CONSTRAINT "sys_sec_Token#2dc001d0_User_fkey" FOREIGN KEY ("User") REFERENCES public."sys_sec_User#953f6cde"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_oidc_OidcUserMapping#72060861 sys_sec_oidc_OidcUs#72060861_oidcClient_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_oidc_OidcUserMapping#72060861"
    ADD CONSTRAINT "sys_sec_oidc_OidcUs#72060861_oidcClient_fkey" FOREIGN KEY ("oidcClient") REFERENCES public."sys_sec_oidc_OidcClient#3e7b1b4d"("registrationId") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_sec_oidc_OidcUserMapping#72060861 sys_sec_oidc_OidcUs#72060861_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_sec_oidc_OidcUserMapping#72060861"
    ADD CONSTRAINT "sys_sec_oidc_OidcUs#72060861_user_fkey" FOREIGN KEY ("user") REFERENCES public."sys_sec_User#953f6cde"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_set_StyleSheet#9d5413fc sys_set_StyleSheet#9d5413fc_bootstrap3Theme_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_StyleSheet#9d5413fc"
    ADD CONSTRAINT "sys_set_StyleSheet#9d5413fc_bootstrap3Theme_fkey" FOREIGN KEY ("bootstrap3Theme") REFERENCES public."sys_FileMeta#76d84794"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_set_StyleSheet#9d5413fc sys_set_StyleSheet#9d5413fc_bootstrap4Theme_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_StyleSheet#9d5413fc"
    ADD CONSTRAINT "sys_set_StyleSheet#9d5413fc_bootstrap4Theme_fkey" FOREIGN KEY ("bootstrap4Theme") REFERENCES public."sys_FileMeta#76d84794"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_set_auth#98c4c015_oidcClients sys_set_auth#98c4c015_oidcClients_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_auth#98c4c015_oidcClients"
    ADD CONSTRAINT "sys_set_auth#98c4c015_oidcClients_id_fkey" FOREIGN KEY (id) REFERENCES public."sys_set_auth#98c4c015"(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sys_set_auth#98c4c015_oidcClients sys_set_auth#98c4c015_oidcClients_oidcClients_fkey; Type: FK CONSTRAINT; Schema: public; Owner: molgenis
--

ALTER TABLE ONLY public."sys_set_auth#98c4c015_oidcClients"
    ADD CONSTRAINT "sys_set_auth#98c4c015_oidcClients_oidcClients_fkey" FOREIGN KEY ("oidcClients") REFERENCES public."sys_sec_oidc_OidcClient#3e7b1b4d"("registrationId") DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

